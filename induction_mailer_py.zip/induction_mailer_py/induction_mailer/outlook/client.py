from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from .com_support import require_win32com


OL_MAIL_ITEM = 0


@dataclass
class OutlookClient:
    """Thin Outlook COM client.

    Mirrors VBS GetOutlookApp/GetNamespace usage.
    """

    app: Any

    @classmethod
    def connect(cls) -> "OutlookClient":
        win32, pythoncom = require_win32com()
        # Try active Outlook instance first (GetObject in VBS)
        app = None
        try:
            app = win32.GetActiveObject("Outlook.Application")
        except Exception:
            app = None
        if app is None:
            # Create a new instance
            app = win32.gencache.EnsureDispatch("Outlook.Application")
        return cls(app=app)

    @property
    def namespace(self) -> Any:
        return self.app.GetNamespace("MAPI")

    def create_mail_item(self) -> Any:
        return self.app.CreateItem(OL_MAIL_ITEM)

    def create_recipient(self, address: str) -> Any:
        return self.namespace.CreateRecipient(address)

    def resolve_recipient(self, address: str) -> Optional[Any]:
        """Resolve a recipient string; returns a Recipient COM object or None."""
        recip = self.create_recipient(address)
        try:
            ok = bool(recip.Resolve())
        except Exception:
            ok = False
        return recip if ok else None

    def get_address_list(self, name: str) -> Optional[Any]:
        try:
            return self.namespace.AddressLists(name)
        except Exception:
            return None
