from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Callable, Optional


def log_event(log_path: str | Path, message: str) -> None:
    """Append a timestamped line to a log file (VBS `LogEvent`)."""
    path = Path(log_path)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8", errors="replace") as f:
            f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {message}\n")
    except Exception:
        # Logging must never break the workflow.
        pass


def make_log_handler(default_log_path: str | Path) -> Callable[[str, str], None]:
    """Return a (log_path, message) -> None callback, similar to VBS `LogHandler`."""

    def _handler(log_path: str, message: str) -> None:
        used = log_path or str(default_log_path)
        log_event(used, message)

    return _handler
