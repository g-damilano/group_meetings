from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

from .core_types import ActionMode, DeliveryMode, MailOptions, ResolutionInfo, Template
from .template.repository import TemplateRepository
from .template.placeholders import build_context_from_meta, ensure_placeholder_values
from .template.link_map import load_link_map_context, apply_link_map
from .template.assets import prepare_inline_image_support, resolve_attachment_paths
from .utils import capitalize_name_part, safe_text
from .outlook.client import OutlookClient
from .outlook.composer import MailComposer
from .name_resolution.resolver import NameResolver
from .name_resolution.prompt import prompt_recipient_resolution_package


@dataclass
class InductionMailerApp:
    templates_root: Path
    link_map_file: str = "links_map.txt"
    log_path: Optional[str] = "induction_mailer.log"

    def run_interactive(self) -> int:
        print("\n=== InductionMailer (Python) ===\n")

        repo = TemplateRepository(self.templates_root)
        templates = repo.load_templates()
        if not templates:
            print(f"No templates found under: {self.templates_root}")
            return 2

        link_map = load_link_map_context(self.templates_root / self.link_map_file)

        # Mode
        mode = self._prompt_mode()
        action = self._prompt_action()

        # Outlook + name resolver
        client = OutlookClient.connect()
        resolver = NameResolver(client)
        package = prompt_recipient_resolution_package(resolver)

        # Template selection
        selected = self._prompt_template_selection(templates)
        if not selected:
            print("No templates selected.")
            return 0

        # Dispatch
        composer = MailComposer(client)

        for tmpl in selected:
            self._send_template(
                composer=composer,
                tmpl=tmpl,
                mode=mode,
                action=action,
                recipients=package.entries,
                link_map=link_map,
            )

        print("\nDone.")
        return 0

    def _prompt_mode(self) -> DeliveryMode:
        print("Delivery mode")
        print("  1) broadcast  (one email -> many recipients)")
        print("  2) personal   (one email per recipient with [NAME]/[SURNAME])")
        choice = input("Mode (1-2, default 1): ").strip()
        return DeliveryMode.PERSONAL if choice == "2" else DeliveryMode.BROADCAST

    def _prompt_action(self) -> ActionMode:
        print("\nAction")
        print("  1) display  (open drafts)")
        print("  2) send     (send immediately)")
        print("  3) save     (save .msg to disk)")
        choice = input("Action (1-3, default 1): ").strip()
        if choice == "2":
            return ActionMode.SEND
        if choice == "3":
            return ActionMode.SAVE
        return ActionMode.DISPLAY

    def _prompt_template_selection(self, templates: List[Template]) -> List[Template]:
        print("\nTemplates")
        for i, t in enumerate(templates, start=1):
            stage = t.stage or "(no stage)"
            code = t.code or ""
            print(f"  {i:>2}) {stage:20} {code:8} {t.display_name}")

        raw = input("Select templates (e.g. '1', '1,3-5', 'all'): ").strip().lower()
        if not raw:
            return []
        if raw in {"all", "a"}:
            return templates

        indexes: set[int] = set()
        for part in raw.split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                a, b = part.split("-", 1)
                try:
                    start = int(a)
                    end = int(b)
                except ValueError:
                    continue
                for k in range(min(start, end), max(start, end) + 1):
                    indexes.add(k)
            else:
                try:
                    indexes.add(int(part))
                except ValueError:
                    continue

        selected: List[Template] = []
        for k in sorted(indexes):
            if 1 <= k <= len(templates):
                selected.append(templates[k - 1])
        return selected

    def _send_template(
        self,
        composer: MailComposer,
        tmpl: Template,
        mode: DeliveryMode,
        action: ActionMode,
        recipients: List[ResolutionInfo],
        link_map: Dict[str, str],
    ) -> None:
        meta = tmpl.meta

        # Build base context
        ctx = build_context_from_meta(meta, link_map_context=link_map)

        subject_raw = safe_text(meta.get("subject", ""))
        cc_raw = safe_text(meta.get("cc", ""))
        bcc_raw = safe_text(meta.get("bcc", ""))
        attachments_raw = safe_text(meta.get("attachments", ""))

        # body
        body_html = tmpl.body
        body_html = apply_link_map(body_html, link_map)

        # apply context to header fields before placeholder prompt
        subject = apply_link_map(subject_raw, link_map)
        cc = apply_link_map(cc_raw, link_map)
        bcc = apply_link_map(bcc_raw, link_map)

        # Prompt placeholders (shared)
        ensure_placeholder_values(ctx, [subject, cc, bcc, body_html, attachments_raw], prompt_fn=input)

        # Evaluate fields with final context
        from .template.placeholders import apply_context_to_text

        subject = apply_context_to_text(subject, ctx)
        cc = apply_context_to_text(cc, ctx)
        bcc = apply_context_to_text(bcc, ctx)

        if mode == DeliveryMode.BROADCAST:
            to = "; ".join([r.email or r.preferred_address for r in recipients if (r.email or r.preferred_address)])
            rendered_body = apply_context_to_text(body_html, ctx)

            rendered_body, inline_folder = prepare_inline_image_support(rendered_body, tmpl.path)
            attachments = resolve_attachment_paths(attachments_raw, tmpl.folder)

            opts = MailOptions(
                to=to,
                cc=cc,
                bcc=bcc,
                subject=subject,
                body_html=rendered_body,
                action=action.value,
                attachments=attachments,
                inline_image_folder=inline_folder or None,
                log_path=self.log_path,
            )
            composer.compose_and_execute(opts)
            return

        # personal: one email per recipient
        for r in recipients:
            per_ctx = ctx.copy()
            self._inject_recipient_context(per_ctx, r)

            subj_i = apply_context_to_text(subject_raw, per_ctx)
            cc_i = apply_context_to_text(cc_raw, per_ctx)
            bcc_i = apply_context_to_text(bcc_raw, per_ctx)

            body_i = apply_link_map(body_html, link_map)
            body_i = apply_context_to_text(body_i, per_ctx)
            body_i, inline_folder = prepare_inline_image_support(body_i, tmpl.path)

            attachments = resolve_attachment_paths(attachments_raw, tmpl.folder)

            opts = MailOptions(
                to=r.email or r.preferred_address,
                cc=cc_i,
                bcc=bcc_i,
                subject=subj_i,
                body_html=body_i,
                action=action.value,
                attachments=attachments,
                inline_image_folder=inline_folder or None,
                log_path=self.log_path,
            )
            composer.compose_and_execute(opts)

    def _inject_recipient_context(self, ctx: Dict[str, str], r: ResolutionInfo) -> None:
        name = safe_text(r.first)
        surname = safe_text(r.last)
        full = safe_text(r.full)

        # Basic cleanups and capitalization (port of EnsureCapitalizedNameText)
        if name:
            name = " ".join(capitalize_name_part(p) for p in name.split())
        if surname:
            surname = " ".join(capitalize_name_part(p) for p in surname.split())
        if not full:
            full = (name + " " + surname).strip()
        if full:
            full = " ".join(capitalize_name_part(p) for p in full.split())

        ctx["NAME"] = name
        ctx["SURNAME"] = surname
        ctx["FULL_NAME"] = full
        ctx["EMAIL"] = safe_text(r.email or r.preferred_address)
        ctx["DIRECTORY_SOURCE"] = safe_text(r.directory_source)
        ctx["DIRECTORY_ATTEMPTED"] = ";".join(r.directory_attempted or [])


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Template-driven Outlook mailer (Python port of InductionMailer.vbs)")
    p.add_argument("--templates", default="templates", help="Templates root folder")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_arg_parser().parse_args(argv)
    app = InductionMailerApp(templates_root=Path(args.templates).resolve())
    return app.run_interactive()
