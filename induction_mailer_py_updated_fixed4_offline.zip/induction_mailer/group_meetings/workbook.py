from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Iterable, List, Optional


@dataclass
class RotaEntry:
    meeting_date: date
    literature: str
    results: str
    alternate: str
    room: str
    lab_manager: str


def _to_date(value) -> Optional[date]:
    if value is None:
        return None
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    # openpyxl can return numbers for Excel serials if guess_types misbehaves;
    # in those cases we cannot reliably convert without workbook epoch.
    try:
        if hasattr(value, "year") and hasattr(value, "month") and hasattr(value, "day"):
            return date(int(value.year), int(value.month), int(value.day))
    except Exception:
        return None
    return None


class MeetingWorkbook:
    """Read-only access to the meeting rota workbook.

    Port of VBS LoadMeetingWorkbook / LocateMeetingRows / sheet cell reads.
    Uses openpyxl so it does not require Excel.
    """

    def __init__(self, path: Path, sheet_rota: str = "Rota", sheet_emails: str = "Emails"):
        self.path = Path(path)
        self.sheet_rota_name = sheet_rota
        self.sheet_emails_name = sheet_emails
        self._wb = None
        self._rota = None
        self._emails = None

    def open(self) -> "MeetingWorkbook":
        from openpyxl import load_workbook

        # data_only=True => read cached formula values when present
        self._wb = load_workbook(self.path, data_only=True)
        self._rota = self._wb[self.sheet_rota_name]
        self._emails = self._wb[self.sheet_emails_name]
        return self

    def close(self) -> None:
        try:
            if self._wb is not None:
                self._wb.close()
        except Exception:
            pass
        self._wb = None
        self._rota = None
        self._emails = None

    def __enter__(self) -> "MeetingWorkbook":
        return self.open()

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @property
    def rota(self):
        if self._rota is None:
            raise RuntimeError("Workbook not opened")
        return self._rota

    @property
    def emails(self):
        if self._emails is None:
            raise RuntimeError("Workbook not opened")
        return self._emails

    def last_rota_row(self) -> int:
        return int(self.rota.max_row or 0)

    def find_row_for_date(self, target: date) -> int:
        """Return the row index (1-based) for a date in column A; -1 if not found."""
        for r in range(2, self.last_rota_row() + 1):
            d = _to_date(self.rota.cell(r, 1).value)
            if d == target:
                return r
        return -1

    def find_rows_for_dates(self, targets: Iterable[date]) -> List[int]:
        return [self.find_row_for_date(d) for d in targets]

    def get_rota_entry(self, row: int) -> RotaEntry:
        d = _to_date(self.rota.cell(row, 1).value)
        if d is None:
            raise ValueError(f"Row {row} has no parsable date in column A")
        literature = str(self.rota.cell(row, 2).value or "").strip()
        results = str(self.rota.cell(row, 3).value or "").strip()
        alternate = str(self.rota.cell(row, 4).value or "").strip()
        room = str(self.rota.cell(row, 5).value or "").strip()
        lab_manager = str(self.rota.cell(row, 6).value or "").strip()
        return RotaEntry(
            meeting_date=d,
            literature=literature,
            results=results,
            alternate=alternate,
            room=room,
            lab_manager=lab_manager,
        )

    def eligible_names_for_tentative_rota(self) -> List[str]:
        """Read Emails sheet: column A (name) where column D == 1 (eligible)."""
        out: List[str] = []
        max_row = int(self.emails.max_row or 0)
        for r in range(2, max_row + 1):
            eligible = self.emails.cell(r, 4).value
            try:
                is_eligible = int(eligible) == 1
            except Exception:
                is_eligible = False
            if not is_eligible:
                continue
            name = str(self.emails.cell(r, 1).value or "").strip()
            if name:
                out.append(name)
        return out
