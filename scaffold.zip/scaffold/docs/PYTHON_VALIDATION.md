# Python Validation

Python support begins in Stage 5 as a development-side validator and test
harness. It is not required for operational VBS deployment.

The validator uses only the Python standard library:

```text
python scaffold/python/validate_scaffold.py --root scaffold
python -m unittest discover -s scaffold/python/tests
```

It checks:

- JSON contract files parse and contain expected structures;
- dispatch state fixtures match the documented state machine;
- workbook-shaped CSV examples contain required headers;
- induction template manifest paths resolve;
- public scaffold text does not contain non-example email addresses, private
  path markers, or live SharePoint-style URLs.

The validator complements VBS smoke tests. It must not become the sole source of
architectural truth.
