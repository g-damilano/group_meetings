# Watchdog Managed Repair

Stage 6 managed repair is intentionally narrower than report-only inspection.
Repair is allowed only when all of these are true:

- the Outbox item has a valid scaffold managed email key;
- the key on the item matches the expected key;
- Outlook transport diagnostics indicate a connected, non-blocked state;
- the item is not waiting for a future deferred-delivery time;
- the queued item age can be determined and exceeds the configured grace period;
- a replacement factory creates a replacement mail item carrying the same
  managed key;
- repair has been explicitly committed by the caller.

Unmarked mail, wrong-key mail, blocked transport, future-deferred mail, young
queued mail, uncertain item age, missing replacement creation, and wrong-key
replacement all resolve to no action, `ACTION_REQUIRED`, or `FAILED_SAFE`.

The public watchdog entrypoint remains report-only. The managed repair primitive
is tested with fake mail objects only, so scaffold validation never modifies a
real mailbox.
