# Induction Mailer Conventions

Stage 3 uses anonymised CSV fixtures to express workbook and template
conventions without copying private operational data.

## Recipient CSV

Required columns:

- `alias`
- `email`

Optional columns:

- `first_name`
- `last_name`
- `full_name`
- `start_date`
- `cohort`
- `active`

`active` accepts `true`, `yes`, `1`, `on`, `false`, `no`, `0`, and `off`.
Inactive recipients are loaded but skipped by the planner.

## Template Manifest CSV

Required columns:

- `template_id`
- `mode`
- `template_path`

Optional columns:

- `target_key`
- `display_name`
- `attachment_base_folder`
- `attachments`
- `enabled`

`mode` is `broadcast` or `personal`. A selected mode of `all` includes both.

`template_path` may be absolute or relative to the manifest folder. Template
files may contain metadata comments at the top:

```text
<!-- Subject: Welcome [NAME] -->
```

The core template engine parses metadata and renders `[TOKEN]` or `{{TOKEN}}`
placeholders from the workflow context.

## Recipient Placeholder Keys

The induction planner provides:

- `ALIAS`
- `EMAIL`
- `NAME`
- `SURNAME`
- `FIRST_NAME`
- `LAST_NAME`
- `FULL_NAME`
- `START_DATE`
- `COHORT`
- `RECIPIENT_COUNT`

Templates should use generic placeholder names and must not contain private
names, addresses, internal links, or production-only identifiers.
