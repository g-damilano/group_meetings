# Induction Mailer Compatibility Map

The legacy induction mailer remains a frozen behavioural reference. Stage 3
scaffold work expresses the reusable behaviours through VBS-first contracts and
anonymised fixtures.

## Preserved Behavioural Concepts

- Template-driven communication: templates provide subject metadata and message
  body content.
- Delivery modes:
  - `broadcast`: one message to many recipients;
  - `personal`: one message per recipient with recipient-specific placeholders.
- Recipient-derived placeholders are available to templates, including first
  name, surname, full name, email, alias, start date, and cohort.
- Attachments and inline images remain core composition concerns, not workflow
  concerns.
- Dry-run/display-first operation is the scaffold default.

## Scaffold Mapping

| Legacy concern | Scaffold location |
| --- | --- |
| Template selection | template manifest fixture and input adapter |
| Recipient capture/resolution package | recipient CSV fixture and input adapter |
| Broadcast vs personal branching | induction message-plan adapter |
| Placeholder context construction | induction message-plan adapter plus core template engine |
| Message composition | core workflow facade and mail composer |
| Managed identity and dispatch states | core contracts and managed dispatch |
| User intent gathering | dry-run VBS entrypoint |

## Deliberate Stage 3 Limits

- No Outlook COM is created by induction workflow or orchestration modules.
- No real email is sent.
- No live address-book or GAL lookup is performed.
- No private templates, addresses, links, logs, or institutional identifiers are
  copied into scaffold files.
- Live display/draft/send modes remain blocked until later guarded migration
  work explicitly enables them.
