# Shared Scaffold Examples

Stage 4 keeps shared behaviour concrete through anonymised examples. These
examples are not production inputs; they document the workbook and template
shapes used by the VBS-first scaffold.

## Example Workbooks

The scaffold represents workbook conventions with CSV examples so they can be
read and diffed without Office automation:

- `examples/workbooks/group_meetings_rota_example.csv`
- `examples/workbooks/induction_recipients_example.csv`
- `examples/workbooks/induction_template_manifest_example.csv`

The operational VBS path can later read real workbooks through Excel-specific
adapters, but the shared contract remains the same column and field shape.

## Example Templates

Template examples live under `examples/templates/` and use the same metadata and
placeholder conventions as the test fixtures:

- metadata comments such as `<!-- Subject: Welcome [NAME] -->`;
- `[TOKEN]` and `{{TOKEN}}` placeholders;
- no private names, addresses, links, file paths, or institutional identifiers.

## Shared Contracts

Both group meetings and induction mailer examples map to:

- `WorkflowContext`
- `MessageSpec`
- `RecipientSpec`
- `DeliveryPolicy`
- `ManagedEmailKey`
- `DispatchResult`

The examples intentionally use `example.invalid` addresses and generic names.
Real operational material must remain outside the public scaffold.
