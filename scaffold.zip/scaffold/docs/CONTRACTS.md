# Canonical Contracts

The canonical architecture lives in contracts, schemas, naming conventions, workbook conventions,
template conventions, managed-key formats, dispatch states, cross-runtime fixtures, and documented
behaviour. It must not live exclusively in VBS or Python.

## Public Concepts

- `MessageSpec`: desired message content, recipients, attachments, and metadata.
- `RecipientSpec`: a raw recipient plus resolution metadata.
- `DeliveryPolicy`: display, draft, send, deferred delivery, and urgent-verification policy.
- `ManagedEmailKey`: deterministic logical identity for a scaffold-managed message.
- `DispatchResult`: state, reason, and safety metadata returned by managed dispatch.
- `WorkflowContext`: workflow run metadata and settings.
- `HealthReport`: Outlook/O365 health and action-required diagnostics.

## Workflow Facade Rule

Workflow modules should build mail through the VBS workflow facade rather than calling low-level COM
helpers directly. The facade builds `MessageSpec`, `DeliveryPolicy`, composer context, and dry-run
`DispatchResult` contracts while keeping Outlook folder/session work in the core layer.

`WorkflowContext` defaults to `dry_run = True`. Operational entrypoints may explicitly set it to
`False`, but tests, validation, and public examples should remain dry-run unless a user deliberately
opts into live Outlook actions.

## Managed Email Key Format

Default key format:

```text
ORG|WORKFLOW|YYYY-MM-DD|MESSAGE-TYPE|TARGET
```

The key must be deterministic, stable across reruns, unique per logical email, and independent of
Outlook `EntryID` values.

## Marker Rules

Managed messages should be stamped with both:

- an Outlook user property named `OfficeScaffoldManagedEmailKey`;
- a hidden HTML marker:

```html
<!-- OfficeScaffoldManagedEmailKey: ORG|WORKFLOW|YYYY-MM-DD|MESSAGE-TYPE|TARGET -->
```

The visible email body must not be degraded.
