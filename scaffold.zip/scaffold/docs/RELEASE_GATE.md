# Release Gate

The release gate is a Stage 7 report-only publication control. It converts the
release candidate plan into an explicit `PASS` or `BLOCKED` result.

Run:

```text
python scaffold\python\release_gate.py --root scaffold --repo-root .
python scaffold\python\release_gate.py --root scaffold --repo-root . --format json
python scaffold\python\release_gate.py --root scaffold --repo-root . --fail-if-blocked
python scaffold\python\release_gate.py --root scaffold --repo-root . --write-json legacy\reports\release_gate.json
```

The default command writes nothing. If `--write-json` is used, the output must
stay under `legacy/`, which is private local migration material and excluded
from the public scaffold release surface.

Gate values:

- `PASS`: scaffold release checks and repository boundary checks are clear.
- `BLOCKED`: the scaffold or surrounding repository still has release blockers.

The current scaffold can be ready while this gate remains `BLOCKED` because
repo-wide legacy/reference/generated material outside `scaffold/` still needs
an authorised public-release cleanup.

The gate does not package, publish, tag, send email, touch Outlook, mutate
mailbox data, edit legacy files, or modify copied mirror files. With
`--fail-if-blocked`, it returns exit code `1` for automation while preserving
the same report-only behaviour.
