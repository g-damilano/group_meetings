# Watchdog Sidecar

Stage 6 starts with a report-only watchdog sidecar. It can inspect scaffold
managed Outbox state through core diagnostics, but it does not repair, replace,
delete, send, or otherwise modify mail.

The entrypoint is:

```text
cscript.exe //NoLogo vbs\entrypoints\run_watchdog_report_only.vbs
```

By default it does not inspect live Outlook. This makes the entrypoint safe for
validation and Task Scheduler installation checks. Operational live inspection
must be explicitly requested:

```text
cscript.exe //NoLogo vbs\entrypoints\run_watchdog_report_only.vbs /inspect_live:true
```

Repair-like arguments such as `/repair`, `/delete`, `/send`, and `/replace` are
blocked with `FAILED_SAFE`.

The doctrine remains:

- inspect broadly;
- report clearly;
- modify narrowly in future guarded work;
- only modify scaffold-managed messages;
- never modify unmarked user mail;
- prefer `ACTION_REQUIRED` or `FAILED_SAFE` when uncertain.
