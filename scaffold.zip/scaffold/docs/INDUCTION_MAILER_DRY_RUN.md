# Induction Mailer Dry-Run Pipeline

Stage 3 introduces a scaffold-only dry-run path for induction mailer workflows:

1. Load anonymised recipient and template-manifest CSV inputs.
2. Build a broadcast/personal message plan.
3. Run the plan through the core workflow facade in dry-run mode.
4. Report shared dispatch states and counts.

The VBS entrypoint is:

```text
cscript.exe //NoLogo vbs\entrypoints\run_induction_mailer_dry_run.vbs /templates:tests\fixtures\induction_template_manifest_fixture.csv /recipients:tests\fixtures\induction_recipients_fixture.csv /mode:all
```

The script prints `key=value` lines and exits with:

- `0`: dry-run completed without action required;
- `1`: failed-safe boundary or composition failure;
- `2`: action required;
- `64`: missing required arguments.

The entrypoint blocks `/send`, `/live`, and `dry_run=false` requests before
loading inputs or planning messages.
