# Office Communication Automation Scaffold

This folder is the development root for the reusable Office/O365 communication automation scaffold.

Everything outside this folder is treated as frozen legacy, reference material, or repository control
material unless explicitly authorised for a specific run.

The scaffold-local license is provided in `LICENSE`.

## Deployment Priority

The scaffold is VBS-first for operational deployment in corporate Windows/O365 environments. Python is
reserved for development support, validation, richer tests, fixture generation, optional CLI use, and
future non-COM backends.

## Layers

1. Core Office Automation Layer: reusable Outlook, Excel, logging, dispatch, diagnostics, template, and
   recipient primitives.
2. Workflow Pipeline Layer: task-specific modules that build message specifications and call the core.
3. UI And Orchestration Layer: small entry scripts that gather intent and route to workflows.

## Current Stage

The scaffold has advanced through the reusable VBS core, group-meetings migration,
induction-mailer migration, shared examples, Python validation, and a report-first
watchdog sidecar with fake-object-tested managed repair guardrails.

The production legacy scripts are still frozen behavioural references and are not
modified by scaffold development.

Operational entrypoints remain dry-run or report-only by default:

- `RunGroupMeetings.vbs`
- `RunInductionMailer.vbs`
- `OutlookWatchdog.vbs`
- `ValidateWorkflow.vbs`
- `vbs/entrypoints/run_group_meetings_dry_run.vbs`
- `vbs/entrypoints/run_induction_mailer_dry_run.vbs`
- `vbs/entrypoints/run_watchdog_report_only.vbs`

The root-level scripts inside this folder are scaffold-local alternates for the
production-shaped legacy launchers. They forward arguments to scaffold dry-run,
report-only, or validation entrypoints and are safe to edit as part of this
rework. They do not replace or modify legacy scripts outside `scaffold/`.
Their mapping to frozen legacy/reference files is tracked in
`migration/legacy_alternate_map.json` and documented in
`docs/LEGACY_ALTERNATE_MAP.md`. The read-only
`python/legacy_intake_audit.py` tool validates that mapping without copying,
moving, or exposing private legacy source content.

For public-release preparation, `python/repo_boundary_audit.py` can inspect
material outside `scaffold/` in report-only mode and summarize release blockers
without editing frozen legacy/reference files.

If a hard copy of frozen legacy/reference/generated material is needed for
migration, place it under `legacy/`. That directory is ignored, excluded from
release manifests and sanitisation gates, and must not be used as a runtime
source. Use `python/legacy_mirror_audit.py` for report-only inspection of that
private mirror and `python/legacy_sanitisation_plan.py` for private
content-free remediation planning.

Use `python/release_candidate_plan.py` for a scaffold-only decision report that
combines release audit, manifest, mirror, and repo-boundary status without
publishing or modifying files outside `scaffold/`.

Use `python/release_gate.py` when automation needs an explicit `PASS` or
`BLOCKED` result, and `python/release_export_plan.py` when reviewers need the
deterministic list of scaffold files that would ship. Both tools are
report-only by default and write optional JSON only under `legacy/`.

Stage 7 release-readiness checks live inside the scaffold:

- `python/release_audit.py`
- `python/release_manifest.py`
- `python/release_candidate_plan.py`
- `python/release_gate.py`
- `python/release_export_plan.py`
- `vbs/tests/RunAllSmokeTests.vbs`
- `vbs/tests/PublicReleaseGateSmokeTest.vbs`
- `vbs/tests/ReleaseManifestSmokeTest.vbs`
- `docs/PUBLIC_RELEASE_CHECKLIST.md`
- `docs/PUBLICATION_BOUNDARY.md`
- `docs/RELEASE_GATE.md`
- `docs/RELEASE_EXPORT_PLAN.md`
- `docs/RELEASE_NOTES_TEMPLATE.md`
- `docs/VALIDATION_RUNBOOK.md`
