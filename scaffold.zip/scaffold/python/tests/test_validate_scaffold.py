from __future__ import annotations

import unittest
from pathlib import Path
import shutil
import tempfile

import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))

import validate_scaffold


def remove_generated_artifacts() -> None:
    legacy_root = ROOT / "legacy"
    for path in ROOT.rglob("__pycache__"):
        if legacy_root in path.parents:
            continue
        shutil.rmtree(path, ignore_errors=True)


class ValidateScaffoldTests(unittest.TestCase):
    def setUp(self) -> None:
        remove_generated_artifacts()

    def tearDown(self) -> None:
        remove_generated_artifacts()

    @classmethod
    def tearDownClass(cls) -> None:
        remove_generated_artifacts()

    def test_dispatch_states_match_contract(self) -> None:
        self.assertEqual(validate_scaffold.validate_dispatch_states(ROOT), [])

    def test_csv_headers_are_present(self) -> None:
        self.assertEqual(validate_scaffold.validate_csv_headers(ROOT), [])

    def test_manifest_template_paths_resolve(self) -> None:
        self.assertEqual(
            validate_scaffold.validate_manifest_template_paths(
                ROOT, "examples/workbooks/induction_template_manifest_example.csv"
            ),
            [],
        )

    def test_full_validator_passes(self) -> None:
        self.assertEqual(validate_scaffold.validate(ROOT), [])

    def test_generated_artifacts_are_absent(self) -> None:
        self.assertEqual(validate_scaffold.validate_generated_artifacts(ROOT), [])

    def test_sanitisation_config_allows_only_example_domain(self) -> None:
        self.assertEqual(validate_scaffold.allowed_email_domains(ROOT), {"example.invalid"})

    def test_legacy_alternate_map_is_valid(self) -> None:
        self.assertEqual(validate_scaffold.validate_legacy_alternate_map(ROOT), [])

    def test_legacy_mirror_is_excluded_from_public_validation(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            (root / "docs").mkdir()
            (root / "docs" / "public.md").write_text("public scaffold text", encoding="utf-8")
            (root / "legacy").mkdir()
            private_text = "private" + "@" + "contoso.invalid"
            private_text = private_text + " C:/Users/Private/" + "OneDrive" + " - Example"
            (root / "legacy" / "private.md").write_text(
                private_text, encoding="utf-8"
            )
            (root / "legacy" / "bundle.zip").write_bytes(b"archive")

            public_paths = [path.relative_to(root).as_posix() for path in validate_scaffold.iter_public_text_files(root)]

            self.assertEqual(public_paths, ["docs/public.md"])
            self.assertTrue(validate_scaffold.is_release_excluded_path(root / "legacy" / "private.md", root))
            self.assertEqual(validate_scaffold.validate_generated_artifacts(root), [])


if __name__ == "__main__":
    unittest.main()
