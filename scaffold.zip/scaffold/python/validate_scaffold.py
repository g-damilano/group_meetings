"""Standard-library scaffold validation helpers.

Python is a development-side checker in this repository. The operational
architecture remains VBS-first and contract-driven.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Iterable


EXPECTED_STATES = [
    "NOT_REQUESTED",
    "COMPOSED",
    "DISPLAYED",
    "DRAFTED",
    "SEND_REQUESTED",
    "QUEUED_OUTBOX",
    "SENT_CONFIRMED",
    "DUPLICATE_SUPPRESSED",
    "WAITING_DEFERRED",
    "BLOCKED_OFFLINE",
    "BLOCKED_AUTH",
    "STALE_MANAGED_OUTBOX",
    "REPLACED_MANAGED_OUTBOX",
    "ACTION_REQUIRED",
    "FAILED_SAFE",
]

CSV_REQUIREMENTS = {
    "examples/workbooks/group_meetings_rota_example.csv": [
        "meeting_date",
        "literature_presenter",
        "results_presenter",
        "group_recipient",
        "manager_recipient",
    ],
    "examples/workbooks/induction_recipients_example.csv": [
        "alias",
        "email",
        "first_name",
        "last_name",
        "active",
    ],
    "examples/workbooks/induction_template_manifest_example.csv": [
        "template_id",
        "mode",
        "target_key",
        "template_path",
        "enabled",
    ],
    "vbs/tests/fixtures/induction_recipients_fixture.csv": [
        "alias",
        "email",
        "first_name",
        "last_name",
        "active",
    ],
    "vbs/tests/fixtures/induction_template_manifest_fixture.csv": [
        "template_id",
        "mode",
        "target_key",
        "template_path",
        "enabled",
    ],
}

TEXT_SUFFIXES = {".md", ".txt", ".csv", ".json", ".vbs", ".html", ".py"}
EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@([A-Z0-9.-]+\.[A-Z]{2,63})\b", re.I)
DEFAULT_ALLOWED_EMAIL_DOMAINS = {"example.invalid"}
DEFAULT_BLOCKED_TEXT_PATTERNS = [
    r"OneDrive\s+-",
    r"Imperial\s+College",
    r"https?://[^\s\"']*sharepoint[^\s\"']*",
]
DEFAULT_BLOCKED_GENERATED_SUFFIXES = {".log", ".pyc", ".pyo", ".zip", ".msg"}
DEFAULT_BLOCKED_GENERATED_DIRECTORY_NAMES = {"__pycache__"}
DEFAULT_RELEASE_EXCLUDED_DIRECTORY_NAMES = {"legacy"}
LEGACY_ALTERNATE_MAP_SCHEMA = "office-communication-scaffold.legacy-alternate-map.v1"
LEGACY_ALTERNATE_STATUSES = {"ported_alternate", "behaviour_mapped", "sanitised_fixture"}


def load_json(path: Path) -> object:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def validate_dispatch_states(root: Path) -> list[str]:
    errors: list[str] = []
    states_path = root / "fixtures" / "dispatch_states" / "states.json"
    data = load_json(states_path)
    states = data.get("states") if isinstance(data, dict) else None
    if states != EXPECTED_STATES:
        errors.append("dispatch state fixture does not match expected state machine")
    return errors


def validate_workflow_schema(root: Path) -> list[str]:
    errors: list[str] = []
    schema = load_json(root / "contracts" / "workflow_schema.json")
    if not isinstance(schema, dict):
        return ["workflow schema is not a JSON object"]
    defs = schema.get("$defs", {})
    if "message_spec" not in defs:
        errors.append("workflow schema missing message_spec definition")
    if "delivery_policy" not in defs:
        errors.append("workflow schema missing delivery_policy definition")
    return errors


def csv_headers(path: Path) -> list[str]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        return next(reader)


def validate_csv_headers(root: Path) -> list[str]:
    errors: list[str] = []
    for relative_path, required_headers in CSV_REQUIREMENTS.items():
        path = root / relative_path
        if not path.exists():
            errors.append(f"missing CSV file: {relative_path}")
            continue
        headers = csv_headers(path)
        missing = [header for header in required_headers if header not in headers]
        if missing:
            errors.append(f"{relative_path} missing headers: {', '.join(missing)}")
    return errors


def validate_manifest_template_paths(root: Path, manifest_relative_path: str) -> list[str]:
    errors: list[str] = []
    manifest_path = root / manifest_relative_path
    with manifest_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        for index, row in enumerate(reader, start=2):
            template_path = (row.get("template_path") or "").strip()
            if not template_path:
                errors.append(f"{manifest_relative_path}:{index} has empty template_path")
                continue
            resolved = (manifest_path.parent / template_path).resolve()
            if not resolved.exists():
                errors.append(f"{manifest_relative_path}:{index} template does not exist: {template_path}")
    return errors


def release_excluded_directory_names(root: Path) -> set[str]:
    data = sanitisation_config(root).get("release_excluded_directory_names", [])
    if isinstance(data, list) and data:
        return {str(item).strip("/\\").lower() for item in data if str(item).strip("/\\")}
    return set(DEFAULT_RELEASE_EXCLUDED_DIRECTORY_NAMES)


def is_release_excluded_path(path: Path, root: Path) -> bool:
    try:
        relative_parts = path.resolve().relative_to(root.resolve()).parts
    except ValueError:
        return False
    if not relative_parts:
        return False
    return relative_parts[0].lower() in release_excluded_directory_names(root)


def iter_public_text_files(root: Path) -> Iterable[Path]:
    root = root.resolve()
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        if is_release_excluded_path(path, root):
            continue
        if ".log" in path.name.lower():
            continue
        yield path


def sanitisation_config(root: Path) -> dict[str, object]:
    config_path = root / "fixtures" / "sanitisation" / "blocked_patterns.json"
    if not config_path.exists():
        return {}
    data = load_json(config_path)
    return data if isinstance(data, dict) else {}


def allowed_email_domains(root: Path) -> set[str]:
    data = sanitisation_config(root).get("allowed_email_domains", [])
    if isinstance(data, list):
        return {str(item).lower() for item in data}
    return set(DEFAULT_ALLOWED_EMAIL_DOMAINS)


def blocked_text_regexes(root: Path) -> list[re.Pattern[str]]:
    data = sanitisation_config(root).get("blocked_text_patterns", [])
    patterns = data if isinstance(data, list) else DEFAULT_BLOCKED_TEXT_PATTERNS
    return [re.compile(str(pattern), re.I) for pattern in patterns]


def validate_sanitisation(root: Path) -> list[str]:
    errors: list[str] = []
    allowed_domains = allowed_email_domains(root)
    blocked_patterns = blocked_text_regexes(root)
    for path in iter_public_text_files(root):
        text = path.read_text(encoding="utf-8", errors="ignore")
        for match in EMAIL_RE.finditer(text):
            if match.group(1).lower() not in allowed_domains:
                errors.append(f"{path.relative_to(root)} contains non-example email address")
                break
        for blocked_pattern in blocked_patterns:
            if blocked_pattern.search(text):
                errors.append(f"{path.relative_to(root)} contains private path or live SharePoint-style URL")
                break
    return errors


def validate_generated_artifacts(root: Path) -> list[str]:
    root = root.resolve()
    errors: list[str] = []
    config = sanitisation_config(root)
    suffixes = config.get("blocked_generated_suffixes", [])
    directory_names = config.get("blocked_generated_directory_names", [])
    blocked_suffixes = {str(item).lower() for item in suffixes} or set(DEFAULT_BLOCKED_GENERATED_SUFFIXES)
    blocked_directory_names = {str(item).lower() for item in directory_names} or set(DEFAULT_BLOCKED_GENERATED_DIRECTORY_NAMES)

    for path in root.rglob("*"):
        if is_release_excluded_path(path, root):
            continue
        relative = path.relative_to(root)
        if path.is_dir() and path.name.lower() in blocked_directory_names:
            errors.append(f"generated directory is present: {relative}")
        elif path.is_file() and path.suffix.lower() in blocked_suffixes:
            errors.append(f"generated or release-blocked artifact is present: {relative}")
    return errors


def is_relative_portable_path(path_text: object) -> bool:
    if not isinstance(path_text, str) or not path_text.strip():
        return False
    normalized = path_text.replace("\\", "/")
    if Path(path_text).is_absolute() or PureWindowsPath(path_text).is_absolute():
        return False
    return ".." not in PurePosixPath(normalized).parts


def validate_legacy_alternate_map(root: Path) -> list[str]:
    errors: list[str] = []
    map_path = root / "migration" / "legacy_alternate_map.json"
    if not map_path.exists():
        return ["missing legacy alternate map: migration/legacy_alternate_map.json"]

    data = load_json(map_path)
    if not isinstance(data, dict):
        return ["legacy alternate map is not a JSON object"]
    if data.get("schema") != LEGACY_ALTERNATE_MAP_SCHEMA:
        errors.append("legacy alternate map schema mismatch")

    policy = data.get("policy")
    if not isinstance(policy, dict):
        errors.append("legacy alternate map missing policy object")
    else:
        if policy.get("copying_into_scaffold_authorised") is not True:
            errors.append("legacy alternate map must explicitly allow copying into scaffold")
        for false_key in [
            "moving_legacy_files_allowed",
            "outside_root_edits_allowed",
            "raw_private_content_allowed",
            "live_send_allowed",
            "destructive_mailbox_actions_allowed",
        ]:
            if policy.get(false_key) is not False:
                errors.append(f"legacy alternate map policy must keep {false_key}=false")

    entries = data.get("entries")
    if not isinstance(entries, list) or not entries:
        errors.append("legacy alternate map must contain entries")
        return errors

    seen_scaffold_paths: set[str] = set()
    for index, entry in enumerate(entries, start=1):
        if not isinstance(entry, dict):
            errors.append(f"legacy alternate map entry {index} is not an object")
            continue

        legacy_path = entry.get("legacy_path")
        scaffold_path = entry.get("scaffold_path")
        route_path = entry.get("route_path")
        status = entry.get("status")

        if not is_relative_portable_path(legacy_path):
            errors.append(f"legacy alternate map entry {index} has non-relative legacy_path")
        if not is_relative_portable_path(scaffold_path):
            errors.append(f"legacy alternate map entry {index} has non-relative scaffold_path")
        elif not (root / str(scaffold_path)).exists():
            errors.append(f"legacy alternate map scaffold target is missing: {scaffold_path}")
        else:
            seen_scaffold_paths.add(str(scaffold_path).replace("\\", "/"))

        if route_path is not None:
            if not is_relative_portable_path(route_path):
                errors.append(f"legacy alternate map entry {index} has non-relative route_path")
            elif not (root / str(route_path)).exists():
                errors.append(f"legacy alternate map route target is missing: {route_path}")

        if status not in LEGACY_ALTERNATE_STATUSES:
            errors.append(f"legacy alternate map entry {index} has unsupported status: {status}")

    for required in [
        "RunGroupMeetings.vbs",
        "RunInductionMailer.vbs",
        "OutlookWatchdog.vbs",
        "ValidateWorkflow.vbs",
    ]:
        if required not in seen_scaffold_paths:
            errors.append(f"legacy alternate map missing scaffold wrapper: {required}")

    return errors


def validate(root: Path) -> list[str]:
    root = root.resolve()
    errors: list[str] = []
    errors.extend(validate_workflow_schema(root))
    errors.extend(validate_dispatch_states(root))
    errors.extend(validate_csv_headers(root))
    errors.extend(validate_manifest_template_paths(root, "examples/workbooks/induction_template_manifest_example.csv"))
    errors.extend(validate_manifest_template_paths(root, "vbs/tests/fixtures/induction_template_manifest_fixture.csv"))
    errors.extend(validate_sanitisation(root))
    errors.extend(validate_generated_artifacts(root))
    errors.extend(validate_legacy_alternate_map(root))
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Office communication scaffold contracts and examples.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()

    errors = validate(args.root)
    if errors:
        for error in errors:
            print(f"FAILED: {error}")
        return 1

    print("Validation passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
