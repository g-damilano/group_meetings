﻿# Local Legacy Mirror

This directory is a private, local hard-copy mirror of repository material outside scaffold/.

It is copy-only migration reference material. It is excluded from public scaffold validation and release manifests, ignored by scaffold/.gitignore, and must not be wired into runtime entrypoints.

Do not publish this directory without a separate explicit sanitisation pass.
