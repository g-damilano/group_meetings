'======================================================================
' mail_utils_utf8_shield_v2.vbs — Outlook Mail Utility (UTF‑8 Shield v2)
' Simplified single-pass repair logic with better detection.
'======================================================================
Option Explicit
SetLocale 1033

Const olMailItem = 0
Const olFormatHTML = 2
Const olMSG = 3
Const PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"

Function CreateMail(toAddr, ccAddr, bccAddr, subjectText, htmlBody, attachPaths, _
                    action, savePath, templateSource, inlineImgFolder, deferMinutes, logPath)
  On Error Resume Next
  EncodingHealthCheck logPath

  Dim ok, olApp, olMail, sigHTML, f, fso, bodyHtml
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set olApp = GetOutlookApp()

  If Len(Trim(templateSource)) > 0 Then
    bodyHtml = LoadHtmlFromSource(templateSource)
  Else
    bodyHtml = htmlBody
  End If

  subjectText = FixEncoding(subjectText)
  bodyHtml    = FixEncoding(bodyHtml)

  Set olMail = olApp.CreateItem(olMailItem)
  sigHTML = LoadSignatureWithImages(olMail)

  With olMail
    .To = FixEncoding(toAddr)
    .CC = FixEncoding(ccAddr)
    .BCC = FixEncoding(bccAddr)
    .Subject = subjectText
    .BodyFormat = olFormatHTML
    .HTMLBody = "<html><body style='font-family:Segoe UI, Arial, sans-serif;'>" & bodyHtml & sigHTML & "</body></html>"

    If Not IsEmpty(attachPaths) Then
      For Each f In attachPaths
        If Len(Trim(f)) > 0 And fso.FileExists(f) Then .Attachments.Add f
      Next
    End If

    If Len(Trim(inlineImgFolder)) > 0 And fso.FolderExists(inlineImgFolder) Then
      EmbedImagesFromFolder olMail, inlineImgFolder
    End If

    If IsNumeric(deferMinutes) And CDbl(deferMinutes) > 0 Then
      .DeferredDeliveryTime = Now + (CDbl(deferMinutes) / (24 * 60))
    End If

    Select Case LCase(action)
      Case "send"   : .Send : LogAction logPath, "Sent: " & subjectText
      Case "save"
        If Len(Trim(savePath)) > 0 Then
          .SaveAs savePath, olMSG : LogAction logPath, "Saved as: " & savePath
        Else
          .Save : LogAction logPath, "Saved to Drafts: " & subjectText
        End If
      Case Else     : .Display : LogAction logPath, "Displayed: " & subjectText
    End Select
  End With

  If Err.Number <> 0 Then
    LogAction logPath, "ERROR: " & Err.Number & " - " & Err.Description
    ok = False
  Else
    ok = True
  End If

  CreateMail = ok
  On Error GoTo 0
End Function

'--- UTF‑8 Shield ---
Function FixEncoding(text)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncoding = text
    Exit Function
  End If
  ' Only repair obvious UTF‑8‑as‑Latin‑1 patterns
  If (InStr(text, "Ã") = 0) And (InStr(text, "â") = 0) And (InStr(text, "�") = 0) Then
    FixEncoding = text
    Exit Function
  End If
  FixEncoding = ReinterpretUtf8(text)
End Function

Function ReinterpretUtf8(badText)
  On Error Resume Next
  Dim s, bin, out
  Set s = CreateObject("ADODB.Stream")
  s.Type = 2 : s.Charset = "iso-8859-1" : s.Open
  s.WriteText badText
  s.Position = 0 : s.Type = 1 : bin = s.Read : s.Close
  s.Open : s.Type = 1 : s.Write bin
  s.Position = 0 : s.Type = 2 : s.Charset = "utf-8"
  out = s.ReadText : s.Close
  If Err.Number <> 0 Or Len(out) = 0 Then out = badText
  ReinterpretUtf8 = out
  On Error GoTo 0
End Function

Sub EncodingHealthCheck(logPath)
  Dim probe, result
  probe = ChrW(&H2713)
  result = FixEncoding(probe)
  If result <> probe Then
    LogAction logPath, "Encoding warning: auto-repair active."
  Else
    LogAction logPath, "Encoding OK."
  End If
End Sub

Sub EmbedImagesFromFolder(olMail, folderPath)
  Dim fso, file, cid, att
  Set fso = CreateObject("Scripting.FileSystemObject")
  For Each file In fso.GetFolder(folderPath).Files
    cid = fso.GetFileName(file.Name)
    Set att = olMail.Attachments.Add(file.Path)
    att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
  Next
End Sub

Function GetOutlookApp()
  Dim app
  On Error Resume Next
  Set app = GetObject(, "Outlook.Application")
  If Err.Number <> 0 Then
    Err.Clear
    Set app = CreateObject("Outlook.Application")
  End If
  On Error GoTo 0
  Set GetOutlookApp = app
End Function

Function LoadSignatureWithImages(olMail)
  Dim fso, shell, sigPath, folder, file, sigHTML, sigFile, baseName, imgFolder, imgFile, att, imgName, cid
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set shell = CreateObject("WScript.Shell")
  sigPath = shell.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\Signatures\"
  sigHTML = ""

  If fso.FolderExists(sigPath) Then
    Set folder = fso.GetFolder(sigPath)
    For Each file In folder.Files
      If LCase(fso.GetExtensionName(file.Name)) = "htm" Then
        sigFile = file.Path
        baseName = fso.GetBaseName(file.Name)
        sigHTML = ReadUTF8File(sigFile)
        Exit For
      End If
    Next
  End If

  imgFolder = sigPath & baseName & ".files"
  If fso.FolderExists(imgFolder) Then
    For Each imgFile In fso.GetFolder(imgFolder).Files
      imgName = fso.GetFileName(imgFile.Name)
      cid = Replace(imgName, " ", "_")
      Set att = olMail.Attachments.Add(imgFile.Path)
      att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
      sigHTML = Replace(sigHTML, baseName & ".files/" & imgName, "cid:" & cid)
      sigHTML = Replace(sigHTML, baseName & ".files\" & imgName, "cid:" & cid)
    Next
  End If

  LoadSignatureWithImages = sigHTML
End Function

Function ReadUTF8File(filePath)
  Dim s : Set s = CreateObject("ADODB.Stream")
  s.Type = 2 : s.Charset = "utf-8" : s.Open : s.LoadFromFile filePath
  ReadUTF8File = s.ReadText : s.Close
End Function

Function LoadHtmlFromSource(src)
  Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
  If Left(LCase(src), 7) = "http://" Or Left(LCase(src), 8) = "https://" Then
    LoadHtmlFromSource = HttpGetUtf8(src)
  ElseIf fso.FileExists(src) Then
    LoadHtmlFromSource = ReadUTF8File(src)
  Else
    LoadHtmlFromSource = src
  End If
End Function

Function HttpGetUtf8(url)
  Dim xhr, stm, txt
  Set xhr = CreateObject("MSXML2.XMLHTTP")
  xhr.Open "GET", url, False
  xhr.Send
  If xhr.Status = 200 Then
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 1 : stm.Open : stm.Write xhr.responseBody
    stm.Position = 0 : stm.Type = 2 : stm.Charset = "utf-8"
    txt = stm.ReadText : stm.Close
    HttpGetUtf8 = txt
  Else
    HttpGetUtf8 = "<p>Failed to load template. HTTP " & xhr.Status & "</p>"
  End If
End Function

Sub LogAction(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then Exit Sub
  Dim fso, f : Set fso = CreateObject("Scripting.FileSystemObject")
  Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
End Sub
