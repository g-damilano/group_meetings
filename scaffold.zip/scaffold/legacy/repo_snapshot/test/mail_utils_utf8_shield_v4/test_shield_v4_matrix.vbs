' test_shield_v4_matrix.vbs
Option Explicit
SetLocale 1033
Dim s, arr, i, subj, html, files, ok
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_utf8_shield_v4.vbs",1).ReadAll

arr = Array( _
"1) å ä ö é è ê ë", _
"2) ć č š ž ř ů", _
"3) ñ á í ó ú", _
"4) ß Ä Ö Ü", _
"5) œ ç é à", _
"6) — – “ ” ‘ ’", _
"7) € £ ¥", _
"8) Mixed: Voilà señor Großzügig", _
"9) Greek: α β γ Δ", _
"10) Cyrillic: Привет" _
)

html = "<h3>Shield v4 Mapping Test</h3>"
For i = 0 To UBound(arr)
  html = html & "<p>" & arr(i) & "</p>"
Next

files = Array()
subj = "Shield v4 Mapping " & ChrW(&H2013) & " Normal"
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, "C:\Temp\mail_util.log")

' Now mojibake version for comparison
html = "<h3>Shield v4 Mapping (Mojibake)</h3>" & _
"<p>Ã¥ Ã¤ Ã¶ Ã© Ã¨ Ãª Ã«</p><p>Ä‡ Ä� Å¡ Å¾ Å™ Å¯</p><p>Ã± Ã¡ Ã­ Ã³ Ãº</p><p>ÃŸ Ã„ Ã– Ãœ</p>" & _
"<p>Å“ Ã§ Ã© Ã  </p><p>â€” â€“ â€œ â€� â€˜ â€™</p><p>â‚¬ Â£ Â¥</p><p>VoilÃ  seÃ±or GroÃŸzÃ¼gig</p>"
subj = "Shield v4 Mapping " & ChrW(&H2013) & " Repair"
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, "C:\Temp\mail_util.log")
