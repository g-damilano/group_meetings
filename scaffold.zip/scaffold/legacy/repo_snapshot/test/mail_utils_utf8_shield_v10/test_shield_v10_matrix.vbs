' test_shield_v10_matrix.vbs
Option Explicit
SetLocale 1033
Dim subj, html, files, ok, i, logPath
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_utf8_shield_v10.vbs",1).ReadAll

logPath = ""

' Normal strings
Dim normal()
ReDim normal(9)
normal(0) = "1) " & ChrW(&HE5) & " " & ChrW(&HE4) & " " & ChrW(&HF6) & " " & ChrW(&HE9) & " " & ChrW(&HE8) & " " & ChrW(&HEA) & " " & ChrW(&HEB)
normal(1) = "2) " & ChrW(&H107) & " " & ChrW(&H10D) & " " & ChrW(&H161) & " " & ChrW(&H17E) & " " & ChrW(&H159) & " " & ChrW(&H16F)
normal(2) = "3) " & ChrW(&HF1) & " " & ChrW(&HE1) & " " & ChrW(&HED) & " " & ChrW(&HF3) & " " & ChrW(&HFA)
normal(3) = "4) " & ChrW(&HDF) & " " & ChrW(&HC4) & " " & ChrW(&HD6) & " " & ChrW(&HDC)
normal(4) = "5) " & ChrW(&H153) & " " & ChrW(&HE7) & " " & ChrW(&HE9) & " " & ChrW(&HE0)
normal(5) = "6) " & ChrW(&H2014) & " " & ChrW(&H2013) & " " & ChrW(&H201C) & " " & ChrW(&H201D) & " " & ChrW(&H2018) & " " & ChrW(&H2019)
normal(6) = "7) " & ChrW(&H20AC) & " " & ChrW(&HA3) & " " & ChrW(&HA5)
normal(7) = "8) Mixed: " & "Voil" & ChrW(&HE0) & " se" & ChrW(&HF1) & "or Gro" & ChrW(&HDF) & "z" & ChrW(&HFC) & "gig"
normal(8) = "9) Greek: " & ChrW(&H3B1) & " " & ChrW(&H3B2) & " " & ChrW(&H3B3) & " " & ChrW(&H394)
normal(9) = "10) Cyrillic: " & ChrW(&H41F) & ChrW(&H440) & ChrW(&H438) & ChrW(&H432) & ChrW(&H435) & ChrW(&H442)

html = "<h3>Shield v10 Mapping Test (Normal)</h3>"
For i = 0 To UBound(normal)
  html = html & "<p>" & normal(i) & "</p>"
Next

files = Array()
subj = "Shield v10 Mapping " & ChrW(&H2013) & " Normal"
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)

' Mojibake strings (deep-layer to trigger iterative repair)
Dim moj()
ReDim moj(9)
moj(0) = "1) ÃƒÆ’Ã‚Â¥ ÃƒÆ’Ã‚Â¤ ÃƒÆ’Ã‚Â¶ ÃƒÆ’Ã‚Â© ÃƒÆ’Ã‚Â¨ ÃƒÆ’Ã‚Âª ÃƒÆ’Ã‚Â«"
moj(1) = "2) Ã„â€¡ Ã„â� Ã…Â¡ Ã…Â¾ Ã…â„¢ Ã…Â¯"
moj(2) = "3) ÃƒÆ’Ã‚Â± ÃƒÆ’Ã‚Â¡ ÃƒÆ’Ã‚Â­ ÃƒÆ’Ã‚Â³ ÃƒÆ’Ã‚Âº"
moj(3) = "4) ÃƒÅ¸ Ãƒâ€ž Ãƒâ€“ ÃƒÅ“"
moj(4) = "5) Ã…â€œ ÃƒÂ§ ÃƒÂ© Ãƒ "
moj(5) = "6) â€” â€“ â€œ â€� â€˜ â€™"
moj(6) = "7) â‚¬ Â£ Â¥"
moj(7) = "8) VoilÃƒ  seÃƒÂ±or GroÃƒÅ¸zÃƒÂ¼gig"
moj(8) = "9) Greek: Î± Î² Î³ Î”"
moj(9) = "10) Cyrillic: ÐŸÑ€Ð¸Ð²ÐµÑ‚"

html = "<h3>Shield v10 Mapping Test (Mojibake)</h3>"
For i = 0 To UBound(moj)
  html = html & "<p>" & moj(i) & "</p>"
Next

subj = "Shield v10 Mapping " & ChrW(&H2013) & " Repair"
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)
