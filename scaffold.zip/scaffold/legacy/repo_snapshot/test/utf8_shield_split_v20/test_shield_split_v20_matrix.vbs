' test_shield_split_v20_matrix.vbs
Option Explicit
SetLocale 1033
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_mailer_v20.vbs",1).ReadAll

Dim files, subj, html, ok, logPath, nbsp
logPath = ""
subj = "Shield Split v20 — Wide Mapping Panel"
nbsp = ChrW(160)

Dim lines, i, row
lines = Array( _
  "A) Ãƒ" & nbsp & " -> should become à", _
  "B) Ã" & nbsp & " -> should become à", _
  "C) VoilÃ" & nbsp & " -> Voilà", _
  "D) â€ Hello (bare opener) -> “ Hello", _
  "E) ÃƒÂ©, ÃƒÂ±, ÃƒÂ  should become é, ñ, à", _
  "F) ÃƒÂ© + Î±Î²Î³ + ÐŸÑ€Ð¸Ð²ÐµÑ‚ mixed", _
  "G) â€” â€“ â€œ â€� â€˜ â€™ punctuation", _
  "H) Ã¢â€šÂ¬, Ã‚Â£, Ã‚Â¥ currencies", _
  "I) ÃƒÂ± and clean Привет stay intact", _
  "J) VoilÃ -> Voilà (no trailing space)" _
)

html = "<h3>Shield v20 Wide Mapping Matrix</h3>"
For i = 0 To UBound(lines)
  row = lines(i)
  html = html & "<p>" & row & "</p>"
Next

files = Array()
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)
