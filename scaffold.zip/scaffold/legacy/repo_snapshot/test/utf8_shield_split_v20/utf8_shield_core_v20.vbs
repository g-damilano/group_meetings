'======================================================================
' utf8_shield_core_v20.vbs — UTF‑8 Repair Shield (Stratified Engine)
'----------------------------------------------------------------------
' Pipeline (stratified):
'  L0  Detect markers, scrub BOMs
'  L1  Pre‑maps (punctuation/currencies) — idempotent
'  L2  CopyTo (Win‑1252 bytes → UTF‑8 text) — v9 core
'  L3  Alt decode probes (round‑trip variants) if markers persist
'  L4  Orphan fixes (NBSP/space Ã/Ãƒ), Voilà heuristic, bare openers
'  L5  Post‑maps (quotes/dashes/currencies) + space normalization
'  L6  Convergence control (marker count, delta check, stall limit)
'----------------------------------------------------------------------
Option Explicit
SetLocale 1033

'================== Public API ==================
Function FixEncoding(text, logPath)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncoding = text
    Exit Function
  End If

  Dim s, i, before, after, prev, m0, m1, changed, stalls
  s = CStr(text)

  ' L0: scrub and detect
  s = StripBomGlyphs(s)
  m0 = MarkerCount(s)
  LogShield logPath, "v20 start — markers=" & m0

  ' Early exit if clean
  If m0 = 0 Then
    FixEncoding = s
    Exit Function
  End If

  ' L1: pre‑maps
  s = HardMapPre(s)

  ' Iterative convergence
  stalls = 0
  Dim MAX_PASSES: MAX_PASSES = 6
  For i = 1 To MAX_PASSES
    before = Left(s, 180)

    ' L2: primary CopyTo
    s = Reinterpret_W1252_to_UTF8_CopyTo(s)

    ' L3: alt decode probes if still looks mojibake
    If LooksLikeUtf8AsWin1252(s) Then
      s = AltDecodeProbe(s)
    End If

    ' L4: orphans / Voilà / openers
    s = FixOrphanPairs(s)

    ' L5: post‑maps + normalize
    s = HardMapPost(s)
    s = NormalizeSpaces(s)

    after = Left(s, 180)
    m1 = MarkerCount(s)
    LogShield logPath, "Pass " & i & " BEFORE: " & before
    LogShield logPath, "Pass " & i & " AFTER : " & after & " | markers=" & m1

    If m1 = 0 Then Exit For

    If prev = s Then
      stalls = stalls + 1
      If stalls >= 2 Then
        LogShield logPath, "Convergence stalled. Breaking."
        Exit For
      End If
    Else
      stalls = 0
    End If
    prev = s
  Next

  FixEncoding = s
End Function

'================== Detection & Metrics ==================
Function LooksLikeUtf8AsWin1252(s)
  LooksLikeUtf8AsWin1252 = _
      (InStr(s, "Ã") > 0) Or (InStr(s, "Â") > 0) Or _
      (InStr(s, "â€”") > 0) Or (InStr(s, "â€“") > 0) Or _
      (InStr(s, "â€œ") > 0) Or (InStr(s, "â€�") > 0) Or _
      (InStr(s, "â€˜") > 0) Or (InStr(s, "â€™") > 0) Or _
      (InStr(s, "â€¦") > 0) Or (InStr(s, "â„¢") > 0) Or _
      (InStr(s, "ï»¿") > 0) Or _
      (InStr(s, "Ð") > 0 And InStr(s, "Ñ") > 0) Or (InStr(s, "Î") > 0)
End Function

Function MarkerCount(s)
  Dim c: c = 0
  c = c + CountOf(s, "Ã")
  c = c + CountOf(s, "Â")
  c = c + CountOf(s, "â€”") + CountOf(s, "â€“") + CountOf(s, "â€œ") + CountOf(s, "â€�") + CountOf(s, "â€˜") + CountOf(s, "â€™") + CountOf(s, "â€¦") + CountOf(s, "â„¢")
  c = c + CountOf(s, "ï»¿")
  MarkerCount = c
End Function

Function CountOf(s, token)
  Dim p, n: p = 1: n = 0
  Do
    p = InStr(p, s, token)
    If p = 0 Then Exit Do
    n = n + 1
    p = p + Len(token)
  Loop
  CountOf = n
End Function

'================== Maps & Normalization ==================
Function HardMapPre(s)
  s = Replace(s, "â€“", "–")
  s = Replace(s, "â€”", "—")
  s = Replace(s, "â€˜", "‘")
  s = Replace(s, "â€™", "’")
  s = Replace(s, "â€œ", "“")
  s = Replace(s, "â€�", "”")
  s = Replace(s, "â€¦", "…")
  s = Replace(s, "â‚¬", "€")
  s = Replace(s, "Â£", "£")
  s = Replace(s, "Â¥", "¥")
  s = Replace(s, "â„¢", "™")
  HardMapPre = s
End Function

Function HardMapPost(s)
  s = Replace(s, "â€“", "–")
  s = Replace(s, "â€”", "—")
  s = Replace(s, "â€˜", "‘")
  s = Replace(s, "â€™", "’")
  s = Replace(s, "â€œ", "“")
  s = Replace(s, "â€�", "”")
  s = Replace(s, "â€¦", "…")
  s = Replace(s, "â‚¬", "€")
  s = Replace(s, "Â£", "£")
  s = Replace(s, "Â¥", "¥")
  s = Replace(s, "â„¢", "™")
  HardMapPost = s
End Function

Function NormalizeSpaces(s)
  Dim nbsp: nbsp = ChrW(160)
  Dim k: For k = 1 To 3: s = Replace(s, "  ", " "): Next
  s = Replace(s, nbsp, " ")
  NormalizeSpaces = s
End Function

'================== Orphans / Voilà / Openers ==================
Function FixOrphanPairs(s)
  Dim nbsp: nbsp = ChrW(160)

  ' Ã/Ãƒ with NBSP or space → à
  s = Replace(s, "Ãƒ" & nbsp, "à")
  s = Replace(s, "Ã" & nbsp, "à")
  s = Replace(s, "Ãƒ ", "à")
  s = Replace(s, "Ã ", "à")
  s = Replace(s, "ÃƒÂ " , "à")
  s = Replace(s, "ÃÂ "  , "à")
  s = Replace(s, "ÃƒÂ" & nbsp, "à")
  s = Replace(s, "ÃÂ" & nbsp , "à")

  ' Voilà variants
  s = RegexReplaceVoila(s)

  ' Bare opener â€ → “
  s = Replace(s, "â€ ", "“ ")
  s = Replace(s, " â€", " “")
  s = Replace(s, "â€", "“")

  FixOrphanPairs = s
End Function

Function RegexReplaceVoila(s)
  On Error Resume Next
  Dim nbsp: nbsp = ChrW(160)
  Dim re: Set re = CreateObject("VBScript.RegExp")
  re.Global = True: re.IgnoreCase = False
  re.Pattern = "VoilÃ(" & nbsp & "| |$)"
  RegexReplaceVoila = re.Replace(s, "Voilà$1")
  If Err.Number <> 0 Then RegexReplaceVoila = s
End Function

'================== Alternate decode probes ==================
' Try a couple of benign re‑interpretations in case CopyTo alone stalls.
Function AltDecodeProbe(s)
  Dim t
  t = s
  ' Probe A: treat current text as UTF‑8 bytes re‑read as 1252 and back
  t = Utf8BytesTo1252TextToUtf8(t)
  ' If improved (marker count decreased), take it
  If MarkerCount(t) < MarkerCount(s) Then
    AltDecodeProbe = t
    Exit Function
  End If
  ' Probe B: 1252 bytes → UTF‑8 (again) to catch layered chunks
  t = Reinterpret_W1252_to_UTF8_CopyTo(s)
  If MarkerCount(t) <= MarkerCount(s) Then
    AltDecodeProbe = t
  Else
    AltDecodeProbe = s
  End If
End Function

Function Utf8BytesTo1252TextToUtf8(txt)
  On Error Resume Next
  Dim a, b, out
  Set a = CreateObject("ADODB.Stream")
  a.Type = 2: a.Charset = "utf-8": a.Open
  a.WriteText txt
  a.Position = 0: a.Type = 1 ' bytes

  Set b = CreateObject("ADODB.Stream")
  b.Type = 1: b.Open
  a.CopyTo b

  b.Position = 0: b.Type = 2: b.Charset = "windows-1252"
  out = b.ReadText

  a.Close: b.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = txt
  Utf8BytesTo1252TextToUtf8 = out
End Function

'================== Core reinterpretation (v9) ==================
Function Reinterpret_W1252_to_UTF8_CopyTo(badText)
  On Error Resume Next
  Dim sIn, sOut, out
  Set sIn = CreateObject("ADODB.Stream")
  sIn.Type = 2: sIn.Charset = "windows-1252": sIn.Open
  sIn.WriteText badText
  sIn.Position = 0: sIn.Type = 1

  Set sOut = CreateObject("ADODB.Stream")
  sOut.Type = 1: sOut.Open
  sIn.CopyTo sOut

  sOut.Position = 0: sOut.Type = 2: sOut.Charset = "utf-8"
  out = sOut.ReadText

  sIn.Close: sOut.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = badText
  Reinterpret_W1252_to_UTF8_CopyTo = out
End Function

'================== Logging ==================
Function ShieldDefaultLogPath()
  On Error Resume Next
  Dim fso, scriptFolder
  Set fso = CreateObject("Scripting.FileSystemObject")
  scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
  If Len(scriptFolder) = 0 Then scriptFolder = "."
  ShieldDefaultLogPath = scriptFolder & "\mail_util.log"
  On Error GoTo 0
End Function

Sub LogShield(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = ShieldDefaultLogPath()
  Dim fso, f: Set fso = CreateObject("Scripting.FileSystemObject")
  Dim ts: Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
  On Error GoTo 0
End Sub
