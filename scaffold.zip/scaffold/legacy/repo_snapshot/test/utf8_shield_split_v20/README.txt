UTF‑8 Shield Split v20 — Stratified Engine
===========================================

What’s new
----------
• **Stratified pipeline** (L0–L6) with convergence & stall control.
• v9 CopyTo remains the core; added **AltDecodeProbe** for layered shards.
• Hard pre/post maps for punctuation/currencies to catch stragglers.
• Stronger NBSP‑aware orphan repairs + Voilà variants + bare opener fix.
• Explicit UTF‑8 <meta> in mailer; detailed markers per pass.

Files
-----
1) utf8_shield_core_v20.vbs
2) mail_utils_mailer_v20.vbs
3) test_shield_split_v20_normal.vbs
4) test_shield_split_v20_repair.vbs
5) test_shield_split_v20_matrix.vbs

Usage
-----
• Place all files in the same folder.
• Run matrix/repair tests; review mail_util.log for markers & convergence.
• If a stubborn case remains, copy the exact snippet + log line; I’ll add a micro‑rule.
