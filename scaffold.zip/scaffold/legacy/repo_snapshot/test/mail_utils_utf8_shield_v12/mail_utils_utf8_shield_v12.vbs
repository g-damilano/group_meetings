'======================================================================
' mail_utils_utf8_shield_v12.vbs — Outlook Mail Utility (UTF‑8 Shield v12)
' - Robust multi-layer repair with enforced byte re-feed per pass
' - Node-scoped decoding with **correct HTML reassembly**
' - Win-1252 bytes → UTF-8 text via CopyTo; repeated per node (up to 7 passes)
' - Marker-count diagnostics, stall detection, and per-node logs
' - BOM scrubbing each pass
' - Logs to mail_util.log in the same folder as the running .vbs (default)
' - All mail features retained (signature images, attachments, template loading, delayed send)
'======================================================================
Option Explicit
SetLocale 1033

Const olMailItem = 0
Const olFormatHTML = 2
Const olMSG = 3
Const PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"

Function CreateMail(toAddr, ccAddr, bccAddr, subjectText, htmlBody, attachPaths, _
                    action, savePath, templateSource, inlineImgFolder, deferMinutes, logPath)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = DefaultLogPath()
  LogAction logPath, "Encoding Shield v12 active."

  Dim ok, olApp, olMail, sigHTML, f, fso, bodyHtml
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set olApp = GetOutlookApp()

  If Len(Trim(templateSource)) > 0 Then
    bodyHtml = LoadHtmlFromSource(templateSource)
  Else
    bodyHtml = htmlBody
  End If

  subjectText = FixEncodingScalar(subjectText, logPath)
  bodyHtml    = FixEncodingHtmlTextNodes(bodyHtml, logPath)

  Set olMail = olApp.CreateItem(olMailItem)
  sigHTML = LoadSignatureWithImages(olMail)

  With olMail
    .To = FixEncodingScalar(toAddr, logPath)
    .CC = FixEncodingScalar(ccAddr, logPath)
    .BCC = FixEncodingScalar(bccAddr, logPath)
    .Subject = subjectText
    .BodyFormat = olFormatHTML
    .HTMLBody = "<html><body style='font-family:Segoe UI, Arial, sans-serif;'>" & bodyHtml & sigHTML & "</body></html>"

    If Not IsEmpty(attachPaths) Then
      For Each f In attachPaths
        If Len(Trim(f)) > 0 And fso.FileExists(f) Then .Attachments.Add f
      Next
    End If

    If Len(Trim(inlineImgFolder)) > 0 And fso.FolderExists(inlineImgFolder) Then
      EmbedImagesFromFolder olMail, inlineImgFolder
    End If

    If IsNumeric(deferMinutes) And CDbl(deferMinutes) > 0 Then
      .DeferredDeliveryTime = Now + (CDbl(deferMinutes) / (24 * 60))
    End If

    Select Case LCase(action)
      Case "send"   : .Send : LogAction logPath, "Sent: " & subjectText
      Case "save"
        If Len(Trim(savePath)) > 0 Then
          .SaveAs savePath, olMSG : LogAction logPath, "Saved as: " & savePath
        Else
          .Save : LogAction logPath, "Saved to Drafts: " & subjectText
        End If
      Case Else     : .Display : LogAction logPath, "Displayed: " & subjectText
    End Select
  End With

  If Err.Number <> 0 Then
    LogAction logPath, "ERROR: " & Err.Number & " - " & Err.Description
    ok = False
  Else
    ok = True
  End If

  CreateMail = ok
  On Error GoTo 0
End Function

'================== UTF‑8 Shield (v12) ==================
Function FixEncodingHtmlTextNodes(html, logPath)
  If IsNull(html) Or IsEmpty(html) Then
    FixEncodingHtmlTextNodes = html
    Exit Function
  End If

  Dim re, mc, m, lastPos, result, inner, fixedInner, mcountBefore, mcountAfter
  Dim originalLen, rebuiltLen
  originalLen = Len(html)

  Set re = CreateObject("VBScript.RegExp")
  re.Global = True
  re.MultiLine = True
  re.Pattern = ">([^<]+)<" ' match text between tags (no nested '<')

  Set mc = re.Execute(html)
  lastPos = 1
  result = ""

  For Each m In mc
    ' Append content before the match (excluding the match start)
    result = result & Mid(html, lastPos, m.FirstIndex - lastPos)
    inner = m.SubMatches(0)

    mcountBefore = MarkerCount(inner)
    If mcountBefore > 0 Then
      LogAction logPath, "Node fix start. Markers: " & mcountBefore & " | Snip: " & Left(inner, 80)
      fixedInner = FixEncodingScalar(inner, logPath)
      mcountAfter = MarkerCount(fixedInner)
      LogAction logPath, "Node fix end. Markers: " & mcountAfter & " | Snip: " & Left(fixedInner, 80)
    Else
      fixedInner = inner
    End If

    ' Reinsert the full node as >fixed< (replace entire match cleanly)
    result = result & ">" & fixedInner & "<"

    ' Advance lastPos to the character right after the match
    lastPos = m.FirstIndex + m.Length
  Next

  ' Append the remaining tail after the last match
  result = result & Mid(html, lastPos)

  rebuiltLen = Len(result)
  ' Safety: if the rebuilt HTML is wildly different, fall back to original
  If originalLen > 0 Then
    If Abs(rebuiltLen - originalLen) / originalLen > 0.1 Then
      LogAction logPath, "HTML rebuild delta too large. Reverting to original body."
      FixEncodingHtmlTextNodes = html
      Exit Function
    End If
  End If

  FixEncodingHtmlTextNodes = result
End Function

Function FixEncodingScalar(text, logPath)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncodingScalar = text
    Exit Function
  End If

  Dim s, i, before, after, prev, mcount, stalled
  s = CStr(text)
  s = StripBomGlyphs(s)
  mcount = MarkerCount(s)
  If mcount = 0 Then
    FixEncodingScalar = s
    Exit Function
  End If

  LogAction logPath, "Scalar fix. Initial markers: " & mcount & " | Snip: " & Left(s, 100)
  stalled = 0
  For i = 1 To 7
    prev = s
    before = Left(s, 120)
    s = Reinterpret_W1252_to_UTF8_Refeed(s)
    s = StripBomGlyphs(s)
    after = Left(s, 120)
    LogAction logPath, "Scalar pass " & i & " BEFORE: " & before
    LogAction logPath, "Scalar pass " & i & " AFTER : " & after
    If s = prev Then
      stalled = stalled + 1
    Else
      stalled = 0
    End If
    mcount = MarkerCount(s)
    LogAction logPath, "Scalar markers after pass " & i & ": " & mcount
    If mcount = 0 Then Exit For
    If stalled >= 2 Then
      LogAction logPath, "Scalar stalled (no change in two consecutive passes)."
      Exit For
    End If
  Next
  FixEncodingScalar = s
End Function

Function MarkerCount(s)
  Dim c: c = 0
  c = c + CountOf(s, "Ã")
  c = c + CountOf(s, "Â")
  c = c + CountOf(s, "â€”")
  c = c + CountOf(s, "â€“")
  c = c + CountOf(s, "â€œ")
  c = c + CountOf(s, "â€�")
  c = c + CountOf(s, "â€˜")
  c = c + CountOf(s, "â€™")
  c = c + CountOf(s, "ï»¿")
  c = c + CountOf(s, "Ð")
  c = c + CountOf(s, "Ñ")
  c = c + CountOf(s, "Î")
  MarkerCount = c
End Function

Function CountOf(s, token)
  Dim pos, cnt, startAt, tlen
  tlen = Len(token)
  If tlen = 0 Then CountOf = 0 : Exit Function
  cnt = 0 : startAt = 1
  Do
    pos = InStr(startAt, s, token)
    If pos = 0 Then Exit Do
    cnt = cnt + 1
    startAt = pos + tlen
  Loop
  CountOf = cnt
End Function

Function StripBomGlyphs(s)
  s = Replace(s, "ï»¿", "")
  Dim feff: feff = ChrW(&HFEFF)
  s = Replace(s, feff, "")
  StripBomGlyphs = s
End Function

' Reinterpret with enforced re-feed to bytes each pass
Function Reinterpret_W1252_to_UTF8_Refeed(badText)
  On Error Resume Next
  Dim sIn, sMid, sOut, out
  ' Encode Unicode text as Win-1252 bytes
  Set sIn = CreateObject("ADODB.Stream")
  sIn.Type = 2
  sIn.Charset = "windows-1252"
  sIn.Open
  sIn.WriteText badText
  sIn.Position = 0
  sIn.Type = 1  ' binary

  ' Copy raw bytes into a fresh binary stream (mid)
  Set sMid = CreateObject("ADODB.Stream")
  sMid.Type = 1
  sMid.Open
  sIn.CopyTo sMid

  ' Now decode those bytes as UTF-8 into text
  sMid.Position = 0
  sMid.Type = 2
  sMid.Charset = "utf-8"
  out = sMid.ReadText

  ' Safety micro re-feed for stubborn residuals
  If MarkerCount(out) > 0 Then
    Set sOut = CreateObject("ADODB.Stream")
    sOut.Type = 2
    sOut.Charset = "windows-1252"
    sOut.Open
    sOut.WriteText out
    sOut.Position = 0
    sOut.Type = 1
    sMid.Position = 0
    sMid.Type = 1
    sMid.SetEOS
    sOut.CopyTo sMid
    sMid.Position = 0
    sMid.Type = 2
    sMid.Charset = "utf-8"
    out = sMid.ReadText
    sOut.Close
  End If

  sIn.Close
  sMid.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = badText
  Reinterpret_W1252_to_UTF8_Refeed = out
  On Error GoTo 0
End Function
'=======================================================

'--- Helpers ---
Sub EmbedImagesFromFolder(olMail, folderPath)
  Dim fso, file, cid, att
  Set fso = CreateObject("Scripting.FileSystemObject")
  For Each file In fso.GetFolder(folderPath).Files
    cid = fso.GetFileName(file.Name)
    Set att = olMail.Attachments.Add(file.Path)
    att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
  Next
End Sub

Function GetOutlookApp()
  Dim app
  On Error Resume Next
  Set app = GetObject(, "Outlook.Application")
  If Err.Number <> 0 Then
    Err.Clear
    Set app = CreateObject("Outlook.Application")
  End If
  On Error GoTo 0
  Set GetOutlookApp = app
End Function

Function LoadSignatureWithImages(olMail)
  Dim fso, shell, sigPath, folder, file, sigHTML, sigFile, baseName, imgFolder, imgFile, att, imgName, cid
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set shell = CreateObject("WScript.Shell")
  sigPath = shell.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\Signatures\"
  sigHTML = ""

  If fso.FolderExists(sigPath) Then
    Set folder = fso.GetFolder(sigPath)
    For Each file In folder.Files
      If LCase(fso.GetExtensionName(file.Name)) = "htm" Then
        sigFile = file.Path
        baseName = fso.GetBaseName(file.Name)
        sigHTML = ReadUTF8File(sigFile)
        Exit For
      End If
    Next
  End If

  imgFolder = sigPath & baseName & ".files"
  If fso.FolderExists(imgFolder) Then
    For Each imgFile In fso.GetFolder(imgFolder).Files
      imgName = fso.GetFileName(imgFile.Name)
      cid = Replace(imgName, " ", "_")
      Set att = olMail.Attachments.Add(imgFile.Path)
      att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
      sigHTML = Replace(sigHTML, baseName & ".files/" & imgName, "cid:" & cid)
      sigHTML = Replace(sigHTML, baseName & ".files\" & imgName, "cid:" & cid)
    Next
  End If

  LoadSignatureWithImages = sigHTML
End Function

Function ReadUTF8File(filePath)
  Dim s : Set s = CreateObject("ADODB.Stream")
  s.Type = 2 : s.Charset = "utf-8" : s.Open : s.LoadFromFile filePath
  ReadUTF8File = s.ReadText : s.Close
End Function

Function LoadHtmlFromSource(src)
  Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
  If Left(LCase(src), 7) = "http://" Or Left(LCase(src), 8) = "https://" Then
    LoadHtmlFromSource = HttpGetUtf8(src)
  ElseIf fso.FileExists(src) Then
    LoadHtmlFromSource = ReadUTF8File(src)
  Else
    LoadHtmlFromSource = src
  End If
End Function

Function HttpGetUtf8(url)
  Dim xhr, stm, txt
  Set xhr = CreateObject("MSXML2.XMLHTTP")
  xhr.Open "GET", url, False
  xhr.Send
  If xhr.Status = 200 Then
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 1 : stm.Open : stm.Write xhr.responseBody
    stm.Position = 0 : stm.Type = 2 : stm.Charset = "utf-8"
    txt = stm.ReadText : stm.Close
    HttpGetUtf8 = txt
  Else
    HttpGetUtf8 = "<p>Failed to load template. HTTP " & xhr.Status & "</p>"
  End If
End Function

Function DefaultLogPath()
  Dim fso, scriptFolder
  Set fso = CreateObject("Scripting.FileSystemObject")
  scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
  If Len(scriptFolder) = 0 Then scriptFolder = "."
  DefaultLogPath = scriptFolder & "\mail_util.log"
End Function

Sub LogAction(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = DefaultLogPath()
  Dim fso, f: Set fso = CreateObject("Scripting.FileSystemObject")
  Dim ts: Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
End Sub
