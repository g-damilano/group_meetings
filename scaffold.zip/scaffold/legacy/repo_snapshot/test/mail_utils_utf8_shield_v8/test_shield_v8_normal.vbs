' test_shield_v8_normal.vbs
Option Explicit
SetLocale 1033
Dim files, html, subj, ok, logPath
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_utf8_shield_v8.vbs",1).ReadAll

logPath = "" ' default: same folder
subj = "Shield Layer " & ChrW(&H2013) & " Normal"
html = "<h3>Shield Normal</h3><p>Accents: " & _
       ChrW(&HE5) & ", " & ChrW(&H107) & ", " & ChrW(&HE9) & ", " & ChrW(&HF1) & ", " & ChrW(&HF6) & _
       " - em dash " & ChrW(&H2014) & " / en dash " & ChrW(&H2013) & ".</p>"

files = Array()
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)
