' test_shield_v11_repair.vbs
Option Explicit
SetLocale 1033
Dim files, html, subj, ok, logPath
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_utf8_shield_v11.vbs",1).ReadAll

logPath = ""

subj = "Shield Layer â€“ Repair"
html = "<h3>Shield Repair</h3><p>Accents: ÃƒÆ’Ã‚Â¥, ÃƒÆ’Ã‚Â¤, ÃƒÆ’Ã‚Â¶, ÃƒÆ’Ã‚Â©, ÃƒÆ’Ã‚Â¨, ÃƒÆ’Ã‚Âª â€” should auto-repair to " & _
       ChrW(&HE5) & ", " & ChrW(&HE4) & ", " & ChrW(&HF6) & ", " & ChrW(&HE9) & ", " & ChrW(&HE8) & ", " & ChrW(&HEA) & _
       " " & ChrW(&H2014) & "</p>"

files = Array()
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)
