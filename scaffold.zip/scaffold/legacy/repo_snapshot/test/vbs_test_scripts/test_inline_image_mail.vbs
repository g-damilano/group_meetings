Option Explicit
Dim olApp, olMail, att
Const olMailItem = 0
Const olFormatHTML = 2
Const PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"

Set olApp = CreateObject("Outlook.Application")
Set olMail = olApp.CreateItem(olMailItem)

Dim imgPath, cid
imgPath = "C:\Temp\logo.png"
cid = "testlogo123@example"

Set att = olMail.Attachments.Add(imgPath)
att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid

With olMail
  .To = "gd2613@ic.ac.uk"
  .Subject = "VBScript Test 3 – Inline Image"
  .BodyFormat = olFormatHTML
  .HTMLBody = "<html><body style='font-family:Segoe UI;'>" & _
              "<h3>Test 3: Inline Image</h3>" & _
              "<p>Below is an inline logo referenced by <code>cid:</code>:</p>" & _
              "<img src='cid:" & cid & "' style='height:80px;'><br>" & _
              "<p>If you can see the image above, embedding works.</p>" & _
              "</body></html>"
  .Display
End With
