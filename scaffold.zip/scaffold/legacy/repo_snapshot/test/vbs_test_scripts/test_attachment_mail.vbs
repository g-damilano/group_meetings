Option Explicit
Dim olApp, olMail
Const olMailItem = 0
Const olFormatHTML = 2

Set olApp = CreateObject("Outlook.Application")
Set olMail = olApp.CreateItem(olMailItem)

With olMail
  .To = "gd2613@ic.ac.uk"
  .Subject = "VBScript Test 2 – HTML + Attachment"
  .BodyFormat = olFormatHTML
  .HTMLBody = "<html><body style='font-family:Segoe UI;'>" & _
              "<h3>Test 2: Attachment</h3>" & _
              "<p>This email should have a test file attached.</p>" & _
              "</body></html>"
  .Attachments.Add "C:\Temp\testfile.txt"
  .Display
End With
