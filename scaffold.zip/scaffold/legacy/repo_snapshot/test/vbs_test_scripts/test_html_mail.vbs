Option Explicit
Const olMailItem = 0
Const olFormatHTML = 2

Dim olApp, olMail, sigHTML
Set olApp = CreateObject("Outlook.Application")
Set olMail = olApp.CreateItem(olMailItem)

' === Include the function here ===
' (copy-paste the full LoadSignatureWithImages function above)
' =================================
Function LoadSignatureWithImages(olMail)
  Dim fso, shell, sigPath, folder, file, sigHTML, sigFile, baseName, imgFolder, imgFile, att, imgName, cid
  Const PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"

  Set fso = CreateObject("Scripting.FileSystemObject")
  Set shell = CreateObject("WScript.Shell")
  sigPath = shell.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\Signatures\"
  sigHTML = ""

  ' Find the default .htm signature
  If fso.FolderExists(sigPath) Then
    Set folder = fso.GetFolder(sigPath)
    For Each file In folder.Files
      If LCase(fso.GetExtensionName(file.Name)) = "htm" Then
        sigFile = file.Path
        baseName = fso.GetBaseName(file.Name)
        sigHTML = fso.OpenTextFile(sigFile, 1).ReadAll
        Exit For
      End If
    Next
  End If

  ' Replace references to _files folder with embedded CIDs
  imgFolder = sigPath & baseName & ".files"
  If fso.FolderExists(imgFolder) Then
    For Each imgFile In fso.GetFolder(imgFolder).Files
      imgName = fso.GetFileName(imgFile.Name)
      cid = Replace(imgName, " ", "_") ' safe ID
      Set att = olMail.Attachments.Add(imgFile.Path)
      att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid

      ' Replace both forward and backward slashes
      sigHTML = Replace(sigHTML, baseName & ".files/" & imgName, "cid:" & cid)
      sigHTML = Replace(sigHTML, baseName & ".files\" & imgName, "cid:" & cid)
    Next
  End If

  LoadSignatureWithImages = sigHTML
End Function


' === Load signature and send ===
sigHTML = LoadSignatureWithImages(olMail)

With olMail
  .To = "gd2613@ic.ac.uk"
  .Subject = "VBScript Test 1 – HTML + Signature with Images"
  .BodyFormat = olFormatHTML
  .HTMLBody = "<html><body style='font-family:Segoe UI;'>" & _
              "<h3>Test 1: HTML body</h3>" & _
              "<p>This message includes your Outlook signature with inline images.</p>" & _
              sigHTML & _
              "</body></html>"
  .Display
End With
