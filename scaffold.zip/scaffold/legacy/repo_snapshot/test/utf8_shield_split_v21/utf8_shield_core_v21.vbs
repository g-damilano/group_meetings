'======================================================================
' utf8_shield_core_v21.vbs — UTF‑8 Repair Shield (Stratified, Score‑gated)
'----------------------------------------------------------------------
' Goal: Fix UTF‑8→Win-1252 mojibake (incl. multi-layer), while preserving
'       already-correct Greek/Cyrillic and avoiding over-normalisation.
'
' Pipeline (stratified):
'  L0  Detect markers, scrub BOMs
'  L1  Pre‑maps (punctuation/currencies) — idempotent
'  L2  CopyTo (Win‑1252 bytes → UTF‑8 text) — v9 core
'  L3  Alt decode probe (UTF‑8→1252→UTF‑8) BUT ONLY if score improves
'  L4  Orphan fixes (NBSP/space Ã/Ãƒ), Voilà heuristic, bare openers
'  L5  Post‑maps (quotes/dashes/currencies) + space normalization
'  L6  Convergence control (marker count, stall limit)
'
' Scoring:
'   Score(s) = (markers, greek_count, cyrillic_count)
'   Candidate is accepted only if:
'     - markers decreases, AND
'     - greek_count and cyrillic_count do not decrease when they were >0.
'----------------------------------------------------------------------
Option Explicit
SetLocale 1033

'================== Public API ==================
Function FixEncoding(text, logPath)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncoding = text
    Exit Function
  End If

  Dim s, i, before, after, prev, m0, sc0m, sc0g, sc0c, scm, scg, scc, stalls
  s = CStr(text)

  ' L0: scrub and detect
  s = StripBomGlyphs(s)
  Score s, sc0m, sc0g, sc0c
  LogShield logPath, "v21 start — markers=" & sc0m & " greek=" & sc0g & " cyr=" & sc0c

  ' Early exit if clean
  If sc0m = 0 Then
    FixEncoding = s
    Exit Function
  End If

  ' L1: pre‑maps
  s = HardMapPre(s)

  ' Iterative convergence
  stalls = 0
  Dim MAX_PASSES: MAX_PASSES = 6
  For i = 1 To MAX_PASSES
    before = Left(s, 180)

    ' L2: primary CopyTo (always applied)
    s = Reinterpret_W1252_to_UTF8_CopyTo(s)

    ' L3: alt decode probe — score gated
    s = TryAltProbeIfBetter(s)

    ' L4: orphans / Voilà / openers
    s = FixOrphanPairs(s)

    ' L5: post‑maps + normalize
    s = HardMapPost(s)
    s = NormalizeSpaces(s)

    after = Left(s, 180)
    Score s, scm, scg, scc
    LogShield logPath, "Pass " & i & " BEFORE: " & before
    LogShield logPath, "Pass " & i & " AFTER : " & after & " | markers=" & scm & " greek=" & scg & " cyr=" & scc

    If scm = 0 Then Exit For

    If prev = s Then
      stalls = stalls + 1
      If stalls >= 2 Then
        LogShield logPath, "Convergence stalled. Breaking."
        Exit For
      End If
    Else
      stalls = 0
    End If
    prev = s
  Next

  FixEncoding = s
End Function

'================== Detection & Metrics ==================
Function LooksLikeUtf8AsWin1252(s)
  LooksLikeUtf8AsWin1252 = _
      (InStr(s, "Ã") > 0) Or (InStr(s, "Â") > 0) Or _
      (InStr(s, "â€”") > 0) Or (InStr(s, "â€“") > 0) Or _
      (InStr(s, "â€œ") > 0) Or (InStr(s, "â€�") > 0) Or _
      (InStr(s, "â€˜") > 0) Or (InStr(s, "â€™") > 0) Or _
      (InStr(s, "â€¦") > 0) Or (InStr(s, "â„¢") > 0) Or _
      (InStr(s, "ï»¿") > 0) Or _
      (InStr(s, "Ð") > 0 And InStr(s, "Ñ") > 0) Or (InStr(s, "Î") > 0)
End Function

Sub Score(s, ByRef markers, ByRef greekCount, ByRef cyrCount)
  markers = MarkerCount(s)
  greekCount = CountBlock(s, &H0370, &H03FF)    ' Greek and Coptic
  cyrCount   = CountBlock(s, &H0400, &H04FF)    ' Cyrillic
End Sub

Function CountBlock(s, lo, hi)
  Dim i, ch, n: n = 0
  For i = 1 To Len(s)
    ch = AscW(Mid(s, i, 1))
    If ch >= lo And ch <= hi Then n = n + 1
  Next
  CountBlock = n
End Function

Function MarkerCount(s)
  Dim c: c = 0
  c = c + CountOf(s, "Ã")
  c = c + CountOf(s, "Â")
  c = c + CountOf(s, "â€”") + CountOf(s, "â€“") + CountOf(s, "â€œ") + CountOf(s, "â€�") + CountOf(s, "â€˜") + CountOf(s, "â€™") + CountOf(s, "â€¦") + CountOf(s, "â„¢")
  c = c + CountOf(s, "ï»¿")
  MarkerCount = c
End Function

Function CountOf(s, token)
  Dim p, n: p = 1: n = 0
  Do
    p = InStr(p, s, token)
    If p = 0 Then Exit Do
    n = n + 1
    p = p + Len(token)
  Loop
  CountOf = n
End Function

'================== Maps & Normalization ==================
Function HardMapPre(s)
  s = Replace(s, "â€“", "–")
  s = Replace(s, "â€”", "—")
  s = Replace(s, "â€˜", "‘")
  s = Replace(s, "â€™", "’")
  s = Replace(s, "â€œ", "“")
  s = Replace(s, "â€�", "”")
  s = Replace(s, "â€¦", "…")
  s = Replace(s, "â‚¬", "€")
  s = Replace(s, "Â£", "£")
  s = Replace(s, "Â¥", "¥")
  s = Replace(s, "â„¢", "™")
  HardMapPre = s
End Function

Function HardMapPost(s)
  s = Replace(s, "â€“", "–")
  s = Replace(s, "â€”", "—")
  s = Replace(s, "â€˜", "‘")
  s = Replace(s, "â€™", "’")
  s = Replace(s, "â€œ", "“")
  s = Replace(s, "â€�", "”")
  s = Replace(s, "â€¦", "…")
  s = Replace(s, "â‚¬", "€")
  s = Replace(s, "Â£", "£")
  s = Replace(s, "Â¥", "¥")
  s = Replace(s, "â„¢", "™")
  HardMapPost = s
End Function

Function NormalizeSpaces(s)
  Dim nbsp: nbsp = ChrW(160)
  Dim k: For k = 1 To 3: s = Replace(s, "  ", " "): Next
  s = Replace(s, nbsp, " ")
  NormalizeSpaces = s
End Function

'================== Orphans / Voilà / Openers ==================
Function FixOrphanPairs(s)
  Dim nbsp: nbsp = ChrW(160)

  ' Ã/Ãƒ with NBSP or space → à
  s = Replace(s, "Ãƒ" & nbsp, "à")
  s = Replace(s, "Ã" & nbsp, "à")
  s = Replace(s, "Ãƒ ", "à")
  s = Replace(s, "Ã ", "à")
  s = Replace(s, "ÃƒÂ " , "à")
  s = Replace(s, "ÃÂ "  , "à")
  s = Replace(s, "ÃƒÂ" & nbsp, "à")
  s = Replace(s, "ÃÂ" & nbsp , "à")

  ' Voilà variants
  s = RegexReplaceVoila(s)

  ' Bare opener â€ → “
  s = Replace(s, "â€ ", "“ ")
  s = Replace(s, " â€", " “")
  s = Replace(s, "â€", "“")

  FixOrphanPairs = s
End Function

Function RegexReplaceVoila(s)
  On Error Resume Next
  Dim nbsp: nbsp = ChrW(160)
  Dim re: Set re = CreateObject("VBScript.RegExp")
  re.Global = True: re.IgnoreCase = False
  re.Pattern = "VoilÃ(" & nbsp & "| |$)"
  RegexReplaceVoila = re.Replace(s, "Voilà$1")
  If Err.Number <> 0 Then RegexReplaceVoila = s
End Function

'================== Alternate decode probe (score‑gated) ==================
Function TryAltProbeIfBetter(s)
  Dim m0, g0, c0, cand, m1, g1, c1
  Score s, m0, g0, c0
  cand = Utf8BytesTo1252TextToUtf8(s)
  Score cand, m1, g1, c1

  If (m1 < m0) And ((g1 >= g0) Or g0 = 0) And ((c1 >= c0) Or c0 = 0) Then
    TryAltProbeIfBetter = cand
  Else
    TryAltProbeIfBetter = s
  End If
End Function

Function Utf8BytesTo1252TextToUtf8(txt)
  On Error Resume Next
  Dim a, b, out
  Set a = CreateObject("ADODB.Stream")
  a.Type = 2: a.Charset = "utf-8": a.Open
  a.WriteText txt
  a.Position = 0: a.Type = 1 ' bytes

  Set b = CreateObject("ADODB.Stream")
  b.Type = 1: b.Open
  a.CopyTo b

  b.Position = 0: b.Type = 2: b.Charset = "windows-1252"
  out = b.ReadText

  a.Close: b.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = txt
  Utf8BytesTo1252TextToUtf8 = out
End Function

'================== Core reinterpretation (v9) ==================
Function Reinterpret_W1252_to_UTF8_CopyTo(badText)
  On Error Resume Next
  Dim sIn, sOut, out
  Set sIn = CreateObject("ADODB.Stream")
  sIn.Type = 2: sIn.Charset = "windows-1252": sIn.Open
  sIn.WriteText badText
  sIn.Position = 0: sIn.Type = 1

  Set sOut = CreateObject("ADODB.Stream")
  sOut.Type = 1: sOut.Open
  sIn.CopyTo sOut

  sOut.Position = 0: sOut.Type = 2: sOut.Charset = "utf-8"
  out = sOut.ReadText

  sIn.Close: sOut.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = badText
  Reinterpret_W1252_to_UTF8_CopyTo = out
End Function

'================== Logging ==================
Function ShieldDefaultLogPath()
  On Error Resume Next
  Dim fso, scriptFolder
  Set fso = CreateObject("Scripting.FileSystemObject")
  scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
  If Len(scriptFolder) = 0 Then scriptFolder = "."
  ShieldDefaultLogPath = scriptFolder & "\mail_util.log"
  On Error GoTo 0
End Function

Sub LogShield(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = ShieldDefaultLogPath()
  Dim fso, f: Set fso = CreateObject("Scripting.FileSystemObject")
  Dim ts: Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
  On Error GoTo 0
End Sub

Function StripBomGlyphs(s)
  s = Replace(s, "ï»¿", "")
  Dim feff: feff = ChrW(&HFEFF)
  s = Replace(s, feff, "")
  StripBomGlyphs = s
End Function
