# UTF‑8 Shield — Problem Definition and Resolution Logic (v21)

## 1) Problem
You receive HTML strings where *UTF‑8 bytes were decoded as Windows‑1252 one or more times*.
Goal: restore correct Unicode **without** damaging already-correct segments (Greek/Cyrillic) and without over‑normalising.

## 2) Model
Let `T` be correct Unicode text. Normal path: `T --encode(UTF‑8)--> U8 --decode(UTF‑8)--> T`.
Mojibake path: `T --encode(UTF‑8)--> U8 --decode(Win‑1252)--> W`. Sometimes repeated: `W --encode(UTF‑8)--> U8' --decode(Win‑1252)--> W'`.

## 3) Observable Signatures
Clusters like `Ã`, `Â`, and `â€” â€œ â€�` sequences; NBSP artifacts `Â`; BOM glyphs `ï»¿`; layered tokens `ÃƒÆ’`, `ÃƒÂ`.

## 4) Boundary Conditions (Safety)
- Never apply a transform unless it **reduces mojibake markers**.
- If Greek or Cyrillic are already present, **do not reduce** their counts.
- Do not increase `�` (U+FFFD) occurrences.
- Idempotent maps only (pre/post) so repeated runs are safe.

## 5) Scoring
`Score(s) = (markers, greek_count, cyr_count)`  
Markers count `Ã`, `Â`, and `â€”/â€“/â€œ/â€�/…/™` plus BOM glyphs.

## 6) Decision Procedure
1. **Strip BOMs**, compute score.
2. If `markers = 0` → return.
3. **Hard pre‑maps** for punctuation/currencies.
4. **CopyTo** (Win‑1252→UTF‑8) reinterpretation.
5. **Alt probe** (UTF‑8→1252→UTF‑8) only if score improves **and** Greek/Cyrillic counts don’t drop.
6. **Orphan repairs** (NBSP “VoilÃ ”, bare opener `â€` to `“`, `Ã/Ãƒ` + space→`à`).
7. **Hard post‑maps** + **space normalize**.
8. Recompute score; stop on `markers=0` or after 2 stall passes.

## 7) Verification Invariants
- Marker count monotonically ↓ or stalling triggers bail‑out.
- Greek/Cyrillic counts never ↓ when non‑zero.
- No HTML structure mutation (we don’t touch `<`…`>` tokens).

## 8) Test Surface (A–J)
Covers NBSP orphans, layered clusters, currencies, quotes/dashes, mixed Greek/Cyrillic lines, and trailing‑space “Voilà”.

## 9) Implementation
See `utf8_shield_core_v21.vbs` and `mail_utils_mailer_v21.vbs`.  
The mailer injects `<meta charset="utf-8">` and logs per‑pass scores.

