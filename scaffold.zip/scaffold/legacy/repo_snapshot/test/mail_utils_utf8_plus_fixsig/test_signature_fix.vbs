' test_signature_fix.vbs — verify signature decoding
Option Explicit
SetLocale 1033

Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
Dim folder: folder = fso.GetParentFolderName(WScript.ScriptFullName) : If Len(folder)=0 Then folder = "."

' Load mailer (no shield)
ExecuteGlobal fso.OpenTextFile(folder & "\mail_utils_mailer.vbs", 1).ReadAll

Dim html, subj, ok
subj = "Signature Charset Auto-Detect — Test"
html = "<h3>Body (UTF‑8)</h3><p>Body accents: å ä ö é è ê ë — “quotes” ‘single’</p>" & _
       "<p>If your signature contains “don’t”, it should render the apostrophe, not �.</p>"

ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, Array(), "display", "", "", "", 0, "")
If Not ok Then WScript.Echo "CreateMail failed. See mail_util.log for details."
