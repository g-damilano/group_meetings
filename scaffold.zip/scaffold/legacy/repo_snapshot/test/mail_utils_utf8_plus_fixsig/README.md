# mail_utils_utf8_plus_fixsig (no shield)

This package fixes misinterpreted **Outlook signatures** like `I don�t expect...` by auto‑detecting the signature **HTM** charset and reading it accordingly.

Most Outlook signatures are saved as **Windows‑1252** HTM, while your email body is UTF‑8. Reading the signature as UTF‑8 causes mojibake (Ã¢â‚¬â„¢ instead of ’). The loader now:

1. Detects `charset=...` in the signature’s `<meta>`.
2. Defaults to `windows-1252` if unspecified (typical for Outlook).
3. Falls back: if mojibake markers found under 1252, re‑reads as UTF‑8 and chooses the cleaner version.

## Files
- `mail_utils_mailer_fixsig.vbs` — Outlook mailer with **signature auto‑charset**.
- `test_signature_fix.vbs` — opens a message to preview.
- (optional) You can still use external HTML bodies the same way as before.

## Usage
Extract to a folder and run `test_signature_fix.vbs`. You should see smart quotes and apostrophes correctly in your signature.
