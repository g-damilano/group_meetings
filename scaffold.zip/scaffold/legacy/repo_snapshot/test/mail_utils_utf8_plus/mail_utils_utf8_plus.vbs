'======================================================================
' mail_utils_utf8_plus.vbs — Outlook Mail Utility (UTF‑8 safe)
' Implements:
'   1) Direct .msg SaveAs via savePath
'   2) HTML template injection from file or URL
'   3) Extra inline image embedding from a folder
'   4) Simple logging to a text file
'   8) Delayed sending via DeferredDeliveryTime (minutes)
' Also: UTF‑8-safe file reads (ADODB.Stream), URL fetch, signature with images.
'======================================================================
Option Explicit
SetLocale 1033  ' normalise locale/codepage

Const olMailItem = 0
Const olFormatHTML = 2
Const olMSG = 3
Const PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"

'---------------------------------------------------------------------
' Public: CreateMail
' Params:
'   toAddr, ccAddr, bccAddr        : strings
'   subjectText                    : string (use ChrW for fancy punctuation, e.g., "Demo " & ChrW(&H2013) & " Test")
'   htmlBody                       : HTML string (ignored if templateSource provided)
'   attachPaths                    : Array of file paths (may be Empty)
'   action                         : "display" | "send" | "save"
'   savePath                       : optional .msg path if action="save"
'   templateSource                 : optional HTML file path or http(s) URL
'   inlineImgFolder                : optional folder path; embeds all files as cid:filename
'   deferMinutes                   : optional number > 0 to delay sending
'   logPath                        : optional txt log path; appends actions/errors
' Returns Boolean success
'---------------------------------------------------------------------
Function CreateMail(toAddr, ccAddr, bccAddr, subjectText, htmlBody, attachPaths, _
                    action, savePath, templateSource, inlineImgFolder, deferMinutes, logPath)
  On Error Resume Next
  Dim ok, olApp, olMail, sigHTML, f, fso, bodyHtml
  Dim startedErrNum, startedErrDesc
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set olApp = GetOutlookApp()
  startedErrNum = Err.Number : startedErrDesc = Err.Description

  If Len(Trim(templateSource)) > 0 Then
    bodyHtml = LoadHtmlFromSource(templateSource)
  Else
    bodyHtml = htmlBody
  End If

  Set olMail = olApp.CreateItem(olMailItem)
  sigHTML = LoadSignatureWithImages(olMail)

  With olMail
    .To = toAddr
    .CC = ccAddr
    .BCC = bccAddr
    .Subject = subjectText
    .BodyFormat = olFormatHTML
    .HTMLBody = "<html><body style='font-family:Segoe UI, Arial, sans-serif;'>" & bodyHtml & sigHTML & "</body></html>"

    If Not IsEmpty(attachPaths) Then
      For Each f In attachPaths
        If Len(Trim(f)) > 0 And fso.FileExists(f) Then .Attachments.Add f
      Next
    End If

    If Len(Trim(inlineImgFolder)) > 0 And fso.FolderExists(inlineImgFolder) Then
      EmbedImagesFromFolder olMail, inlineImgFolder
      ' NOTE: reference these as <img src=""cid:filename.ext""> in your HTML/template
    End If

    If IsNumeric(deferMinutes) And CDbl(deferMinutes) > 0 Then
      .DeferredDeliveryTime = Now + (CDbl(deferMinutes) / (24 * 60))
    End If

    Select Case LCase(action)
      Case "send"   : .Send : LogAction logPath, "Sent: " & subjectText
      Case "save"
        If Len(Trim(savePath)) > 0 Then
          .SaveAs savePath, olMSG : LogAction logPath, "Saved as: " & savePath
        Else
          .Save : LogAction logPath, "Saved to Drafts: " & subjectText
        End If
      Case Else     : .Display : LogAction logPath, "Displayed: " & subjectText
    End Select
  End With

  If Err.Number <> 0 Then
    LogAction logPath, "ERROR: " & Err.Number & " - " & Err.Description
    ok = False
  Else
    ok = True
  End If

  CreateMail = ok
  On Error GoTo 0
End Function

'---------------------------------------------------------------------
' EmbedImagesFromFolder: attaches all files in folder with CID=filename
'---------------------------------------------------------------------
Sub EmbedImagesFromFolder(olMail, folderPath)
  Dim fso, file, cid, att
  Set fso = CreateObject("Scripting.FileSystemObject")
  For Each file In fso.GetFolder(folderPath).Files
    cid = fso.GetFileName(file.Name)
    Set att = olMail.Attachments.Add(file.Path)
    att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
  Next
End Sub

'---------------------------------------------------------------------
' GetOutlookApp
'---------------------------------------------------------------------
Function GetOutlookApp()
  Dim app
  On Error Resume Next
  Set app = GetObject(, "Outlook.Application")
  If Err.Number <> 0 Then
    Err.Clear
    Set app = CreateObject("Outlook.Application")
  End If
  On Error GoTo 0
  Set GetOutlookApp = app
End Function

'---------------------------------------------------------------------
' LoadSignatureWithImages (supports ".files" signature folder)
' Reads HTML via UTF‑8 stream and rewrites src to cid: while embedding
'---------------------------------------------------------------------
Function LoadSignatureWithImages(olMail)
  Dim fso, shell, sigPath, folder, file, sigHTML, sigFile, baseName, imgFolder, imgFile, att, imgName, cid
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set shell = CreateObject("WScript.Shell")
  sigPath = shell.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\Signatures\"
  sigHTML = ""

  If fso.FolderExists(sigPath) Then
    Set folder = fso.GetFolder(sigPath)
    For Each file In folder.Files
      If LCase(fso.GetExtensionName(file.Name)) = "htm" Then
        sigFile = file.Path
        baseName = fso.GetBaseName(file.Name)
        sigHTML = ReadUTF8File(sigFile)
        Exit For
      End If
    Next
  End If

  imgFolder = sigPath & baseName & ".files"
  If fso.FolderExists(imgFolder) Then
    For Each imgFile In fso.GetFolder(imgFolder).Files
      imgName = fso.GetFileName(imgFile.Name)
      cid = Replace(imgName, " ", "_")
      Set att = olMail.Attachments.Add(imgFile.Path)
      att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
      sigHTML = Replace(sigHTML, baseName & ".files/" & imgName, "cid:" & cid)
      sigHTML = Replace(sigHTML, baseName & ".files\" & imgName, "cid:" & cid)
    Next
  End If

  LoadSignatureWithImages = sigHTML
End Function

'---------------------------------------------------------------------
' ReadUTF8File: reliable UTF‑8 text read (no mojibake)
'---------------------------------------------------------------------
Function ReadUTF8File(filePath)
  Dim s
  Set s = CreateObject("ADODB.Stream")
  s.Type = 2                 ' text
  s.Charset = "utf-8"
  s.Open
  s.LoadFromFile filePath
  ReadUTF8File = s.ReadText
  s.Close
End Function

'---------------------------------------------------------------------
' LoadHtmlFromSource: accepts local file path OR http/https URL
' Uses UTF‑8 decoding for predictable results
'---------------------------------------------------------------------
Function LoadHtmlFromSource(src)
  Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
  If Left(LCase(src), 7) = "http://" Or Left(LCase(src), 8) = "https://" Then
    LoadHtmlFromSource = HttpGetUtf8(src)
  ElseIf fso.FileExists(src) Then
    LoadHtmlFromSource = ReadUTF8File(src)
  Else
    LoadHtmlFromSource = src ' fallback: treat as literal HTML
  End If
End Function

'---------------------------------------------------------------------
' HttpGetUtf8: fetch URL as UTF‑8 using XMLHTTP + ADODB.Stream
'---------------------------------------------------------------------
Function HttpGetUtf8(url)
  Dim xhr, stm, txt
  Set xhr = CreateObject("MSXML2.XMLHTTP")
  xhr.Open "GET", url, False
  xhr.Send
  If xhr.Status = 200 Then
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 1 ' binary
    stm.Open
    stm.Write xhr.responseBody
    stm.Position = 0
    stm.Type = 2 ' text
    stm.Charset = "utf-8"
    txt = stm.ReadText
    stm.Close
    HttpGetUtf8 = txt
  Else
    HttpGetUtf8 = "<p>Failed to load template. HTTP " & xhr.Status & "</p>"
  End If
End Function

'---------------------------------------------------------------------
' LogAction: append timestamped lines to a log file
'---------------------------------------------------------------------
Sub LogAction(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then Exit Sub
  Dim fso, f
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
End Sub
