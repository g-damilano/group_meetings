'======================================================================
' utf8_shield_core_v22.vbs — UTF‑8 Repair Shield (Stratified + Segmented)
'----------------------------------------------------------------------
' This implements the analysis-first logic:
'  • Global stratified passes (L0–L6) with score‑gated transforms
'  • Segmented, ramified decoding (per‑segment candidates S0–S4)
'  • Safety invariants: markers↓, Greek/Cyrillic not↓, replacements not↑
'----------------------------------------------------------------------
Option Explicit
SetLocale 1033

'================== Public API ==================
Function FixEncoding(text, logPath)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncoding = text
    Exit Function
  End If

  Dim s, i, prev, m,g,c,r, stalls, before, after
  s = CStr(text)

  s = StripBomGlyphs(s)
  Score s, m,g,c,r
  LogShield logPath, "v22 start — markers=" & m & " greek=" & g & " cyr=" & c & " repl=" & r

  If m = 0 Then
    FixEncoding = s
    Exit Function
  End If

  ' -------- Global stratified passes --------
  stalls = 0
  Dim MAX_PASSES: MAX_PASSES = 6
  For i = 1 To MAX_PASSES
    before = Left(s, 180)

    s = HardMapPre(s)

    Dim s1, s2, sbest
    s1 = Reinterpret_W1252_to_UTF8_CopyTo(s)   ' L2
    s2 = TryAltProbeIfBetter(s1)               ' L3 (guarded)
    sbest = ChooseBestByScore(Array(s, s1, s2), False) ' no trust constraints at global level

    sbest = FixOrphanPairs(sbest)              ' L4
    sbest = HardMapPost(sbest)
    sbest = NormalizeSpaces(sbest)

    after = Left(sbest, 180)
    Score sbest, m,g,c,r
    LogShield logPath, "Pass " & i & " BEFORE: " & before
    LogShield logPath, "Pass " & i & " AFTER : " & after & " | markers=" & m & " greek=" & g & " cyr=" & c & " repl=" & r

    If m = 0 Then
      FixEncoding = sbest
      Exit Function
    End If

    If sbest = s Then
      stalls = stalls + 1
      If stalls >= 2 Then Exit For
    Else
      stalls = 0
    End If
    s = sbest
  Next

  ' -------- Segmented ramified pass --------
  Dim parts, combined, j
  parts = SegmentByMarkersAndScript(s)
  combined = ""

  For j = 0 To UBound(parts)
    combined = combined & RepairSegment(parts(j), logPath)
  Next

  FixEncoding = combined
End Function

'================== Segment structure ==================
' Segment is encoded as: kind|text
' kind: "trusted" (Greek/Cyrillic), "moji" (marker-heavy), "neutral" (other)
Function MakeSeg(kind, txt)
  MakeSeg = kind & "|" & txt
End Function

Sub ParseSeg(seg, ByRef kind, ByRef txt)
  Dim p: p = InStr(seg, "|")
  If p = 0 Then
    kind = "neutral": txt = seg
  Else
    kind = Left(seg, p-1)
    txt = Mid(seg, p+1)
  End If
End Sub

Function SegmentByMarkersAndScript(s)
  Dim OUT(), i, n, ch, code, curKind, buf, addSeg, mk, isGreek, isCyr
  n = Len(s)
  ReDim OUT(0)
  curKind = ""
  buf = ""

  For i = 1 To n
    ch = Mid(s, i, 1)
    code = AscW(ch)
    mk = (ch = "Ã") Or (ch = "Â") Or (ch = "â") Or (ch = "ï")
    isGreek = (code >= &H370 And code <= &H3FF)
    isCyr   = (code >= &H400 And code <= &H4FF)

    Dim k
    If isGreek Or isCyr Then
      k = "trusted"
    ElseIf mk Then
      k = "moji"
    Else
      k = "neutral"
    End If

    If curKind = "" Then
      curKind = k: buf = ch
    ElseIf k = curKind Then
      buf = buf & ch
    Else
      addSeg = MakeSeg(curKind, buf)
      Call ArrAppend(OUT, addSeg)
      curKind = k
      buf = ch
    End If
  Next

  If Len(buf) > 0 Then
    addSeg = MakeSeg(curKind, buf)
    Call ArrAppend(OUT, addSeg)
  End If

  SegmentByMarkersAndScript = OUT
End Function

Sub ArrAppend(ByRef arr, value)
  Dim n: n = UBound(arr)
  If n = 0 And arr(0) = Empty Then
    ReDim arr(0)
    arr(0) = value
  Else
    ReDim Preserve arr(n+1)
    arr(n+1) = value
  End If
End Sub

'================== Segment repair ==================
Function RepairSegment(seg, logPath)
  Dim kind, txt
  ParseSeg seg, kind, txt

  If kind = "trusted" Then
    ' Leave scripts intact; only safe maps
    txt = HardMapPre(txt)
    txt = HardMapPost(txt)
    RepairSegment = txt
    Exit Function
  End If

  If kind = "neutral" Then
    ' Try mild cleanup: maps and orphan heuristics; avoid reinterpret unless markers exist
    Dim m0,g0,c0,r0
    Score txt, m0,g0,c0,r0
    If m0 = 0 Then
      RepairSegment = txt
      Exit Function
    End If
    ' Fallthrough to mojibake candidates
  End If

  ' kind = "moji" or neutral with markers
  Dim cands(4)
  cands(0) = txt                                    ' S0 identity
  cands(1) = Reinterpret_W1252_to_UTF8_CopyTo(txt)  ' S1 CopyTo
  cands(2) = Utf8BytesTo1252TextToUtf8(cands(1))    ' S2 Alt probe on S1
  cands(3) = Reinterpret_W1252_to_UTF8_CopyTo(cands(1)) ' S3 Double CopyTo
  cands(4) = HardMapPost(FixOrphanPairs(HardMapPre(txt))) ' S4 maps only

  Dim best: best = ChooseBestByScore(cands, True)   ' enforce Greek/Cyr safety

  ' Final polish
  best = HardMapPost(best)
  best = NormalizeSpaces(best)

  RepairSegment = best
End Function

Function ChooseBestByScore(cands, enforceScriptSafety)
  Dim i, best, bm,bg,bc,br, sm,sg,sc,sr
  best = cands(0)
  Score best, bm,bg,bc,br

  For i = 1 To UBound(cands)
    Dim cand: cand = cands(i)
    Score cand, sm,sg,sc,sr
    If Better(sm,sg,sc,sr, bm,bg,bc,br, enforceScriptSafety, bg, bc) Then
      best = cand
      bm = sm: bg = sg: bc = sc: br = sr
    End If
  Next
  ChooseBestByScore = best
End Function

Function Better(sm,sg,sc,sr, bm,bg,bc,br, enforceScript, baseG, baseC)
  ' Prefer fewer markers
  If sm < bm Then
    If enforceScript Then
      If (baseG > 0 And sg < baseG) Then Better = False: Exit Function
      If (baseC > 0 And sc < baseC) Then Better = False: Exit Function
    End If
    If sr > br Then Better = False: Exit Function
    Better = True: Exit Function
  End If

  If sm > bm Then Better = False: Exit Function

  ' Tie-breakers: preserve/increase Greek/Cyr, then fewer replacements
  If enforceScript Then
    If (sg > bg) Or (sc > bc) Then Better = True: Exit Function
  End If

  If sr < br Then Better = True Else Better = False
End Function

'================== Detection & Metrics ==================
Function LooksLikeUtf8AsWin1252(s)
  LooksLikeUtf8AsWin1252 = _
      (InStr(s, "Ã") > 0) Or (InStr(s, "Â") > 0) Or _
      (InStr(s, "â€”") > 0) Or (InStr(s, "â€“") > 0) Or _
      (InStr(s, "â€œ") > 0) Or (InStr(s, "â€�") > 0) Or _
      (InStr(s, "â€˜") > 0) Or (InStr(s, "â€™") > 0) Or _
      (InStr(s, "â€¦") > 0) Or (InStr(s, "â„¢") > 0) Or _
      (InStr(s, "ï»¿") > 0)
End Function

Sub Score(s, ByRef markers, ByRef greekCount, ByRef cyrCount, ByRef replCount)
  markers = MarkerCount(s)
  greekCount = CountBlock(s, &H0370, &H03FF)
  cyrCount   = CountBlock(s, &H0400, &H04FF)
  replCount  = CountChar(s, ChrW(&HFFFD))
End Sub

Function CountBlock(s, lo, hi)
  Dim i, ch, n: n = 0
  For i = 1 To Len(s)
    ch = AscW(Mid(s, i, 1))
    If ch >= lo And ch <= hi Then n = n + 1
  Next
  CountBlock = n
End Function

Function CountChar(s, ch)
  Dim p, n: p = 1: n = 0
  Do
    p = InStr(p, s, ch)
    If p = 0 Then Exit Do
    n = n + 1
    p = p + Len(ch)
  Loop
  CountChar = n
End Function

Function MarkerCount(s)
  Dim c: c = 0
  c = c + CountOf(s, "Ã")
  c = c + CountOf(s, "Â")
  c = c + CountOf(s, "â€”") + CountOf(s, "â€“") + CountOf(s, "â€œ") + CountOf(s, "â€�") + CountOf(s, "â€˜") + CountOf(s, "â€™") + CountOf(s, "â€¦") + CountOf(s, "â„¢")
  c = c + CountOf(s, "ï»¿")
  MarkerCount = c
End Function

Function CountOf(s, token)
  Dim p, n: p = 1: n = 0
  Do
    p = InStr(p, s, token)
    If p = 0 Then Exit Do
    n = n + 1
    p = p + Len(token)
  Loop
  CountOf = n
End Function

'================== Maps & Normalization ==================
Function HardMapPre(s)
  s = Replace(s, "â€“", "–")
  s = Replace(s, "â€”", "—")
  s = Replace(s, "â€˜", "‘")
  s = Replace(s, "â€™", "’")
  s = Replace(s, "â€œ", "“")
  s = Replace(s, "â€�", "”")
  s = Replace(s, "â€¦", "…")
  s = Replace(s, "â‚¬", "€")
  s = Replace(s, "Â£", "£")
  s = Replace(s, "Â¥", "¥")
  s = Replace(s, "â„¢", "™")
  HardMapPre = s
End Function

Function HardMapPost(s)
  s = Replace(s, "â€“", "–")
  s = Replace(s, "â€”", "—")
  s = Replace(s, "â€˜", "‘")
  s = Replace(s, "â€™", "’")
  s = Replace(s, "â€œ", "“")
  s = Replace(s, "â€�", "”")
  s = Replace(s, "â€¦", "…")
  s = Replace(s, "â‚¬", "€")
  s = Replace(s, "Â£", "£")
  s = Replace(s, "Â¥", "¥")
  s = Replace(s, "â„¢", "™")
  HardMapPost = s
End Function

Function NormalizeSpaces(s)
  Dim nbsp: nbsp = ChrW(160)
  Dim k: For k = 1 To 3: s = Replace(s, "  ", " "): Next
  s = Replace(s, nbsp & " ", " ")
  s = Replace(s, " " & nbsp, " ")
  NormalizeSpaces = s
End Function

'================== Orphans / Voilà / Openers ==================
Function FixOrphanPairs(s)
  Dim nbsp: nbsp = ChrW(160)

  ' Ã/Ãƒ with NBSP or space → à
  s = Replace(s, "Ãƒ" & nbsp, "à")
  s = Replace(s, "Ã" & nbsp, "à")
  s = Replace(s, "Ãƒ ", "à")
  s = Replace(s, "Ã ", "à")
  s = Replace(s, "ÃƒÂ " , "à")
  s = Replace(s, "ÃÂ "  , "à")
  s = Replace(s, "ÃƒÂ" & nbsp, "à")
  s = Replace(s, "ÃÂ" & nbsp , "à")

  ' Voilà variants
  s = RegexReplaceVoila(s)

  ' Bare opener â€ → “ (small lookahead horizon simulated)
  s = Replace(s, "â€ ", "“ ")
  s = Replace(s, " â€", " “")
  s = Replace(s, "â€", "“")

  FixOrphanPairs = s
End Function

Function RegexReplaceVoila(s)
  On Error Resume Next
  Dim nbsp: nbsp = ChrW(160)
  Dim re: Set re = CreateObject("VBScript.RegExp")
  re.Global = True: re.IgnoreCase = False
  re.Pattern = "VoilÃ(" & nbsp & "| |$)"
  RegexReplaceVoila = re.Replace(s, "Voilà$1")
  If Err.Number <> 0 Then RegexReplaceVoila = s
End Function

'================== Alternate decode probe (score‑gated) ==================
Function TryAltProbeIfBetter(s)
  Dim m0,g0,c0,r0, cand, m1,g1,c1,r1
  Score s, m0,g0,c0,r0
  cand = Utf8BytesTo1252TextToUtf8(s)
  Score cand, m1,g1,c1,r1

  If (m1 < m0) And ((g1 >= g0) Or g0 = 0) And ((c1 >= c0) Or c0 = 0) And (r1 <= r0) Then
    TryAltProbeIfBetter = cand
  Else
    TryAltProbeIfBetter = s
  End If
End Function

Function Utf8BytesTo1252TextToUtf8(txt)
  On Error Resume Next
  Dim a, b, out
  Set a = CreateObject("ADODB.Stream")
  a.Type = 2: a.Charset = "utf-8": a.Open
  a.WriteText txt
  a.Position = 0: a.Type = 1

  Set b = CreateObject("ADODB.Stream")
  b.Type = 1: b.Open
  a.CopyTo b

  b.Position = 0: b.Type = 2: b.Charset = "windows-1252"
  out = b.ReadText

  a.Close: b.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = txt
  Utf8BytesTo1252TextToUtf8 = out
End Function

'================== Core reinterpretation (v9 CopyTo) ==================
Function Reinterpret_W1252_to_UTF8_CopyTo(badText)
  On Error Resume Next
  Dim sIn, sOut, out
  Set sIn = CreateObject("ADODB.Stream")
  sIn.Type = 2: sIn.Charset = "windows-1252": sIn.Open
  sIn.WriteText badText
  sIn.Position = 0: sIn.Type = 1

  Set sOut = CreateObject("ADODB.Stream")
  sOut.Type = 1: sOut.Open
  sIn.CopyTo sOut

  sOut.Position = 0: sOut.Type = 2: sOut.Charset = "utf-8"
  out = sOut.ReadText

  sIn.Close: sOut.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = badText
  Reinterpret_W1252_to_UTF8_CopyTo = out
End Function

'================== Logging & BOM ==================
Function ShieldDefaultLogPath()
  On Error Resume Next
  Dim fso, scriptFolder
  Set fso = CreateObject("Scripting.FileSystemObject")
  scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
  If Len(scriptFolder) = 0 Then scriptFolder = "."
  ShieldDefaultLogPath = scriptFolder & "\mail_util.log"
  On Error GoTo 0
End Function

Sub LogShield(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = ShieldDefaultLogPath()
  Dim fso, f: Set fso = CreateObject("Scripting.FileSystemObject")
  Dim ts: Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
  On Error GoTo 0
End Sub

Function StripBomGlyphs(s)
  s = Replace(s, "ï»¿", "")
  Dim feff: feff = ChrW(&HFEFF)
  s = Replace(s, feff, "")
  StripBomGlyphs = s
End Function
