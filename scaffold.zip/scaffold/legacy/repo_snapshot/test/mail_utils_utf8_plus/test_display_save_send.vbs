' test_display_save_send.vbs
Option Explicit
SetLocale 1033
Dim files, html, ok
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_utf8_plus.vbs",1).ReadAll

' Use ChrW to guarantee Unicode punctuation in subject
Dim subj: subj = "VBScript Extended Mail Utility " & ChrW(&H2013) & " UTF-8 Test"

html = "<h3>Display/Save/Send demo</h3><p>Accents: å, ć, é, ñ, ö — and an en dash " & ChrW(&H2013) & " here.</p>"
files = Array("C:\Temp\testfile.txt")

' 1) Display
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj & " (Display)", html, files, "display", "", "", "", 0, "C:\Temp\mail_util.log")

' 2) Save to .msg
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj & " (Save)", html, files, "save", "C:\Temp\TestDraft.msg", "", "", 0, "C:\Temp\mail_util.log")

' 3) Send with a 2-minute delay
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj & " (Send delayed)", html, files, "send", "", "", "", 2, "C:\Temp\mail_util.log")
