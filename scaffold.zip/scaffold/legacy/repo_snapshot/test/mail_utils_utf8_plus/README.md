# mail_utils_utf8_plus

This test package demonstrates sending an **external HTML template** body through the Outlook mailer + UTF‑8 shield.

## Files
- `utf8_shield_core_v22.vbs` — UTF‑8 repair shield (stratified + segmented)
- `mail_utils_mailer_v22.vbs` — Outlook mailer that loads the shield
- `sample_template_utf8.html` — **external HTML** used as the message body
- `assets/logo.png` — tiny PNG embedded as `cid:logo.png` from the folder
- `test_send_external_html.vbs` — test runner (defaults to `display`)

## How to use
1. Extract everything to the **same folder**.
2. Double‑click `test_send_external_html.vbs` to open a composed email with the external HTML body and signature.
   - Change `action` to `"send"` in the script to send directly.
3. Check `mail_util.log` in the same folder for shield diagnostics.

The template contains accents, punctuation, currencies, and Greek/Cyrillic to exercise the shield. Inline images in `assets/` are embedded with `cid:` and will render inside Outlook.
