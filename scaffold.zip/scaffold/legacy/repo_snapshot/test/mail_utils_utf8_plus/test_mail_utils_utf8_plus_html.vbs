'=============================================================
' test_mail_utils_utf8_plus_html.vbs
' ------------------------------------------------------------
' Test script for mail_utils_utf8_plus.zip (mailer + shield)
' It loads the mailer, then sends/displays an HTML file
' from disk using the shield to repair encoding automatically.
'=============================================================
Option Explicit
SetLocale 1033

'--- Load the mailer (which loads the shield automatically) ---
Dim fso
Set fso = CreateObject("Scripting.FileSystemObject")
ExecuteGlobal fso.OpenTextFile("mail_utils_mailer_utf8_plus.vbs", 1).ReadAll

'--- User configuration ---
Dim toAddr, ccAddr, bccAddr, subj, htmlFile, attachPaths, action, savePath, inlineFolder, deferMinutes, logPath

toAddr       = "your.name@domain.com"    ' <- change me
ccAddr       = ""
bccAddr      = ""
subj         = "UTF-8 Plus Test — External HTML"
htmlFile     = "sample_mail_body.html"   ' <- put your HTML here in same folder
attachPaths  = Array()                   ' or e.g. Array("C:\Temp\doc.pdf")
action       = "display"                 ' use "send" to actually mail it
savePath     = ""                        ' optional .msg path
inlineFolder = ""                        ' folder for embedded images (optional)
deferMinutes = 0                         ' delay (0 = immediate)
logPath      = ""                        ' defaults to mail_util.log

'--- Create mail ---
Dim ok
ok = CreateMail(toAddr, ccAddr, bccAddr, subj, "", attachPaths, _
                action, savePath, htmlFile, inlineFolder, deferMinutes, logPath)

If ok Then
  WScript.Echo "Mail created successfully using " & htmlFile
Else
  WScript.Echo "Mail creation failed — check mail_util.log"
End If
