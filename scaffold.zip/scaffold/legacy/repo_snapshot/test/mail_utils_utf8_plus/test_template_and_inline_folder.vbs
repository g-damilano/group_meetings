' test_template_and_inline_folder.vbs
Option Explicit
SetLocale 1033
Dim ok, html, files
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_utf8_plus.vbs",1).ReadAll

' If you have a local HTML file or a URL, set templateSource accordingly
Dim templateSource
templateSource = "" ' e.g. "C:\Temp\template.html" or "https://example.com/template.html"

' Inline images folder (reference in HTML as <img src=""cid:logo.png"">)
Dim inlineFolder: inlineFolder = "C:\Temp\inline_imgs"

html = "<h3>Template + Inline Images</h3><p>If you used a template, its HTML replaced this text.</p>"

files = Array()

ok = CreateMail("gd2613@ic.ac.uk", "", "", _
  "Template & Inline Images " & ChrW(&H2013) & " Demo", _
  html, files, _
  "display", "", templateSource, inlineFolder, 0, "C:\Temp\mail_util.log")
