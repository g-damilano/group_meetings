' test_shield_split_v19_normal.vbs
Option Explicit
SetLocale 1033
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_mailer_v19.vbs",1).ReadAll

Dim files, html, subj, ok, logPath
logPath = ""
subj = "Shield Split v19 — Normal"
html = "<h3>Shield v19 Mapping Test (Normal)</h3>" & _
       "<p>1) å ä ö é è ê ë</p>" & _
       "<p>2) ć č š ž ř ů</p>" & _
       "<p>3) ñ á í ó ú</p>" & _
       "<p>4) ß Ä Ö Ü</p>" & _
       "<p>5) œ ç é à</p>" & _
       "<p>6) — – “ ” ‘ ’</p>" & _
       "<p>7) € £ ¥</p>" & _
       "<p>8) Mixed: Voilà señor Großzügig</p>" & _
       "<p>9) Greek: α β γ Δ</p>" & _
       "<p>10) Cyrillic: Привет</p>"

files = Array()
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)
