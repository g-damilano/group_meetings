UTF‑8 Shield Split v19 — Generation Jump
=========================================

What’s new
----------
• Restored v9 CopyTo reinterpretation as the core.
• Added **HardMapPre/HardMapPost** passes for quotes/dashes/currencies/trademark.
• Strengthened **NBSP‑aware orphan** repairs + contextual **Voilà** matcher.
• Added space normalization and an expanded marker counter.
• Same detailed logging as v18, clearer marker counts per pass.
• Mailer wraps HTML with explicit UTF‑8 meta (and has optional BOM toggle).

Files
-----
1) utf8_shield_core_v19.vbs
2) mail_utils_mailer_v19.vbs
3) test_shield_split_v19_normal.vbs
4) test_shield_split_v19_repair.vbs
5) test_shield_split_v19_matrix.vbs

Usage
-----
• Put all files in the SAME folder.
• Run the tests; Outlook displays messages with repaired text.
• See mail_util.log for “Shield v19 — start; markers=…” and pass logs.
