'==============================================================
' utf8_shield_core_v19.vbs — UTF‑8 Repair Shield (Generation Jump)
' Strategy:
'   • v9 CopyTo reinterpretation core (byte‑faithful) as primary engine
'   • Dual‑phase hard maps for punctuation/currencies (pre & post core)
'   • NBSP‑aware orphan repairs (Ã/Ãƒ + NBSP/space → à) + Voilà heuristic
'   • Bare opener fallback (â€ → “), generalized quote/dash normalization
'   • Iterative loop w/ stall detector; wide marker set; aggressive logging
'==============================================================
Option Explicit
SetLocale 1033

'================== Public API ==================
Function FixEncoding(text, logPath)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncoding = text
    Exit Function
  End If

  Dim s, i, before, after, stalled
  s = CStr(text)

  ' Phase 0: scrub BOMs and run pre‑maps for obvious sequences
  s = StripBomGlyphs(s)
  s = HardMapPre(s)
  s = FixOrphanPairs(s)

  LogShield logPath, "Shield v19 — start; markers=" & CStr(MarkerCount(s))

  If Not LooksLikeUtf8AsWin1252(s) Then
    FixEncoding = s
    Exit Function
  End If

  ' Phase 1: CopyTo reinterpretation passes (byte‑faithful)
  stalled = 0
  Dim maxPasses: maxPasses = 5
  For i = 1 To maxPasses
    before = Left(s, 160)
    s = Reinterpret_W1252_to_UTF8_CopyTo(s)
    s = StripBomGlyphs(s)
    s = FixOrphanPairs(s)
    s = HardMapPost(s)
    after = Left(s, 160)

    LogShield logPath, "Pass " & i & " BEFORE: " & before
    LogShield logPath, "Pass " & i & " AFTER : " & after & " | markers=" & CStr(MarkerCount(s))

    If Not LooksLikeUtf8AsWin1252(s) Then Exit For
    If s = before Then
      stalled = stalled + 1
      If stalled >= 2 Then
        LogShield logPath, "Stalled (no change in two consecutive passes)."
        Exit For
      End If
    Else
      stalled = 0
    End If
  Next

  ' Phase 2: final normalizations
  s = NormalizeSpaces(s)
  FixEncoding = s
End Function

'================== Detection & Metrics ==================
Function LooksLikeUtf8AsWin1252(s)
  LooksLikeUtf8AsWin1252 = _
      (InStr(s, "Ã") > 0) Or (InStr(s, "Â") > 0) Or _
      (InStr(s, "â€”") > 0) Or (InStr(s, "â€“") > 0) Or _
      (InStr(s, "â€œ") > 0) Or (InStr(s, "â€�") > 0) Or _
      (InStr(s, "â€˜") > 0) Or (InStr(s, "â€™") > 0) Or _
      (InStr(s, "â€") > 0) Or (InStr(s, "â„¢") > 0) Or _
      (InStr(s, "ï»¿") > 0) Or _
      (InStr(s, "Ð") > 0 And InStr(s, "Ñ") > 0) Or (InStr(s, "Î") > 0)
End Function

Function MarkerCount(s)
  Dim c: c = 0
  c = c + CountOf(s, "Ã")
  c = c + CountOf(s, "Â")
  c = c + CountOf(s, "â€”") + CountOf(s, "â€“") + CountOf(s, "â€œ") + CountOf(s, "â€�") + CountOf(s, "â€˜") + CountOf(s, "â€™") + CountOf(s, "â€")
  c = c + CountOf(s, "ï»¿")
  MarkerCount = c
End Function

Function CountOf(s, token)
  Dim p, n: p = 1: n = 0
  Do
    p = InStr(p, s, token)
    If p = 0 Then Exit Do
    n = n + 1
    p = p + Len(token)
  Loop
  CountOf = n
End Function

'================== Pre/Post Hard Maps ==================
Function HardMapPre(s)
  ' Normalize common “double‑encoded punctuation” before reinterpretation
  ' (Some sources already replaced with U+FFFD; we cannot reconstruct those)
  s = Replace(s, "â€“", "–")
  s = Replace(s, "â€”", "—")
  s = Replace(s, "â€˜", "‘")
  s = Replace(s, "â€™", "’")
  s = Replace(s, "â€œ", "“")
  s = Replace(s, "â€�", "”")
  s = Replace(s, "â€¦", "…")
  s = Replace(s, "â‚¬", "€")
  s = Replace(s, "Â£", "£")
  s = Replace(s, "Â¥", "¥")
  s = Replace(s, "â„¢", "™")
  HardMapPre = s
End Function

Function HardMapPost(s)
  ' Post‑reinterpretation sweep to catch stragglers
  s = Replace(s, "â€“", "–")
  s = Replace(s, "â€”", "—")
  s = Replace(s, "â€˜", "‘")
  s = Replace(s, "â€™", "’")
  s = Replace(s, "â€œ", "“")
  s = Replace(s, "â€�", "”")
  s = Replace(s, "â€¦", "…")
  s = Replace(s, "â‚¬", "€")
  s = Replace(s, "Â£", "£")
  s = Replace(s, "Â¥", "¥")
  s = Replace(s, "â„¢", "™")
  HardMapPost = s
End Function

'================== Orphans / Voilà / Openers ==================
Function FixOrphanPairs(s)
  Dim nbsp: nbsp = ChrW(160)

  ' NBSP/space orphans that should be à
  s = Replace(s, "Ãƒ" & nbsp, "à")
  s = Replace(s, "Ã" & nbsp, "à")
  s = Replace(s, "Ãƒ ", "à")
  s = Replace(s, "Ã ", "à")
  s = Replace(s, "ÃƒÂ " , "à")
  s = Replace(s, "ÃÂ "  , "à")
  s = Replace(s, "ÃƒÂ" & nbsp, "à")
  s = Replace(s, "ÃÂ" & nbsp , "à")

  ' Voilà (with space, NBSP, or end)
  s = RegexReplaceVoila(s)

  ' Bare opener â€ → “
  s = Replace(s, "â€ ", "“ ")
  s = Replace(s, " â€", " “")
  s = Replace(s, "â€", "“")

  FixOrphanPairs = s
End Function

Function RegexReplaceVoila(s)
  On Error Resume Next
  Dim nbsp: nbsp = ChrW(160)
  Dim re: Set re = CreateObject("VBScript.RegExp")
  re.Global = True
  re.IgnoreCase = False
  re.Pattern = "VoilÃ(" & nbsp & "| |$)"
  RegexReplaceVoila = re.Replace(s, "Voilà$1")
  If Err.Number <> 0 Then
    Err.Clear
    RegexReplaceVoila = s
  End If
End Function

'================== Space normalization ==================
Function NormalizeSpaces(s)
  Dim nbsp: nbsp = ChrW(160)
  ' Collapse accidental doubles
  Dim k: For k = 1 To 3
    s = Replace(s, "  ", " ")
  Next
  ' Normalize NBSP next to ASCII letters/punct (keep in HTML entities if needed)
  s = Replace(s, nbsp, " ")
  NormalizeSpaces = s
End Function

'================== Core reinterpretation ==================
Function Reinterpret_W1252_to_UTF8_CopyTo(badText)
  On Error Resume Next
  Dim sIn, sOut, out
  Set sIn = CreateObject("ADODB.Stream")
  sIn.Type = 2
  sIn.Charset = "windows-1252"
  sIn.Open
  sIn.WriteText badText
  sIn.Position = 0
  sIn.Type = 1 ' binary

  Set sOut = CreateObject("ADODB.Stream")
  sOut.Type = 1
  sOut.Open
  sIn.CopyTo sOut

  sOut.Position = 0
  sOut.Type = 2
  sOut.Charset = "utf-8"
  out = sOut.ReadText

  sIn.Close
  sOut.Close
  If Err.Number <> 0 Or Len(out) = 0 Then out = badText
  Reinterpret_W1252_to_UTF8_CopyTo = out
  On Error GoTo 0
End Function

'================== Logging ==================
Function ShieldDefaultLogPath()
  On Error Resume Next
  Dim fso, scriptFolder
  Set fso = CreateObject("Scripting.FileSystemObject")
  scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
  If Len(scriptFolder) = 0 Then scriptFolder = "."
  ShieldDefaultLogPath = scriptFolder & "\mail_util.log"
  On Error GoTo 0
End Function

Sub LogShield(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = ShieldDefaultLogPath()
  Dim fso, f: Set fso = CreateObject("Scripting.FileSystemObject")
  Dim ts: Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
  On Error GoTo 0
End Sub
