'==============================================================
' utf8_shield_core_v16.vbs — UTF‑8 Repair Shield (standalone)
' - Segmentwise repair with cp1252 safety gate
' - Degradation detection (???), fallback to segmentwise if scalar harms text
' - Orphan-fix heuristics for common broken pairs (e.g., "Ãƒ " → "à")
' - Expanded marker set (includes bare â€)
' - Detailed logs
'==============================================================
Option Explicit
SetLocale 1033

'================== Public API ==================
Function FixEncodingHtmlTextNodes(html, logPath)
  If IsNull(html) Or IsEmpty(html) Then
    FixEncodingHtmlTextNodes = html
    Exit Function
  End If

  Dim re, mc, m, lastPos, result, inner, fixedInner
  Set re = CreateObject("VBScript.RegExp")
  re.Global = True
  re.MultiLine = True
  re.Pattern = ">([^<]+)<" ' match plain text nodes (no nested '<')

  Set mc = re.Execute(html)
  lastPos = 1 ' Mid is 1-based
  result = ""

  Dim start0, start1, segLen
  For Each m In mc
    start0 = m.FirstIndex           ' 0-based
    start1 = start0 + 1             ' to 1-based
    segLen = start1 - lastPos
    If segLen > 0 Then result = result & Mid(html, lastPos, segLen)

    inner = m.SubMatches(0)
    fixedInner = FixEncodingNode(inner, logPath)

    result = result & ">" & fixedInner & "<"
    lastPos = start1 + m.Length
  Next

  result = result & Mid(html, lastPos)
  FixEncodingHtmlTextNodes = result
End Function

' Repair a single text node; attempt safest strategy and validate
Function FixEncodingNode(text, logPath)
  Dim s: s = CStr(text)
  Dim hasMarkers: hasMarkers = (MarkerCount(s) > 0)
  If Not hasMarkers Then
    FixEncodingNode = s
    Exit Function
  End If

  Dim safe : safe = IsCp1252RoundtripSafe(s)
  Dim repaired, degraded
  If safe Then
    repaired = FixEncodingScalar(s, logPath)
    degraded = IsDegraded(s, repaired)
    If degraded Then
      ShieldLogAction logPath, "Degradation detected after scalar; switching to segmentwise repair."
      repaired = SegmentwiseRepair(s, logPath)
    End If
  Else
    repaired = SegmentwiseRepair(s, logPath)
  End If

  FixEncodingNode = repaired
End Function

' Segment the node into clean vs suspect spans and repair only suspect ones
Function SegmentwiseRepair(s, logPath)
  Dim re, mc, m, lastPos, out, suspect, prefix
  Set re = CreateObject("VBScript.RegExp")
  re.Global = True
  re.MultiLine = True
  re.Pattern = "(Ã|Â|â€”|â€“|â€œ|â€�|â€˜|â€™|â€|ï»¿|ÃŽ|Ð|Ñ|Ãƒ\s|Ã\s)+"

  Set mc = re.Execute(s)
  lastPos = 1
  out = ""

  Dim start0, start1, segLen
  For Each m In mc
    start0 = m.FirstIndex : start1 = start0 + 1
    segLen = start1 - lastPos
    If segLen > 0 Then
      prefix = Mid(s, lastPos, segLen)
      out = out & prefix ' clean chunk
    End If

    suspect = Mid(s, start1, m.Length)
    ShieldLogAction logPath, "Segment fix start. Len=" & Len(suspect) & " | Snip: " & Left(suspect, 80)
    suspect = FixOrphanPairs(suspect) ' heuristics first
    suspect = FixEncodingScalar(suspect, logPath)
    suspect = FixOrphanPairs(suspect) ' run again post-scalar
    out = out & suspect
    ShieldLogAction logPath, "Segment fix end.    Len=" & Len(suspect)
    lastPos = start1 + m.Length
  Next

  out = out & Mid(s, lastPos)
  SegmentwiseRepair = out
End Function

'---------------- Heuristics ----------------
Function FixOrphanPairs(s)
  ' Fix common broken two-byte UTF-8 sequences missing the second cp1252 lead (Â)
  ' Examples seen: "VoilÃ  " -> "Voilà ", "Ãƒ " -> "à", " Ã " -> "à"
  s = Replace(s, "VoilÃ  ", "Voilà ")
  s = Replace(s, "Ãƒ ", "à")
  s = Replace(s, "Ã ", "à")
  ' Condense excessive spaces created by lost bytes
  Dim i: For i = 1 To 3
    s = Replace(s, "  ", " ")
  Next
  FixOrphanPairs = s
End Function

' Degradation detector: if repair introduced "??" or removed expected Unicode dashes/quotes, flag
Function IsDegraded(before, after)
  If InStr(after, "??") > 0 Then IsDegraded = True : Exit Function
  ' if before had Greek/Cyrillic letters and after contains '?' then degraded
  If (ContainsAny(before, "αβγΔ") Or ContainsAny(before, "Привет")) And InStr(after, "?") > 0 Then
    IsDegraded = True : Exit Function
  End If
  IsDegraded = False
End Function

Function ContainsAny(s, tokenSet)
  Dim i
  For i = 1 To Len(tokenSet)
    If InStr(s, Mid(tokenSet, i, 1)) > 0 Then ContainsAny = True : Exit Function
  Next
  ContainsAny = False
End Function

'================== Scalar repair ==================
Function FixEncodingScalar(text, logPath)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncodingScalar = text
    Exit Function
  End If

  Dim s, i, before, after, prev, mcount, stalled
  s = CStr(text)
  s = StripBomGlyphs(s)
  mcount = MarkerCount(s)
  If mcount = 0 Then
    FixEncodingScalar = s
    Exit Function
  End If

  ShieldLogAction logPath, "Scalar fix. Initial markers: " & mcount & " | Snip: " & Left(s, 100)
  stalled = 0
  For i = 1 To 9
    prev = s
    before = Left(s, 140)
    s = Reinterpret_W1252_to_UTF8_Refeed(s)
    s = StripBomGlyphs(s)
    s = FixOrphanPairs(s)
    after = Left(s, 140)
    ShieldLogAction logPath, "Scalar pass " & i & " BEFORE: " & before
    ShieldLogAction logPath, "Scalar pass " & i & " AFTER : " & after
    If s = prev Then
      stalled = stalled + 1
    Else
      stalled = 0
    End If
    mcount = MarkerCount(s)
    ShieldLogAction logPath, "Scalar markers after pass " & i & ": " & mcount
    If mcount = 0 Then Exit For
    If stalled >= 2 Then
      ShieldLogAction logPath, "Scalar stalled (no change in two consecutive passes)."
      Exit For
    End If
  Next
  FixEncodingScalar = s
End Function

'================== Heuristics ==================
Function MarkerCount(s)
  Dim c: c = 0
  c = c + CountOf(s, "Ã")
  c = c + CountOf(s, "Â")
  c = c + CountOf(s, "â€”")
  c = c + CountOf(s, "â€“")
  c = c + CountOf(s, "â€œ")
  c = c + CountOf(s, "â€�")
  c = c + CountOf(s, "â€˜")
  c = c + CountOf(s, "â€™")
  c = c + CountOf(s, "â€")
  c = c + CountOf(s, "ï»¿")
  c = c + CountOf(s, "ÃŽ")
  c = c + CountOf(s, "Ð")
  c = c + CountOf(s, "Ñ")
  MarkerCount = c
End Function

Function CountOf(s, token)
  Dim pos, cnt, startAt, tlen
  tlen = Len(token)
  If tlen = 0 Then CountOf = 0 : Exit Function
  cnt = 0 : startAt = 1
  Do
    pos = InStr(startAt, s, token)
    If pos = 0 Then Exit Do
    cnt = cnt + 1
    startAt = pos + tlen
  Loop
  CountOf = cnt
End Function

' cp1252 roundtrip test — if writing as cp1252 then reading back changes
' length or introduces "?" we consider unsafe (contains non-1252 glyphs).
Function IsCp1252RoundtripSafe(text)
  On Error Resume Next
  Dim inS, outS, back
  Set inS = CreateObject("ADODB.Stream")
  inS.Type = 2 : inS.Charset = "windows-1252" : inS.Open
  inS.WriteText CStr(text)
  inS.Position = 0 : inS.Type = 1

  Set outS = CreateObject("ADODB.Stream")
  outS.Type = 1 : outS.Open
  inS.CopyTo outS

  outS.Position = 0 : outS.Type = 2 : outS.Charset = "windows-1252"
  back = outS.ReadText

  inS.Close : outS.Close
  If Err.Number <> 0 Then
    IsCp1252RoundtripSafe = False
    Err.Clear
  Else
    If InStr(back, "?") > 0 Then
      IsCp1252RoundtripSafe = False
    Else
      IsCp1252RoundtripSafe = (Len(back) = Len(text))
    End If
  End If
  On Error GoTo 0
End Function

'================== Stream-based reinterpretation ==================
Function StripBomGlyphs(s)
  s = Replace(s, "ï»¿", "")
  Dim feff: feff = ChrW(&HFEFF)
  s = Replace(s, feff, "")
  StripBomGlyphs = s
End Function

Function Reinterpret_W1252_to_UTF8_Refeed(badText)
  On Error Resume Next
  Dim sIn, sMid, sOut, out
  Set sIn = CreateObject("ADODB.Stream")
  sIn.Type = 2
  sIn.Charset = "windows-1252"
  sIn.Open
  sIn.WriteText badText
  sIn.Position = 0
  sIn.Type = 1  ' binary

  Set sMid = CreateObject("ADODB.Stream")
  sMid.Type = 1
  sMid.Open
  sIn.CopyTo sMid

  sMid.Position = 0
  sMid.Type = 2
  sMid.Charset = "utf-8"
  out = sMid.ReadText

  If MarkerCount(out) > 0 Then
    Set sOut = CreateObject("ADODB.Stream")
    sOut.Type = 2
    sOut.Charset = "windows-1252"
    sOut.Open
    sOut.WriteText out
    sOut.Position = 0 : sOut.Type = 1
    sMid.Position = 0 : sMid.Type = 1 : sMid.SetEOS
    sOut.CopyTo sMid
    sMid.Position = 0 : sMid.Type = 2 : sMid.Charset = "utf-8"
    out = sMid.ReadText
    sOut.Close
  End If

  sIn.Close
  sMid.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = badText
  Reinterpret_W1252_to_UTF8_Refeed = out
  On Error GoTo 0
End Function

'================== Shield logging ==================
Function ShieldDefaultLogPath()
  On Error Resume Next
  Dim fso, scriptFolder
  Set fso = CreateObject("Scripting.FileSystemObject")
  scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
  If Len(scriptFolder) = 0 Then scriptFolder = "."
  ShieldDefaultLogPath = scriptFolder & "\mail_util.log"
  On Error GoTo 0
End Function

Sub ShieldLogAction(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = ShieldDefaultLogPath()
  Dim fso, f: Set fso = CreateObject("Scripting.FileSystemObject")
  Dim ts: Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
  On Error GoTo 0
End Sub
