UTF‑8 Shield Split v16 — Package
=================================

What’s fixed
------------
• Prevents regressions where scalar repair could degrade Greek/Cyrillic by:
  - cp1252 safety gate
  - degradation detection (“??” or loss) with fallback to segmentwise
• Recovers common orphan pairs (“Ãƒ ” without “Â”) via a small heuristic.
• Expanded marker set catches bare “â€”/â€“/â€ ...” patterns.

Files
-----
1) utf8_shield_core_v16.vbs
2) mail_utils_mailer_v16.vbs
3) test_shield_split_v16_normal.vbs
4) test_shield_split_v16_repair.vbs

Run
---
• Put all files in the SAME folder and execute the tests.
• Inspect mail_util.log for “Segment fix …” vs “Scalar fix …” and “Degradation detected …” messages.
