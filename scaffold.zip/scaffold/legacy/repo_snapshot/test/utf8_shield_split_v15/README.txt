UTF‑8 Shield Split v15 — Package
=================================

Files
-----
1) utf8_shield_core_v15.vbs
   • Standalone encoding repair (node-scoped, segmentwise, cp1252-safety gate)
   • Public functions:
     - FixEncodingHtmlTextNodes(html, logPath)
     - FixEncodingScalar(text, logPath)

2) mail_utils_mailer_v15.vbs
   • Outlook mailer that loads shield core from same folder.
   • Public function:
     - CreateMail(to, cc, bcc, subject, htmlBody, attachPaths, action, savePath, templateSource, inlineImgFolder, deferMinutes, logPath)

3) test_shield_split_v15_normal.vbs
4) test_shield_split_v15_repair.vbs
5) test_shield_split_v15_edges.vbs

What’s new in v15
-----------------
• **SegmentwiseRepair**: only mojibake clusters are decoded; clean Unicode stays intact (prevents v10 regressions).
• **cp1252 safety gate**: if a node cannot roundtrip through Windows-1252 without loss, we avoid whole-node repair and repair only suspect segments.
• Stronger diagnostics: logs “Segment fix start/end”, cp1252 safety choices, and scalar passes.

How to use
----------
• Place all files in the SAME folder.
• Double-click any test script. The mailer loads the shield core with ExecuteGlobal.
• Logs go to: mail_util.log in the same folder.

Tuning
------
If a stubborn pattern remains, add it to the marker regex in **SegmentwiseRepair** or increase scalar passes from 7 → 9.
