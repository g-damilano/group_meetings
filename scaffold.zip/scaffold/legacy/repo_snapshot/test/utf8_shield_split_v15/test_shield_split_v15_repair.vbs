' test_shield_split_v15_repair.vbs
Option Explicit
SetLocale 1033

ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_mailer_v15.vbs",1).ReadAll

Dim files, html, subj, ok, logPath
logPath = ""
subj = "Shield Split v15 — Repair"
html = "<h3>Shield v15 Mapping Test (Mojibake)</h3>" & _
       "<p>1) ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¥ ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¤ ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¶ ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â© ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¨ ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âª ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â«</p>" & _
       "<p>2) Ã„â€¡ Ã„â� Ã…Â¡ Ã…Â¾ Ã…â„¢ Ã…Â¯</p>" & _
       "<p>3) ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â± ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­ ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³ ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âº</p>" & _
       "<p>4) ÃƒÅ¸ Ãƒâ€ž Ãƒâ€“ ÃƒÅ“</p>" & _
       "<p>5) Ã…â€œ ÃƒÂ§ ÃƒÂ© Ãƒ </p>" & _
       "<p>6) â€” â€“ â€œ â€� â€˜ â€™</p>" & _
       "<p>7) â‚¬ Â£ Â¥</p>" & _
       "<p>8) VoilÃƒ  seÃƒÂ±or GroÃƒÅ¸zÃƒÂ¼gig</p>" & _
       "<p>9) Greek: Î± Î² Î³ Î”</p>" & _
       "<p>10) Cyrillic: ÐŸÑ€Ð¸Ð²ÐµÑ‚</p>"

files = Array()
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)
