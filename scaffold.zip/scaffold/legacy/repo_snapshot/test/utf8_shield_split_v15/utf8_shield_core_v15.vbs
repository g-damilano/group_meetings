'==============================================================
' utf8_shield_core_v15.vbs — UTF‑8 Repair Shield (standalone)
' - Node-scoped decoding with correct HTML reassembly
' - Segment-level repair only where markers exist (preserves clean text)
' - cp1252-safety gate to avoid over-decoding non-1252 scripts
' - Multi-pass Win-1252→UTF-8 reinterpretation per segment
' - Marker diagnostics, stall detection, BOM scrubbing
' - Self-contained logging (ShieldLogAction)
'==============================================================
Option Explicit
SetLocale 1033

'================== Public API ==================
Function FixEncodingHtmlTextNodes(html, logPath)
  If IsNull(html) Or IsEmpty(html) Then
    FixEncodingHtmlTextNodes = html
    Exit Function
  End If

  Dim re, mc, m, lastPos, result, inner, fixedInner
  Set re = CreateObject("VBScript.RegExp")
  re.Global = True
  re.MultiLine = True
  re.Pattern = ">([^<]+)<" ' match plain text nodes (no nested '<')

  Set mc = re.Execute(html)
  lastPos = 1 ' Mid is 1-based
  result = ""

  Dim start0, start1, segLen
  For Each m In mc
    start0 = m.FirstIndex           ' 0-based
    start1 = start0 + 1             ' to 1-based
    segLen = start1 - lastPos
    If segLen > 0 Then result = result & Mid(html, lastPos, segLen)

    inner = m.SubMatches(0)
    fixedInner = FixEncodingNode(inner, logPath)

    result = result & ">" & fixedInner & "<"
    lastPos = start1 + m.Length
  Next

  result = result & Mid(html, lastPos)
  FixEncodingHtmlTextNodes = result
End Function

' Repair a single text node with segmentation by markers + cp1252 safety
Function FixEncodingNode(text, logPath)
  Dim s: s = CStr(text)
  Dim hasMarkers: hasMarkers = (MarkerCount(s) > 0)
  If Not hasMarkers Then
    FixEncodingNode = s
    Exit Function
  End If

  ' If node contains non-1252 characters AND only few/weak markers, avoid global repair
  Dim safe : safe = IsCp1252RoundtripSafe(s)
  If Not safe Then
    ' segment by marker clusters and only repair marked segments
    FixEncodingNode = SegmentwiseRepair(s, logPath)
  Else
    ' scalar full repair
    FixEncodingNode = FixEncodingScalar(s, logPath)
  End If
End Function

' Segment the node into clean vs suspect spans and repair only suspect ones
Function SegmentwiseRepair(s, logPath)
  Dim re, mc, m, lastPos, out, chunk
  Set re = CreateObject("VBScript.RegExp")
  re.Global = True
  re.MultiLine = True
  re.Pattern = "(Ã|Â|â€”|â€“|â€œ|â€�|â€˜|â€™|ï»¿|ÃŽ|Ð|Ñ)+"

  Set mc = re.Execute(s)
  lastPos = 1
  out = ""

  Dim start0, start1, segLen, suspect
  For Each m In mc
    start0 = m.FirstIndex : start1 = start0 + 1
    segLen = start1 - lastPos
    If segLen > 0 Then
      out = out & Mid(s, lastPos, segLen) ' clean prefix
    End If
    suspect = Mid(s, start1, m.Length)
    ShieldLogAction logPath, "Segment fix start. Len=" & Len(suspect) & " | Snip: " & Left(suspect, 80)
    out = out & FixEncodingScalar(suspect, logPath)
    ShieldLogAction logPath, "Segment fix end.    Len=" & Len(suspect)
    lastPos = start1 + m.Length
  Next

  out = out & Mid(s, lastPos)
  SegmentwiseRepair = out
End Function

'================== Scalar repair ==================
Function FixEncodingScalar(text, logPath)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncodingScalar = text
    Exit Function
  End If

  Dim s, i, before, after, prev, mcount, stalled
  s = CStr(text)
  s = StripBomGlyphs(s)
  mcount = MarkerCount(s)
  If mcount = 0 Then
    FixEncodingScalar = s
    Exit Function
  End If

  ShieldLogAction logPath, "Scalar fix. Initial markers: " & mcount & " | Snip: " & Left(s, 100)
  stalled = 0
  For i = 1 To 7
    prev = s
    before = Left(s, 140)
    s = Reinterpret_W1252_to_UTF8_Refeed(s)
    s = StripBomGlyphs(s)
    after = Left(s, 140)
    ShieldLogAction logPath, "Scalar pass " & i & " BEFORE: " & before
    ShieldLogAction logPath, "Scalar pass " & i & " AFTER : " & after
    If s = prev Then
      stalled = stalled + 1
    Else
      stalled = 0
    End If
    mcount = MarkerCount(s)
    ShieldLogAction logPath, "Scalar markers after pass " & i & ": " & mcount
    If mcount = 0 Then Exit For
    If stalled >= 2 Then
      ShieldLogAction logPath, "Scalar stalled (no change in two consecutive passes)."
      Exit For
    End If
  Next
  FixEncodingScalar = s
End Function

'================== Heuristics ==================
Function MarkerCount(s)
  Dim c: c = 0
  c = c + CountOf(s, "Ã")
  c = c + CountOf(s, "Â")
  c = c + CountOf(s, "â€”")
  c = c + CountOf(s, "â€“")
  c = c + CountOf(s, "â€œ")
  c = c + CountOf(s, "â€�")
  c = c + CountOf(s, "â€˜")
  c = c + CountOf(s, "â€™")
  c = c + CountOf(s, "ï»¿")
  c = c + CountOf(s, "ÃŽ")
  c = c + CountOf(s, "Ð")
  c = c + CountOf(s, "Ñ")
  MarkerCount = c
End Function

Function CountOf(s, token)
  Dim pos, cnt, startAt, tlen
  tlen = Len(token)
  If tlen = 0 Then CountOf = 0 : Exit Function
  cnt = 0 : startAt = 1
  Do
    pos = InStr(startAt, s, token)
    If pos = 0 Then Exit Do
    cnt = cnt + 1
    startAt = pos + tlen
  Loop
  CountOf = cnt
End Function

' cp1252 roundtrip test — if writing as cp1252 then reading back changes
' length or introduces "?" we consider unsafe (contains non-1252 glyphs).
Function IsCp1252RoundtripSafe(text)
  On Error Resume Next
  Dim inS, outS, back
  Set inS = CreateObject("ADODB.Stream")
  inS.Type = 2 : inS.Charset = "windows-1252" : inS.Open
  inS.WriteText CStr(text)
  inS.Position = 0 : inS.Type = 1

  Set outS = CreateObject("ADODB.Stream")
  outS.Type = 1 : outS.Open
  inS.CopyTo outS

  outS.Position = 0 : outS.Type = 2 : outS.Charset = "windows-1252"
  back = outS.ReadText

  inS.Close : outS.Close
  If Err.Number <> 0 Then
    IsCp1252RoundtripSafe = False
    Err.Clear
  Else
    ' if roundtrip produced "?" or changed length, consider unsafe
    If InStr(back, "?") > 0 Then
      IsCp1252RoundtripSafe = False
    Else
      IsCp1252RoundtripSafe = (Len(back) = Len(text))
    End If
  End If
  On Error GoTo 0
End Function

'================== Stream-based reinterpretation ==================
Function StripBomGlyphs(s)
  s = Replace(s, "ï»¿", "")
  Dim feff: feff = ChrW(&HFEFF)
  s = Replace(s, feff, "")
  StripBomGlyphs = s
End Function

Function Reinterpret_W1252_to_UTF8_Refeed(badText)
  On Error Resume Next
  Dim sIn, sMid, sOut, out
  Set sIn = CreateObject("ADODB.Stream")
  sIn.Type = 2
  sIn.Charset = "windows-1252"
  sIn.Open
  sIn.WriteText badText
  sIn.Position = 0
  sIn.Type = 1  ' binary

  Set sMid = CreateObject("ADODB.Stream")
  sMid.Type = 1
  sMid.Open
  sIn.CopyTo sMid

  sMid.Position = 0
  sMid.Type = 2
  sMid.Charset = "utf-8"
  out = sMid.ReadText

  If MarkerCount(out) > 0 Then
    Set sOut = CreateObject("ADODB.Stream")
    sOut.Type = 2
    sOut.Charset = "windows-1252"
    sOut.Open
    sOut.WriteText out
    sOut.Position = 0 : sOut.Type = 1
    sMid.Position = 0 : sMid.Type = 1 : sMid.SetEOS
    sOut.CopyTo sMid
    sMid.Position = 0 : sMid.Type = 2 : sMid.Charset = "utf-8"
    out = sMid.ReadText
    sOut.Close
  End If

  sIn.Close
  sMid.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = badText
  Reinterpret_W1252_to_UTF8_Refeed = out
  On Error GoTo 0
End Function

'================== Shield logging ==================
Function ShieldDefaultLogPath()
  On Error Resume Next
  Dim fso, scriptFolder
  Set fso = CreateObject("Scripting.FileSystemObject")
  scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
  If Len(scriptFolder) = 0 Then scriptFolder = "."
  ShieldDefaultLogPath = scriptFolder & "\mail_util.log"
  On Error GoTo 0
End Function

Sub ShieldLogAction(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = ShieldDefaultLogPath()
  Dim fso, f: Set fso = CreateObject("Scripting.FileSystemObject")
  Dim ts: Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
  On Error GoTo 0
End Sub
