' test_shield_split_v15_edges.vbs
Option Explicit
SetLocale 1033

ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_mailer_v15.vbs",1).ReadAll

Dim files, html, subj, ok, logPath
logPath = ""
subj = "Shield Split v15 — Edge Cases"

html = "<h3>Shield v15 Edge/Stress Tests</h3>" & _
  "<p>A) Mixed node: Good αβγ + bad Ã¢â‚¬Å“quotesÃ¢â‚¬Â + Cyrillic Привет intact</p>" & _
  "<p>B) Partial cluster: startÃƒâ€”middle and end clean.</p>" & _
  "<p>C) Currency soup: â‚¬ price Â£ cost Â¥ yen → should become € £ ¥</p>" & _
  "<p>D) Punct: â€” dash â€“ ndash â€˜leftâ€™ â€œdoubleâ€�</p>" & _
  "<p>E) Triple layer: ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â± (should become ñ)</p>" & _
  "<p>F) BOM glyphs: ï»¿Hidden BOM removed.</p>" & _
  "<p>G) Greek preserved: Greek αβγΔ should not be touched.</p>" & _
  "<p>H) Cyrillic preserved: Привет remains unchanged.</p>" & _
  "<p>I) Long line with multiple segments: 1) ÃƒÂ© ok 2) α ok 3) â€” fix 4) Привет ok 5) ÃƒÂ± fix</p>"

files = Array()
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)
