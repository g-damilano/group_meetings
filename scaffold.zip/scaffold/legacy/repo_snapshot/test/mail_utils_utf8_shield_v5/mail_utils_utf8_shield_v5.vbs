'======================================================================
' mail_utils_utf8_shield_v5.vbs — Outlook Mail Utility (UTF‑8 Shield v5)
' Strategy:
'   • Detect mojibake markers ("Ã", "Â", "â", "ï»¿", "�")
'   • Iteratively apply Win-1252 → UTF-8 reinterpretation up to 3 passes
'   • Strip any UTF‑8 BOM glyphs (ï»¿) and zero-width BOM (U+FEFF)
'   • Never touch already-clean Unicode
'======================================================================
Option Explicit
SetLocale 1033

Const olMailItem = 0
Const olFormatHTML = 2
Const olMSG = 3
Const PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"

Function CreateMail(toAddr, ccAddr, bccAddr, subjectText, htmlBody, attachPaths, _
                    action, savePath, templateSource, inlineImgFolder, deferMinutes, logPath)
  On Error Resume Next
  EncodingHealthCheck logPath

  Dim ok, olApp, olMail, sigHTML, f, fso, bodyHtml
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set olApp = GetOutlookApp()

  If Len(Trim(templateSource)) > 0 Then
    bodyHtml = LoadHtmlFromSource(templateSource)
  Else
    bodyHtml = htmlBody
  End If

  subjectText = FixEncoding(subjectText)
  bodyHtml    = FixEncoding(bodyHtml)

  Set olMail = olApp.CreateItem(olMailItem)
  sigHTML = LoadSignatureWithImages(olMail)

  With olMail
    .To = FixEncoding(toAddr)
    .CC = FixEncoding(ccAddr)
    .BCC = FixEncoding(bccAddr)
    .Subject = subjectText
    .BodyFormat = olFormatHTML
    .HTMLBody = "<html><body style='font-family:Segoe UI, Arial, sans-serif;'>" & bodyHtml & sigHTML & "</body></html>"

    If Not IsEmpty(attachPaths) Then
      For Each f In attachPaths
        If Len(Trim(f)) > 0 And fso.FileExists(f) Then .Attachments.Add f
      Next
    End If

    If Len(Trim(inlineImgFolder)) > 0 And fso.FolderExists(inlineImgFolder) Then
      EmbedImagesFromFolder olMail, inlineImgFolder
    End If

    If IsNumeric(deferMinutes) And CDbl(deferMinutes) > 0 Then
      .DeferredDeliveryTime = Now + (CDbl(deferMinutes) / (24 * 60))
    End If

    Select Case LCase(action)
      Case "send"   : .Send : LogAction logPath, "Sent: " & subjectText
      Case "save"
        If Len(Trim(savePath)) > 0 Then
          .SaveAs savePath, olMSG : LogAction logPath, "Saved as: " & savePath
        Else
          .Save : LogAction logPath, "Saved to Drafts: " & subjectText
        End If
      Case Else     : .Display : LogAction logPath, "Displayed: " & subjectText
    End Select
  End With

  If Err.Number <> 0 Then
    LogAction logPath, "ERROR: " & Err.Number & " - " & Err.Description
    ok = False
  Else
    ok = True
  End If

  CreateMail = ok
  On Error GoTo 0
End Function

'================== UTF‑8 Shield (v5) ==================
Function FixEncoding(text)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncoding = text
    Exit Function
  End If
  Dim s, i, prev
  s = CStr(text)
  If Not HasMojibakeMarkers(s) Then
    FixEncoding = StripBomGlyphs(s)
    Exit Function
  End If
  For i = 1 To 3
    prev = s
    s = Reinterpret_W1252_to_UTF8(s)
    s = StripBomGlyphs(s)
    If s = prev Or Not HasMojibakeMarkers(s) Then Exit For
  Next
  FixEncoding = s
End Function

Function HasMojibakeMarkers(s)
  HasMojibakeMarkers = (InStr(s, "Ã") > 0) Or (InStr(s, "Â") > 0) Or (InStr(s, "â") > 0) Or (InStr(s, "ï»¿") > 0) Or (InStr(s, "�") > 0)
End Function

Function StripBomGlyphs(s)
  ' Remove visible UTF‑8 BOM "ï»¿" and zero-width BOM U+FEFF
  s = Replace(s, "ï»¿", "")
  Dim feff: feff = ChrW(&HFEFF)
  s = Replace(s, feff, "")
  StripBomGlyphs = s
End Function

Function Reinterpret_W1252_to_UTF8(badText)
  On Error Resume Next
  Dim stream, bytes, out
  ' Treat current Unicode as Windows-1252 bytes -> decode as UTF-8
  Set stream = CreateObject("ADODB.Stream")
  stream.Type = 2 : stream.Charset = "windows-1252" : stream.Open
  stream.WriteText badText
  stream.Position = 0 : stream.Type = 1 : bytes = stream.Read : stream.Close

  stream.Open : stream.Type = 1 : stream.Write bytes
  stream.Position = 0 : stream.Type = 2 : stream.Charset = "utf-8"
  out = stream.ReadText : stream.Close

  If Err.Number <> 0 Or Len(out)=0 Then out = badText
  Reinterpret_W1252_to_UTF8 = out
  On Error GoTo 0
End Function
'=======================================================

'--- Helpers ---
Sub EmbedImagesFromFolder(olMail, folderPath)
  Dim fso, file, cid, att
  Set fso = CreateObject("Scripting.FileSystemObject")
  For Each file In fso.GetFolder(folderPath).Files
    cid = fso.GetFileName(file.Name)
    Set att = olMail.Attachments.Add(file.Path)
    att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
  Next
End Sub

Function GetOutlookApp()
  Dim app
  On Error Resume Next
  Set app = GetObject(, "Outlook.Application")
  If Err.Number <> 0 Then
    Err.Clear
    Set app = CreateObject("Outlook.Application")
  End If
  On Error GoTo 0
  Set GetOutlookApp = app
End Function

Function LoadSignatureWithImages(olMail)
  Dim fso, shell, sigPath, folder, file, sigHTML, sigFile, baseName, imgFolder, imgFile, att, imgName, cid
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set shell = CreateObject("WScript.Shell")
  sigPath = shell.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\Signatures\"
  sigHTML = ""

  If fso.FolderExists(sigPath) Then
    Set folder = fso.GetFolder(sigPath)
    For Each file In folder.Files
      If LCase(fso.GetExtensionName(file.Name)) = "htm" Then
        sigFile = file.Path
        baseName = fso.GetBaseName(file.Name)
        sigHTML = ReadUTF8File(sigFile)
        Exit For
      End If
    Next
  End If

  imgFolder = sigPath & baseName & ".files"
  If fso.FolderExists(imgFolder) Then
    For Each imgFile In fso.GetFolder(imgFolder).Files
      imgName = fso.GetFileName(imgFile.Name)
      cid = Replace(imgName, " ", "_")
      Set att = olMail.Attachments.Add(imgFile.Path)
      att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
      sigHTML = Replace(sigHTML, baseName & ".files/" & imgName, "cid:" & cid)
      sigHTML = Replace(sigHTML, baseName & ".files\" & imgName, "cid:" & cid)
    Next
  End If

  LoadSignatureWithImages = sigHTML
End Function

Function ReadUTF8File(filePath)
  Dim s : Set s = CreateObject("ADODB.Stream")
  s.Type = 2 : s.Charset = "utf-8" : s.Open : s.LoadFromFile filePath
  ReadUTF8File = s.ReadText : s.Close
End Function

Function LoadHtmlFromSource(src)
  Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
  If Left(LCase(src), 7) = "http://" Or Left(LCase(src), 8) = "https://" Then
    LoadHtmlFromSource = HttpGetUtf8(src)
  ElseIf fso.FileExists(src) Then
    LoadHtmlFromSource = ReadUTF8File(src)
  Else
    LoadHtmlFromSource = src
  End If
End Function

Function HttpGetUtf8(url)
  Dim xhr, stm, txt
  Set xhr = CreateObject("MSXML2.XMLHTTP")
  xhr.Open "GET", url, False
  xhr.Send
  If xhr.Status = 200 Then
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 1 : stm.Open : stm.Write xhr.responseBody
    stm.Position = 0 : stm.Type = 2 : stm.Charset = "utf-8"
    txt = stm.ReadText : stm.Close
    HttpGetUtf8 = txt
  Else
    HttpGetUtf8 = "<p>Failed to load template. HTTP " & xhr.Status & "</p>"
  End If
End Function

Sub LogAction(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then Exit Sub
  Dim fso, f : Set fso = CreateObject("Scripting.FileSystemObject")
  Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
End Sub
