' test_shield_v5_normal.vbs
Option Explicit
SetLocale 1033
Dim files, html, subj, ok
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_utf8_shield_v5.vbs",1).ReadAll

subj = "Shield Layer " & ChrW(&H2013) & " Normal"
html = "<h3>Shield Normal</h3><p>Accents: " & _
       ChrW(&HE5) & ", " & ChrW(&H107) & ", " & ChrW(&HE9) & ", " & ChrW(&HF1) & ", " & ChrW(&HF6) & _
       " - em dash " & ChrW(&H2014) & " / en dash " & ChrW(&H2013) & ".</p>"

files = Array()
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, "C:\Temp\mail_util.log")
