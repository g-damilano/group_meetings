Option Explicit
Const olMailItem = 0
Const olFormatHTML = 2
Const PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"

Function CreateMail(toAddr, ccAddr, bccAddr, subject, htmlBody, attachPaths, _
                    action, savePath, templatePath, inlineImgFolder, deferMinutes)
  On Error Resume Next
  Dim olApp, olMail, sigHTML, f, fso, errMsg
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set olApp = GetOutlookApp()

  If Len(Trim(templatePath)) > 0 And fso.FileExists(templatePath) Then
    Set olMail = olApp.CreateItemFromTemplate(templatePath)
  Else
    Set olMail = olApp.CreateItem(olMailItem)
  End If

  sigHTML = LoadSignatureWithImages(olMail)

  If Len(Trim(htmlBody)) = 0 And Len(Trim(templatePath)) > 0 Then
    htmlBody = fso.OpenTextFile(templatePath, 1).ReadAll
  End If

  With olMail
    .To = toAddr
    .CC = ccAddr
    .BCC = bccAddr
    .Subject = subject
    .BodyFormat = olFormatHTML
    .HTMLBody = "<html><body style='font-family:Segoe UI;'>" & htmlBody & sigHTML & "</body></html>"

    If Not IsEmpty(attachPaths) Then
      For Each f In attachPaths
        If Len(Trim(f)) > 0 And fso.FileExists(f) Then .Attachments.Add f
      Next
    End If

    If Len(Trim(inlineImgFolder)) > 0 And fso.FolderExists(inlineImgFolder) Then
      EmbedImagesFromFolder olMail, inlineImgFolder
    End If

    If IsNumeric(deferMinutes) And deferMinutes > 0 Then
      .DeferredDeliveryTime = Now + (deferMinutes / (24*60))
    End If

    Select Case LCase(action)
      Case "send"   : .Send
      Case "save"
        If Len(Trim(savePath)) > 0 Then
          .SaveAs savePath, 3
        Else
          .Save
        End If
      Case Else     : .Display
    End Select
  End With

  If Err.Number <> 0 Then
    errMsg = "Mail creation failed: " & Err.Description
    WScript.Echo errMsg
    CreateMail = False
  Else
    CreateMail = True
  End If
  On Error GoTo 0
End Function

Function EmbedImagesFromFolder(olMail, folderPath)
  Dim fso, file, cid, att
  Set fso = CreateObject("Scripting.FileSystemObject")
  For Each file In fso.GetFolder(folderPath).Files
    cid = Replace(fso.GetFileName(file.Name), " ", "_")
    Set att = olMail.Attachments.Add(file.Path)
    att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
  Next
End Function

Function GetOutlookApp()
  Dim app
  On Error Resume Next
  Set app = GetObject(, "Outlook.Application")
  If Err.Number <> 0 Then
    Err.Clear
    Set app = CreateObject("Outlook.Application")
  End If
  On Error GoTo 0
  Set GetOutlookApp = app
End Function

Function LoadSignatureWithImages(olMail)
  Dim fso, shell, sigPath, folder, file, sigHTML, sigFile, baseName, imgFolder, imgFile, att, imgName, cid
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set shell = CreateObject("WScript.Shell")
  sigPath = shell.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\Signatures\"
  sigHTML = ""

  If fso.FolderExists(sigPath) Then
    Set folder = fso.GetFolder(sigPath)
    For Each file In folder.Files
      If LCase(fso.GetExtensionName(file.Name)) = "htm" Then
        sigFile = file.Path
        baseName = fso.GetBaseName(file.Name)
        sigHTML = fso.OpenTextFile(sigFile, 1).ReadAll
        Exit For
      End If
    Next
  End If

  imgFolder = sigPath & baseName & ".files"
  If fso.FolderExists(imgFolder) Then
    For Each imgFile In fso.GetFolder(imgFolder).Files
      imgName = fso.GetFileName(imgFile.Name)
      cid = Replace(imgName, " ", "_")
      Set att = olMail.Attachments.Add(imgFile.Path)
      att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
      sigHTML = Replace(sigHTML, baseName & ".files/" & imgName, "cid:" & cid)
      sigHTML = Replace(sigHTML, baseName & ".files\" & imgName, "cid:" & cid)
    Next
  End If

  LoadSignatureWithImages = sigHTML
End Function
