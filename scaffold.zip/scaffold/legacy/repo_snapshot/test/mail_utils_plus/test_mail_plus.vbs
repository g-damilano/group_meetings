Option Explicit
Dim files, html
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_plus.vbs",1).ReadAll

html = "<h3>Automated Test</h3><p>This message tests <b>mail_utils_plus.vbs</b>.</p>"
files = Array("C:\Temp\testfile.txt")

CreateMail "gd2613@ic.ac.uk", "", "", _
            "VBScript Extended Mail Utility – Test", html, files, _
            "display", "C:\Temp\TestDraft.msg", "", "", 0
