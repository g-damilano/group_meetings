' test_shield_v7_repair.vbs
Option Explicit
SetLocale 1033
Dim files, html, subj, ok, logPath
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_utf8_shield_v7.vbs",1).ReadAll

logPath = "" ' default: same folder

' Single-layer mojibake
subj = "Shield Layer â€“ Repair"
html = "<h3>Shield Repair</h3><p>Accents: Ã¥, Ä‡, Ã©, Ã±, Ã¶ â€” should auto-repair to " & _
       ChrW(&HE5) & ", " & ChrW(&H107) & ", " & ChrW(&HE9) & ", " & ChrW(&HF1) & ", " & ChrW(&HF6) & _
       " " & ChrW(&H2014) & "</p>"

files = Array()
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)
