UTF‑8 Shield Split v18a — Package
===================================
Patch: Adds explicit UTF‑8 <meta> tag to HTML body to improve copy/paste fidelity.

Files
-----
1) utf8_shield_core_v18.vbs        (same core as v18)
2) mail_utils_mailer_v18a.vbs       (UTF‑8 meta tag)
3) test_shield_split_v18a_normal.vbs
4) test_shield_split_v18a_matrix.vbs

Usage
-----
• Place all files in the SAME folder.
• Run the test scripts; Outlook windows open with processed content.
• Check mail_util.log for “Mailer v18a active.” and pass logs.
