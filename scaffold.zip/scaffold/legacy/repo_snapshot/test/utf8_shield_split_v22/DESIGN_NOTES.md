# UTF‑8 Shield v22 — Stratified + Segmented Logic (frozen)

This version implements the locked logic: global stratified passes with score-gated transforms, followed by segmented, per-run candidate selection. Safety invariants enforce markers↓, Greek/Cyrillic not↓, replacements not↑.

## How to test
Run:
- test_shield_split_v22_normal.vbs
- test_shield_split_v22_repair.vbs
- test_shield_split_v22_matrix.vbs

Inspect mail_util.log for per-pass markers/greek/cyr/repl and ensure monotone decrease or stall break before segmentation. Segmented pass chooses best candidate per run (identity vs CopyTo vs double vs alt probe vs maps-only).
