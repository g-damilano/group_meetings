UTF‑8 Shield Split v18 — Package
=================================

What’s in v18 (Hybrid)
----------------------
• Restores **v9 CopyTo reinterpretation core** (Win‑1252 bytes → UTF‑8) with up to 5 passes.
• Keeps **v17 heuristics**: NBSP‑aware orphans (Ã + NBSP / Ãƒ + NBSP → à), contextual **Voilà**, lone **â€ → “**.
• Adds stall detector to stop after two unchanged passes.
• Wide tests: baseline mojibake + orphan stress + mixed Greek/Cyrillic + matrix panel.

Files
-----
1) utf8_shield_core_v18.vbs
2) mail_utils_mailer_v18.vbs
3) test_shield_split_v18_normal.vbs
4) test_shield_split_v18_repair.vbs
5) test_shield_split_v18_matrix.vbs

Usage
-----
• Place all files in the SAME folder.
• Double‑click any test *.vbs to open Outlook message windows.
• Check mail_util.log for “Mailer v18 active.” and pass logs.
