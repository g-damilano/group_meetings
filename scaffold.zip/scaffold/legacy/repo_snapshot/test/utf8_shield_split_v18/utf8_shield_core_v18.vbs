'==============================================================
' utf8_shield_core_v18.vbs — UTF‑8 Repair Shield (Hybrid)
' v9 CopyTo reinterpretation core + v17 orphan & opener fixes + wide logging
'==============================================================
Option Explicit
SetLocale 1033

'================== Public API ==================
' Hybrid high-level fix for any text fragment (safe for Subject, HTML, etc.)
Function FixEncoding(text, logPath)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncoding = text
    Exit Function
  End If
  Dim s, i, before, after, stalled, hadMarkers
  s = CStr(text)

  s = StripBomGlyphs(s)
  s = FixOrphanPairs(s) ' pre-pass to normalize common orphans

  hadMarkers = LooksLikeUtf8AsWin1252(s)
  If Not hadMarkers Then
    FixEncoding = s
    Exit Function
  End If

  stalled = 0
  LogShield logPath, "Hybrid shield v18 — CopyTo core active."
  Dim maxPasses: maxPasses = 5
  For i = 1 To maxPasses
    before = Left(s, 140)
    s = Reinterpret_W1252_to_UTF8_CopyTo(s)
    s = StripBomGlyphs(s)
    s = FixOrphanPairs(s) ' post-pass cleanup (NBSP orphans, VoilÃ, bare â€)
    after = Left(s, 140)
    LogShield logPath, "Pass " & i & " BEFORE: " & before
    LogShield logPath, "Pass " & i & " AFTER : " & after

    If Not LooksLikeUtf8AsWin1252(s) Then Exit For
    If s = before Then
      stalled = stalled + 1
      If stalled >= 2 Then
        LogShield logPath, "Stalled (no change for two passes). Breaking."
        Exit For
      End If
    Else
      stalled = 0
    End If
  Next
  FixEncoding = s
End Function

'================== Heuristics & helpers ==================
Function StripBomGlyphs(s)
  s = Replace(s, "ï»¿", "")
  Dim feff: feff = ChrW(&HFEFF)
  s = Replace(s, feff, "")
  StripBomGlyphs = s
End Function

' Detect typical UTF-8-as-1252 mojibake markers
Function LooksLikeUtf8AsWin1252(s)
  LooksLikeUtf8AsWin1252 = _
      (InStr(s, "Ã") > 0) Or _
      (InStr(s, "Â") > 0) Or _
      (InStr(s, "â€”") > 0) Or (InStr(s, "â€“") > 0) Or (InStr(s, "â€œ") > 0) Or (InStr(s, "â€�") > 0) Or (InStr(s, "â€˜") > 0) Or (InStr(s, "â€™") > 0) Or (InStr(s, "â€") > 0) Or _
      (InStr(s, "ï»¿") > 0) Or _
      (InStr(s, "Ð") > 0 And InStr(s, "Ñ") > 0) Or (InStr(s, "Î") > 0)
End Function

' Orphan & opener fixes (NBSP‑aware) — surgical and idempotent
Function FixOrphanPairs(s)
  Dim nbsp: nbsp = ChrW(160)

  ' Map orphans for "à" and similar spaces (Ã + NBSP/space; Ãƒ + NBSP/space)
  s = Replace(s, "Ãƒ" & nbsp, "à")
  s = Replace(s, "Ã" & nbsp, "à")
  s = Replace(s, "Ãƒ ", "à")
  s = Replace(s, "Ã ", "à")
  ' rare double-byte-with-space forms
  s = Replace(s, "ÃƒÂ " , "à")
  s = Replace(s, "ÃÂ "  , "à")
  s = Replace(s, "ÃƒÂ" & nbsp, "à")
  s = Replace(s, "ÃÂ" & nbsp , "à")

  ' Contextual fix: "VoilÃ" + [space|NBSP|end] → "Voilà"
  s = RegexReplaceVoila(s)

  ' Lone opener â€ → “
  s = Replace(s, "â€ ", "“ ")
  s = Replace(s, " â€", " “")
  s = Replace(s, "â€", "“")

  ' Collapse double spaces that appear after orphan repair
  Dim k: For k = 1 To 3
    s = Replace(s, "  ", " ")
  Next
  FixOrphanPairs = s
End Function

Function RegexReplaceVoila(s)
  On Error Resume Next
  Dim nbsp: nbsp = ChrW(160)
  Dim re: Set re = CreateObject("VBScript.RegExp")
  re.Global = True
  re.IgnoreCase = False
  re.Pattern = "VoilÃ(" & nbsp & "| |$)"
  RegexReplaceVoila = re.Replace(s, "Voilà$1")
  If Err.Number <> 0 Then
    Err.Clear
    RegexReplaceVoila = s
  End If
End Function

' Stream-based reinterpretation (v9 core)
Function Reinterpret_W1252_to_UTF8_CopyTo(badText)
  On Error Resume Next
  Dim sIn, sOut, out
  Set sIn = CreateObject("ADODB.Stream")
  sIn.Type = 2
  sIn.Charset = "windows-1252"
  sIn.Open
  sIn.WriteText badText
  sIn.Position = 0
  sIn.Type = 1 ' binary

  Set sOut = CreateObject("ADODB.Stream")
  sOut.Type = 1
  sOut.Open
  sIn.CopyTo sOut

  sOut.Position = 0
  sOut.Type = 2
  sOut.Charset = "utf-8"
  out = sOut.ReadText

  sIn.Close
  sOut.Close
  If Err.Number <> 0 Or Len(out) = 0 Then out = badText
  Reinterpret_W1252_to_UTF8_CopyTo = out
  On Error GoTo 0
End Function

'================== Logging ==================
Function ShieldDefaultLogPath()
  On Error Resume Next
  Dim fso, scriptFolder
  Set fso = CreateObject("Scripting.FileSystemObject")
  scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
  If Len(scriptFolder) = 0 Then scriptFolder = "."
  ShieldDefaultLogPath = scriptFolder & "\mail_util.log"
  On Error GoTo 0
End Function

Sub LogShield(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = ShieldDefaultLogPath()
  Dim fso, f: Set fso = CreateObject("Scripting.FileSystemObject")
  Dim ts: Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
  On Error GoTo 0
End Sub
