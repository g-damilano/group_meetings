# mail_utils_utf8_plus (no shield)

This package demonstrates sending an **external HTML template** through the Outlook mailer **without the UTF‑8 Shield**.

## Files
- `mail_utils_mailer_v22.vbs` — Outlook mailer (expects UTF‑8 content)
- `sample_template_utf8.html` — external HTML template used as body
- `assets/logo.png` — tiny PNG embedded as `cid:logo.png`
- `test_send_external_html.vbs` — test runner
- `README.md` — this file

## How to use
1. Extract everything to a folder.
2. Double‑click `test_send_external_html.vbs` to open a composed email.
   - The mailer will directly send the HTML file content (no shield repair).
3. Edit the script if you want to change recipients or send automatically.
