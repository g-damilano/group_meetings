'======================================================================
' mail_utils_utf8_shield.vbs — Outlook Mail Utility with UTF‑8 Shield
' Features:
'   1) savePath => .SaveAs .msg
'   2) templateSource => HTML file/URL loading (UTF‑8 safe)
'   3) EmbedImagesFromFolder for extra inline CIDs
'   4) LogAction for simple logging
'   8) deferMinutes => DeferredDeliveryTime
' Plus:
'   • UTF‑8 Shield: FixEncoding() auto-detects and repairs UTF‑8/Latin-1 mojibake
'   • EncodingHealthCheck() runs a sentinel test and logs issues
'   • Signature (".files") HTML + embedded images with cid: rewrites
'======================================================================
Option Explicit
SetLocale 1033  ' normalise locale/codepage

Const olMailItem = 0
Const olFormatHTML = 2
Const olMSG = 3
Const PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"

'---------------------------------------------------------------------
' Public: CreateMail
'---------------------------------------------------------------------
Function CreateMail(toAddr, ccAddr, bccAddr, subjectText, htmlBody, attachPaths, _
                    action, savePath, templateSource, inlineImgFolder, deferMinutes, logPath)
  On Error Resume Next
  EncodingHealthCheck logPath

  Dim ok, olApp, olMail, sigHTML, f, fso, bodyHtml
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set olApp = GetOutlookApp()

  If Len(Trim(templateSource)) > 0 Then
    bodyHtml = LoadHtmlFromSource(templateSource)
  Else
    bodyHtml = htmlBody
  End If

  ' Shield user-provided subject/body
  subjectText = FixEncoding(subjectText)
  bodyHtml    = FixEncoding(bodyHtml)

  Set olMail = olApp.CreateItem(olMailItem)
  sigHTML = LoadSignatureWithImages(olMail)

  With olMail
    .To = FixEncoding(toAddr)
    .CC = FixEncoding(ccAddr)
    .BCC = FixEncoding(bccAddr)
    .Subject = subjectText
    .BodyFormat = olFormatHTML
    .HTMLBody = "<html><body style='font-family:Segoe UI, Arial, sans-serif;'>" & bodyHtml & sigHTML & "</body></html>"

    If Not IsEmpty(attachPaths) Then
      For Each f In attachPaths
        If Len(Trim(f)) > 0 And fso.FileExists(f) Then .Attachments.Add f
      Next
    End If

    If Len(Trim(inlineImgFolder)) > 0 And fso.FolderExists(inlineImgFolder) Then
      EmbedImagesFromFolder olMail, inlineImgFolder
    End If

    If IsNumeric(deferMinutes) And CDbl(deferMinutes) > 0 Then
      .DeferredDeliveryTime = Now + (CDbl(deferMinutes) / (24 * 60))
    End If

    Select Case LCase(action)
      Case "send"   : .Send : LogAction logPath, "Sent: " & subjectText
      Case "save"
        If Len(Trim(savePath)) > 0 Then
          .SaveAs savePath, olMSG : LogAction logPath, "Saved as: " & savePath
        Else
          .Save : LogAction logPath, "Saved to Drafts: " & subjectText
        End If
      Case Else     : .Display : LogAction logPath, "Displayed: " & subjectText
    End Select
  End With

  If Err.Number <> 0 Then
    LogAction logPath, "ERROR: " & Err.Number & " - " & Err.Description
    ok = False
  Else
    ok = True
  End If

  CreateMail = ok
  On Error GoTo 0
End Function

'---------------------------------------------------------------------
' UTF‑8 Shield: Detect and repair common mojibake patterns
'---------------------------------------------------------------------
Function FixEncoding(text)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncoding = text
    Exit Function
  End If

  ' Quick heuristic: look for UTF‑8 read as Latin-1 markers
  If (InStr(text, "Ã") > 0) Or (InStr(text, "â") > 0) Or (InStr(text, "œ") > 0) Or (InStr(text, "¢") > 0) Then
    FixEncoding = ReinterpretUtf8(text)
  Else
    FixEncoding = text
  End If
End Function

Function ReinterpretUtf8(badText)
  On Error Resume Next
  Dim s, bin, out
  ' Interpret current VBScript string as bytes in ISO-8859-1, then decode as UTF‑8
  Set s = CreateObject("ADODB.Stream")
  s.Type = 2                 ' text
  s.Charset = "iso-8859-1"
  s.Open
  s.WriteText badText
  s.Position = 0
  s.Type = 1                 ' binary
  bin = s.Read
  s.Close

  Set s = CreateObject("ADODB.Stream")
  s.Type = 1                 ' binary
  s.Open
  s.Write bin
  s.Position = 0
  s.Type = 2                 ' text
  s.Charset = "utf-8"
  out = s.ReadText
  s.Close

  If Err.Number <> 0 Or Len(out) = 0 Then
    ReinterpretUtf8 = badText ' fall back
  Else
    ReinterpretUtf8 = out
  End If
  On Error GoTo 0
End Function

Sub EncodingHealthCheck(logPath)
  Dim probe, result
  probe = ChrW(&H2713) ' ✓ checkmark
  result = FixEncoding(probe)
  If result <> probe Then
    LogAction logPath, "Encoding warning: probe failed, enabling shield."
  Else
    LogAction logPath, "Encoding OK: probe passed."
  End If
End Sub

'---------------------------------------------------------------------
' EmbedImagesFromFolder: attaches all files in folder with CID=filename
'---------------------------------------------------------------------
Sub EmbedImagesFromFolder(olMail, folderPath)
  Dim fso, file, cid, att
  Set fso = CreateObject("Scripting.FileSystemObject")
  For Each file In fso.GetFolder(folderPath).Files
    cid = fso.GetFileName(file.Name)
    Set att = olMail.Attachments.Add(file.Path)
    att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
  Next
End Sub

'---------------------------------------------------------------------
' GetOutlookApp
'---------------------------------------------------------------------
Function GetOutlookApp()
  Dim app
  On Error Resume Next
  Set app = GetObject(, "Outlook.Application")
  If Err.Number <> 0 Then
    Err.Clear
    Set app = CreateObject("Outlook.Application")
  End If
  On Error GoTo 0
  Set GetOutlookApp = app
End Function

'---------------------------------------------------------------------
' LoadSignatureWithImages (supports ".files" signature folder)
' Reads HTML via UTF‑8 stream and rewrites src to cid: while embedding
'---------------------------------------------------------------------
Function LoadSignatureWithImages(olMail)
  Dim fso, shell, sigPath, folder, file, sigHTML, sigFile, baseName, imgFolder, imgFile, att, imgName, cid
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set shell = CreateObject("WScript.Shell")
  sigPath = shell.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\Signatures\"
  sigHTML = ""

  If fso.FolderExists(sigPath) Then
    Set folder = fso.GetFolder(sigPath)
    For Each file In folder.Files
      If LCase(fso.GetExtensionName(file.Name)) = "htm" Then
        sigFile = file.Path
        baseName = fso.GetBaseName(file.Name)
        sigHTML = ReadUTF8File(sigFile)
        Exit For
      End If
    Next
  End If

  imgFolder = sigPath & baseName & ".files"
  If fso.FolderExists(imgFolder) Then
    For Each imgFile In fso.GetFolder(imgFolder).Files
      imgName = fso.GetFileName(imgFile.Name)
      cid = Replace(imgName, " ", "_")
      Set att = olMail.Attachments.Add(imgFile.Path)
      att.PropertyAccessor.SetProperty PR_ATTACH_CONTENT_ID, cid
      sigHTML = Replace(sigHTML, baseName & ".files/" & imgName, "cid:" & cid)
      sigHTML = Replace(sigHTML, baseName & ".files\" & imgName, "cid:" & cid)
    Next
  End If

  LoadSignatureWithImages = sigHTML
End Function

'---------------------------------------------------------------------
' UTF‑8 Helpers
'---------------------------------------------------------------------
Function ReadUTF8File(filePath)
  Dim s, text
  Set s = CreateObject("ADODB.Stream")
  s.Type = 2                 ' text
  s.Charset = "utf-8"
  s.Open
  s.LoadFromFile filePath
  text = s.ReadText
  s.Close
  ReadUTF8File = text
End Function

Function LoadHtmlFromSource(src)
  Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
  If Left(LCase(src), 7) = "http://" Or Left(LCase(src), 8) = "https://" Then
    LoadHtmlFromSource = HttpGetUtf8(src)
  ElseIf fso.FileExists(src) Then
    LoadHtmlFromSource = ReadUTF8File(src)
  Else
    LoadHtmlFromSource = src ' treat as literal HTML
  End If
End Function

Function HttpGetUtf8(url)
  Dim xhr, stm, txt
  Set xhr = CreateObject("MSXML2.XMLHTTP")
  xhr.Open "GET", url, False
  xhr.Send
  If xhr.Status = 200 Then
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 1 ' binary
    stm.Open
    stm.Write xhr.responseBody
    stm.Position = 0
    stm.Type = 2 ' text
    stm.Charset = "utf-8"
    txt = stm.ReadText
    stm.Close
    HttpGetUtf8 = txt
  Else
    HttpGetUtf8 = "<p>Failed to load template. HTTP " & xhr.Status & "</p>"
  End If
End Function

'---------------------------------------------------------------------
' Logging
'---------------------------------------------------------------------
Sub LogAction(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then Exit Sub
  Dim fso, f
  Set fso = CreateObject("Scripting.FileSystemObject")
  Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
End Sub
