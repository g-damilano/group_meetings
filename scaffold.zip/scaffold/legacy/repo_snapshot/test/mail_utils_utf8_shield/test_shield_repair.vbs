' test_shield_repair.vbs
Option Explicit
SetLocale 1033
Dim files, html, subj, ok
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_utf8_shield.vbs",1).ReadAll

' Deliberate mojibake to prove auto-repair: (looks wrong in ANSI)
subj = "Shield Layer Demo â€“ Repair"
html = "<h3>Shield Repair</h3><p>Accents: Ã¥, Ä‡, Ã©, Ã±, Ã¶ â€” should auto-repair to å, ć, é, ñ, ö —</p>"

files = Array()

ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, "C:\Temp\mail_util.log")
