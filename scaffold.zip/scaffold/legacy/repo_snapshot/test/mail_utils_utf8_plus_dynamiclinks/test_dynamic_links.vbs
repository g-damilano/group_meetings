' test_dynamic_links.vbs — verify URL replacement logic
Option Explicit
SetLocale 1033

Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
Dim folder: folder = fso.GetParentFolderName(WScript.ScriptFullName)
If Len(folder)=0 Then folder = "."

ExecuteGlobal fso.OpenTextFile(folder & "\mail_utils_mailer_dynamiclinks.vbs", 1).ReadAll

Dim html, subj, ok
subj = "Dynamic Link Injection Test"
html = "<h3>Testing Dynamic Links</h3>" & _
       "<p><a href='{{LINK_1}}'>Visit Website</a></p>" & _
       "<p><a href='{{LINK_2}}'>Download Report</a></p>" & _
       "<p><a href='{{LINK_3}}'>Open Dashboard</a></p>"

ok = CreateMail("", "", "", subj, html, Array(), "display", "", "", "", 0, "")
If Not ok Then WScript.Echo "CreateMail failed. Check mail_util.log."
