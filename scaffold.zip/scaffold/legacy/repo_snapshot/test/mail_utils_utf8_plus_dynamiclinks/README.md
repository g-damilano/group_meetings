# mail_utils_utf8_plus_dynamiclinks

This package extends the Outlook mailer to **dynamically inject current hyperlinks** into any HTML template.

## How It Works
1. In your HTML template, insert link placeholders like `{{LINK_1}}`, `{{LINK_2}}`.
2. Maintain a `links_map.txt` file with the actual URLs:
   ```
   LINK_1=https://example.com/home
   LINK_2=https://example.com/report.pdf
   LINK_3=https://example.com/dashboard
   ```
3. Before sending, the mailer replaces the placeholders with live URLs.

## Files
- `mail_utils_mailer_dynamiclinks.vbs` — Outlook mailer with dynamic link mapping.
- `test_dynamic_links.vbs` — test script to preview a message.
- `links_map.txt` — URL mapping file.
- `README.md` — this file.

## Usage
1. Extract to a folder.
2. Double-click `test_dynamic_links.vbs` to preview the mail.
3. Update `links_map.txt` anytime to keep URLs current without editing the HTML.
