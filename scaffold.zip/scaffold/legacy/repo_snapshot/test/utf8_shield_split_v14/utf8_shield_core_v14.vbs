'==============================================================
' utf8_shield_core_v14.vbs — UTF‑8 Repair Shield (standalone)
' - Node-scoped decoding with correct HTML reassembly
' - Multi-pass Win-1252→UTF-8 reinterpretation per node
' - Marker diagnostics, stall detection, BOM scrubbing
' - Self-contained logging (ShieldLogAction)
'==============================================================
Option Explicit
SetLocale 1033

'================== Public API ==================
Function FixEncodingHtmlTextNodes(html, logPath)
  If IsNull(html) Or IsEmpty(html) Then
    FixEncodingHtmlTextNodes = html
    Exit Function
  End If

  Dim re, mc, m, lastPos, result, inner, fixedInner, mcountBefore, mcountAfter
  Set re = CreateObject("VBScript.RegExp")
  re.Global = True
  re.MultiLine = True
  re.Pattern = ">([^<]+)<" ' match plain text nodes (no nested '<')

  Set mc = re.Execute(html)
  lastPos = 1 ' Mid is 1-based
  result = ""

  For Each m In mc
    Dim start0, start1, segLen
    start0 = m.FirstIndex    ' 0-based index of the match
    start1 = start0 + 1      ' convert to 1-based for Mid()
    segLen = start1 - lastPos
    If segLen > 0 Then result = result & Mid(html, lastPos, segLen)

    inner = m.SubMatches(0)
    mcountBefore = MarkerCount(inner)
    If mcountBefore > 0 Then
      ShieldLogAction logPath, "Node fix start. Markers: " & mcountBefore & " | Snip: " & Left(inner, 80)
      fixedInner = FixEncodingScalar(inner, logPath)
      mcountAfter = MarkerCount(fixedInner)
      ShieldLogAction logPath, "Node fix end. Markers: " & mcountAfter & " | Snip: " & Left(fixedInner, 80)
    Else
      fixedInner = inner
    End If

    result = result & ">" & fixedInner & "<"
    lastPos = start1 + m.Length
  Next

  result = result & Mid(html, lastPos)
  FixEncodingHtmlTextNodes = result
End Function

Function FixEncodingScalar(text, logPath)
  If IsNull(text) Or IsEmpty(text) Then
    FixEncodingScalar = text
    Exit Function
  End If

  Dim s, i, before, after, prev, mcount, stalled
  s = CStr(text)
  s = StripBomGlyphs(s)
  mcount = MarkerCount(s)
  If mcount = 0 Then
    FixEncodingScalar = s
    Exit Function
  End If

  ShieldLogAction logPath, "Scalar fix. Initial markers: " & mcount & " | Snip: " & Left(s, 100)
  stalled = 0
  For i = 1 To 7
    prev = s
    before = Left(s, 140)
    s = Reinterpret_W1252_to_UTF8_Refeed(s)
    s = StripBomGlyphs(s)
    after = Left(s, 140)
    ShieldLogAction logPath, "Scalar pass " & i & " BEFORE: " & before
    ShieldLogAction logPath, "Scalar pass " & i & " AFTER : " & after
    If s = prev Then
      stalled = stalled + 1
    Else
      stalled = 0
    End If
    mcount = MarkerCount(s)
    ShieldLogAction logPath, "Scalar markers after pass " & i & ": " & mcount
    If mcount = 0 Then Exit For
    If stalled >= 2 Then
      ShieldLogAction logPath, "Scalar stalled (no change in two consecutive passes)."
      Exit For
    End If
  Next
  FixEncodingScalar = s
End Function

'================== Internals ==================
Function MarkerCount(s)
  Dim c: c = 0
  c = c + CountOf(s, "Ã")
  c = c + CountOf(s, "Â")
  c = c + CountOf(s, "â€”")
  c = c + CountOf(s, "â€“")
  c = c + CountOf(s, "â€œ")
  c = c + CountOf(s, "â€�")
  c = c + CountOf(s, "â€˜")
  c = c + CountOf(s, "â€™")
  c = c + CountOf(s, "ï»¿")
  c = c + CountOf(s, "ÃŽ")
  c = c + CountOf(s, "Ð")
  c = c + CountOf(s, "Ñ")
  MarkerCount = c
End Function

Function CountOf(s, token)
  Dim pos, cnt, startAt, tlen
  tlen = Len(token)
  If tlen = 0 Then CountOf = 0 : Exit Function
  cnt = 0 : startAt = 1
  Do
    pos = InStr(startAt, s, token)
    If pos = 0 Then Exit Do
    cnt = cnt + 1
    startAt = pos + tlen
  Loop
  CountOf = cnt
End Function

Function StripBomGlyphs(s)
  s = Replace(s, "ï»¿", "")
  Dim feff: feff = ChrW(&HFEFF)
  s = Replace(s, feff, "")
  StripBomGlyphs = s
End Function

Function Reinterpret_W1252_to_UTF8_Refeed(badText)
  On Error Resume Next
  Dim sIn, sMid, sOut, out
  Set sIn = CreateObject("ADODB.Stream")
  sIn.Type = 2
  sIn.Charset = "windows-1252"
  sIn.Open
  sIn.WriteText badText
  sIn.Position = 0
  sIn.Type = 1  ' binary

  Set sMid = CreateObject("ADODB.Stream")
  sMid.Type = 1
  sMid.Open
  sIn.CopyTo sMid

  sMid.Position = 0
  sMid.Type = 2
  sMid.Charset = "utf-8"
  out = sMid.ReadText

  If MarkerCount(out) > 0 Then
    Set sOut = CreateObject("ADODB.Stream")
    sOut.Type = 2
    sOut.Charset = "windows-1252"
    sOut.Open
    sOut.WriteText out
    sOut.Position = 0 : sOut.Type = 1
    sMid.Position = 0 : sMid.Type = 1 : sMid.SetEOS
    sOut.CopyTo sMid
    sMid.Position = 0 : sMid.Type = 2 : sMid.Charset = "utf-8"
    out = sMid.ReadText
    sOut.Close
  End If

  sIn.Close
  sMid.Close
  If Err.Number <> 0 Or Len(out)=0 Then out = badText
  Reinterpret_W1252_to_UTF8_Refeed = out
  On Error GoTo 0
End Function

'================== Shield logging ==================
Function ShieldDefaultLogPath()
  On Error Resume Next
  Dim fso, scriptFolder
  Set fso = CreateObject("Scripting.FileSystemObject")
  scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
  If Len(scriptFolder) = 0 Then scriptFolder = "."
  ShieldDefaultLogPath = scriptFolder & "\mail_util.log"
  On Error GoTo 0
End Function

Sub ShieldLogAction(logPath, message)
  On Error Resume Next
  If Len(Trim(logPath)) = 0 Then logPath = ShieldDefaultLogPath()
  Dim fso, f: Set fso = CreateObject("Scripting.FileSystemObject")
  Dim ts: Set f = fso.OpenTextFile(logPath, 8, True)
  f.WriteLine Now & "  " & message
  f.Close
  On Error GoTo 0
End Sub
