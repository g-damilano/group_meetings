' test_shield_split_v14_normal.vbs
Option Explicit
SetLocale 1033

' Load the mailer (which loads shield core)
ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("mail_utils_mailer_v14.vbs",1).ReadAll

Dim files, html, subj, ok, logPath
logPath = ""
subj = "Shield Split v14 — Normal"
html = "<h3>Shield v14 Mapping Test (Normal)</h3>" & _
       "<p>1) " & ChrW(&HE5) & " " & ChrW(&HE4) & " " & ChrW(&HF6) & " " & ChrW(&HE9) & " " & ChrW(&HE8) & " " & ChrW(&HEA) & " " & ChrW(&HEB) & "</p>" & _
       "<p>2) " & ChrW(&H107) & " " & ChrW(&H10D) & " " & ChrW(&H161) & " " & ChrW(&H17E) & " " & ChrW(&H159) & " " & ChrW(&H16F) & "</p>" & _
       "<p>3) " & ChrW(&HF1) & " " & ChrW(&HE1) & " " & ChrW(&HED) & " " & ChrW(&HF3) & " " & ChrW(&HFA) & "</p>" & _
       "<p>4) " & ChrW(&HDF) & " " & ChrW(&HC4) & " " & ChrW(&HD6) & " " & ChrW(&HDC) & "</p>" & _
       "<p>5) " & ChrW(&H153) & " " & ChrW(&HE7) & " " & ChrW(&HE9) & " " & ChrW(&HE0) & "</p>" & _
       "<p>6) " & ChrW(&H2014) & " " & ChrW(&H2013) & " " & ChrW(&H201C) & " " & ChrW(&H201D) & " " & ChrW(&H2018) & " " & ChrW(&H2019) & "</p>" & _
       "<p>7) " & ChrW(&H20AC) & " " & ChrW(&HA3) & " " & ChrW(&HA5) & "</p>" & _
       "<p>8) Mixed: Voil" & ChrW(&HE0) & " se" & ChrW(&HF1) & "or Gro" & ChrW(&HDF) & "z" & ChrW(&HFC) & "gig</p>" & _
       "<p>9) Greek: " & ChrW(&H3B1) & " " & ChrW(&H3B2) & " " & ChrW(&H3B3) & " " & ChrW(&H394) & "</p>" & _
       "<p>10) Cyrillic: " & ChrW(&H41F) & ChrW(&H440) & ChrW(&H438) & ChrW(&H432) & ChrW(&H435) & ChrW(&H442) & "</p>"

files = Array()
ok = CreateMail("gd2613@ic.ac.uk", "", "", subj, html, files, "display", "", "", "", 0, logPath)
