
UTF‑8 Shield Split v14 — Package
=================================

Files
-----
1) utf8_shield_core_v14.vbs
   • Standalone encoding repair module (node-scoped + scalar)
   • Public functions:
     - FixEncodingHtmlTextNodes(html, logPath)
     - FixEncodingScalar(text, logPath)

2) mail_utils_mailer_v14.vbs
   • Outlook mail utility that loads the shield core from the same folder.
   • Public function:
     - CreateMail(to, cc, bcc, subject, htmlBody, attachPaths, action, savePath, templateSource, inlineImgFolder, deferMinutes, logPath)

3) test_shield_split_v14_normal.vbs
4) test_shield_split_v14_repair.vbs
5) test_shield_split_v14_matrix.vbs

How to use
----------
• Place all files in the SAME folder.
• Double-click any test script. The mailer will load Outlook and the shield core automatically.
• Logs are written to: mail_util.log (same folder).

Notes
-----
• The shield only repairs text nodes that actually contain mojibake markers, preserving clean content (Greek/Cyrillic).
• If you want to reuse the shield in your own scripts:
    ExecuteGlobal CreateObject("Scripting.FileSystemObject").OpenTextFile("utf8_shield_core_v14.vbs",1).ReadAll
    repaired = FixEncodingHtmlTextNodes(yourHtml, "")
