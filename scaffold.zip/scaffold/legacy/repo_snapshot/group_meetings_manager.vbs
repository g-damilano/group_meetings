Option Explicit

'==============================================================
' Global Objects and State
'==============================================================
Dim objShell, fso
Dim SCRIPT_FOLDER, LOG_FILE_PATH
Dim OL, olNS

'==============================================================
' Configuration Constants
'==============================================================
Const DEBUG_MODE = False   ' Set to True to dry-run without sending emails
Const EXTENDED_LOGGING = True
Const LOG_VARIANT = "[Main] "
Const DISPLAY_DEBUG_POPUPS = False
Const MANAGER   = "gd2613@ic.ac.uk"
Const BUILDING_ADMIN_EMAIL   = "i.gomezvilchis@imperial.ac.uk"
Const DEFAULT_PREVIOUS_LAB_MANAGER = "Agi"

Const EMAIL_TO = "brandt-talbot-group@imperial.ac.uk"
Const EXCEL_PATH = "C:\\Users\\giaco\\OneDrive - Imperial College London\\Work\\group_meetings\\meeting_rota.xlsx"
Const SHEET_ROTA = "Rota"
Const SHEET_EMAILS = "Emails"

Const MANAGED_EMAIL_PROPERTY_NAME = "ABTManagedEmailKey"
Const MANAGED_EMAIL_KEY_PREFIX = "ABT-GROUP-MEETING"
Const MANAGED_OUTBOX_GRACE_MINUTES = 15
Const ENABLE_STALE_OUTBOX_REPLACEMENT = True
Const ENABLE_MANAGED_EMAIL_KEY_FALLBACK_BY_SUBJECT = True
Const ENABLE_OUTLOOK_TRANSPORT_DIAGNOSTICS = True
Const ENABLE_OUTBOX_DIAGNOSTICS = True

'==============================================================
' Logging Helpers
'==============================================================
Sub LogEvent(message)
    On Error Resume Next
    Dim ts
    Set ts = fso.OpenTextFile(LOG_FILE_PATH, 8, True)
    ts.WriteLine Now & " - " & LOG_VARIANT & message
    ts.Close
    Set ts = Nothing
    On Error GoTo 0
End Sub

Function ShouldResetLogForNewWeek(filePath)
    On Error Resume Next
    Dim fileObj, weekDelta

    If Not fso.FileExists(filePath) Then
        ShouldResetLogForNewWeek = False
        Exit Function
    End If

    Set fileObj = fso.GetFile(filePath)
    If Err.Number <> 0 Then
        Err.Clear
        ShouldResetLogForNewWeek = False
        Exit Function
    End If

    weekDelta = DateDiff("ww", fileObj.DateLastModified, Now, vbMonday, vbFirstFourDays)
    If Err.Number <> 0 Then
        Err.Clear
        ShouldResetLogForNewWeek = False
        Exit Function
    End If

    ShouldResetLogForNewWeek = (weekDelta > 0)
End Function

Function ResetLogIfNewWeek(filePath)
    On Error Resume Next
    Dim ts

    ResetLogIfNewWeek = False

    If Not fso.FileExists(filePath) Then
        Exit Function
    End If

    If Not ShouldResetLogForNewWeek(filePath) Then
        Exit Function
    End If

    Set ts = fso.OpenTextFile(filePath, 2, True)
    If Err.Number <> 0 Then
        Err.Clear
        Exit Function
    End If

    ts.Write ""
    ts.Close
    Set ts = Nothing

    ResetLogIfNewWeek = True
End Function

Sub LogError(context)
    Dim errMsg
    errMsg = context & " | Err: " & Err.Number & " - " & Err.Description
    LogEvent errMsg
    Err.Clear
End Sub

Sub LogVerbose(message)
    If EXTENDED_LOGGING Then
        LogEvent "[VERBOSE] " & message
    End If
End Sub

'==============================================================
' Formatting Helpers
'==============================================================
Function FormatMeetingDateForFilename(meetingDate)
    Dim yearPart, monthPart, dayPart
    yearPart = Right("0" & (Year(meetingDate) Mod 100), 2)
    monthPart = Right("0" & Month(meetingDate), 2)
    dayPart = Right("0" & Day(meetingDate), 2)
    FormatMeetingDateForFilename = yearPart & monthPart & dayPart
End Function

Function FindHeaderColumn(objSheet, headerText, defaultColumn)
    Dim lastColumn, col, currentHeader
    lastColumn = objSheet.Cells(1, objSheet.Columns.Count).End(-4159).Column
    For col = 1 To lastColumn
        currentHeader = LCase(Trim(CStr(objSheet.Cells(1, col).Value)))
        If currentHeader = LCase(Trim(CStr(headerText))) Then
            FindHeaderColumn = col
            Exit Function
        End If
    Next
    FindHeaderColumn = defaultColumn
End Function

Function IsFlagSet(value)
    Dim textValue
    textValue = Trim(CStr(value))
    If IsNumeric(textValue) Then
        IsFlagSet = (CDbl(textValue) <> 0)
    Else
        IsFlagSet = (LCase(textValue) = "true" Or LCase(textValue) = "yes")
    End If
End Function

Function ExtractNameInitials(fullName)
    Dim cleaned, parts, firstName, lastName, tokens, i, initials
    cleaned = Trim(fullName)

    If cleaned = "" Then
        ExtractNameInitials = ""
        Exit Function
    End If

    firstName = ""
    lastName = ""

    If InStr(cleaned, ",") > 0 Then
        parts = Split(cleaned, ",")
        lastName = Trim(parts(0))
        If UBound(parts) >= 1 Then
            firstName = Trim(parts(1))
        End If
    Else
        tokens = Split(cleaned, " ")
        If UBound(tokens) >= 0 Then
            firstName = Trim(tokens(0))
            lastName = Trim(tokens(UBound(tokens)))
        End If
    End If

    If LCase(firstName) = LCase(lastName) Then
        lastName = ""
    End If

    initials = ""
    If firstName <> "" Then
        initials = initials & UCase(Left(firstName, 1))
    End If
    If lastName <> "" Then
        initials = initials & UCase(Left(lastName, 1))
    End If

    ExtractNameInitials = initials
End Function

'==============================================================
' Environment Bootstrap
'==============================================================
Sub InitializeFileSystem()
    Call LogVerbose("InitializeFileSystem invoked")
    Set objShell = CreateObject("WScript.Shell")
    Set fso = CreateObject("Scripting.FileSystemObject")
    SCRIPT_FOLDER = fso.GetParentFolderName(WScript.ScriptFullName)
    LOG_FILE_PATH = fso.BuildPath(SCRIPT_FOLDER, "group_meetings_manager.log")
End Sub

Sub InitializeLogging()
    Dim logExisted, resetPerformed

    logExisted = fso.FileExists(LOG_FILE_PATH)
    resetPerformed = ResetLogIfNewWeek(LOG_FILE_PATH)

    If resetPerformed Then
        LogEvent "Weekly log reset detected. Starting new log file: " & LOG_FILE_PATH
    ElseIf logExisted Then
        LogEvent "Continuing existing weekly log: " & LOG_FILE_PATH
    Else
        LogEvent "Creating new weekly log file: " & LOG_FILE_PATH
    End If

    Call LogVerbose("InitializeLogging invoked")
    LogEvent "=== Script execution started ==="
    LogEvent "Logging to file: " & LOG_FILE_PATH
End Sub

Function SyncMeetingWorkbook()
    Call LogVerbose("SyncMeetingWorkbook invoked")
    Dim cmd, exitCode
    cmd = "C:\rclone\rclone.exe copy ""ABTsharepoint:/Group Meetings/meeting_rota.xlsx"" ""C:\Users\giaco\OneDrive - Imperial College London\Work\group_meetings"""
    LogEvent "Executing rclone command: " & cmd
    exitCode = objShell.Run(cmd, 0, True)
    LogEvent "rclone command completed with exit code: " & exitCode
    If exitCode <> 0 Then
        LogEvent "WARNING: rclone returned non-zero exit code: " & exitCode
    End If
    SyncMeetingWorkbook = (exitCode = 0)
End Function

Function InitializeOutlook()
    Call LogVerbose("InitializeOutlook invoked")
    InitializeOutlook = False

    On Error Resume Next
    Set OL = CreateObject("Outlook.Application")
    If Err.Number <> 0 Then
        LogError "Failed to create Outlook.Application"
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0
    LogEvent "Outlook application created successfully."

    On Error Resume Next
    Set olNS = OL.GetNamespace("MAPI")
    If Err.Number <> 0 Then
        LogError "Failed to obtain Outlook namespace"
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0
    LogEvent "Obtained Outlook namespace for MAPI."

    InitializeOutlook = True
End Function

Sub CleanupSyncedWorkbook()
    Call LogVerbose("CleanupSyncedWorkbook invoked")
    If fso.FileExists(EXCEL_PATH) Then
        LogEvent "Deleting local Excel file after sync: " & EXCEL_PATH
        fso.DeleteFile EXCEL_PATH, True
    Else
        LogEvent "Local Excel file not found during cleanup: " & EXCEL_PATH
    End If
End Sub

'==============================================================
' Outlook Lookups
'==============================================================
Function GetExactEmail(searchName)
    Call LogVerbose("GetExactEmail invoked with searchName='" & searchName & "'")
    If Trim(searchName) = "" Then
        GetExactEmail = ""
        Exit Function
    End If

    Dim olApp, ns, recip, exchUser
    Set olApp = CreateObject("Outlook.Application")
    Set ns = olApp.GetNamespace("MAPI")

    Set recip = ns.CreateRecipient(searchName)
    recip.Resolve

    If recip.Resolved Then
        On Error Resume Next
        Set exchUser = recip.AddressEntry.GetExchangeUser()
        On Error GoTo 0

        If Not exchUser Is Nothing Then
            GetExactEmail = exchUser.PrimarySmtpAddress
        Else
            GetExactEmail = recip.AddressEntry.Address
        End If
    Else
        GetExactEmail = ""
    End If
End Function

Function EmailExists(header, folderConstant, checkOnly)
    Call LogVerbose("EmailExists invoked for subject='" & header & "'")
    Dim targetFolderId, folderLabel, sortField
    Dim targetFolder, items, mail
    Dim found, checkMode

    targetFolderId = 6 ' Inbox by default
    If Not IsEmpty(folderConstant) Then
        On Error Resume Next
        targetFolderId = CLng(folderConstant)
        On Error GoTo 0
        If targetFolderId = 0 Then targetFolderId = 6
    End If

    checkMode = False
    If Not IsEmpty(checkOnly) Then
        On Error Resume Next
        checkMode = CBool(checkOnly)
        If Err.Number <> 0 Then
            checkMode = False
        End If
        On Error GoTo 0
    End If

    Select Case targetFolderId
        Case 4
            folderLabel = "Outbox"
            sortField = "CreationTime"
        Case 5
            folderLabel = "Sent Items"
            sortField = "SentOn"
        Case 6
            folderLabel = "Inbox"
            sortField = "ReceivedTime"
        Case Else
            folderLabel = "folder id " & targetFolderId
            sortField = "ReceivedTime"
    End Select

    LogEvent "Checking Outlook " & folderLabel & " for email with subject: " & header

    On Error Resume Next
    Set targetFolder = olNS.GetDefaultFolder(targetFolderId)
    If Err.Number <> 0 Then
        LogError "Unable to access Outlook folder id " & targetFolderId & " for subject '" & header & "'"
        On Error GoTo 0
        EmailExists = False
        Exit Function
    End If
    On Error GoTo 0

    Set items = targetFolder.Items
    On Error Resume Next
    items.Sort sortField, True
    On Error GoTo 0

    found = False
    For Each mail In items
        If TypeName(mail) = "MailItem" Then
            If mail.Subject = header Then
                found = True
                If checkMode Then
                    LogEvent "Confirmed email with subject '" & header & "' in " & folderLabel & "."
                Else
                    LogEvent "Email with subject '" & header & "' already exists in " & folderLabel & ". Skipping related actions."
                End If
                Exit For
            End If
        End If
    Next

    If Not found Then
        If checkMode Then
            LogEvent "Email with subject '" & header & "' not yet located in " & folderLabel & " during verification."
        Else
            LogEvent "Email with subject '" & header & "' not found in " & folderLabel & " prior to action."
        End If
    End If

    LogEvent "EmailExists('" & header & "', folder=" & folderLabel & ", checkOnly=" & checkMode & ") result: " & found
    EmailExists = found
End Function

Function EmailExistsInSentOrOutbox(header, checkOnly)
    Call LogVerbose("EmailExistsInSentOrOutbox invoked for subject='" & header & "'")
    Dim found

    found = EmailExists(header, 5, checkOnly)
    If found Then
        EmailExistsInSentOrOutbox = True
        Exit Function
    End If

    found = EmailExists(header, 4, checkOnly)
    EmailExistsInSentOrOutbox = found
End Function

'==============================================================
' Managed Email Identity and Lookup Helpers
'==============================================================
Function BoolText(value)
    If CBool(value) Then
        BoolText = "True"
    Else
        BoolText = "False"
    End If
End Function

Function FormatManagedEmailDate(meetingDate)
    FormatManagedEmailDate = Year(meetingDate) & "-" & _
                             Right("0" & Month(meetingDate), 2) & "-" & _
                             Right("0" & Day(meetingDate), 2)
End Function

Function NormalizeManagedEmailType(emailType)
    Dim cleaned
    cleaned = UCase(Trim(CStr(emailType)))
    cleaned = Replace(cleaned, " ", "-")
    cleaned = Replace(cleaned, "_", "-")
    Do While InStr(cleaned, "--") > 0
        cleaned = Replace(cleaned, "--", "-")
    Loop

    Select Case cleaned
        Case "LITERATURE", "LITERATURE-PRESENTATION", "LITERATURE-REMINDER"
            NormalizeManagedEmailType = "LITERATURE-REMINDER"
        Case "RESULTS", "RESULTS-PRESENTATION", "RESULTS-REMINDER"
            NormalizeManagedEmailType = "RESULTS-REMINDER"
        Case "MEETING-LEAD", "MEETING-LEAD-REMINDER"
            NormalizeManagedEmailType = "MEETING-LEAD-REMINDER"
        Case "LAB-MANAGER", "LAB-MANAGER-REMINDER"
            NormalizeManagedEmailType = "LAB-MANAGER-REMINDER"
        Case "SAME-DAY", "SAME-DAY-REMINDER"
            NormalizeManagedEmailType = "SAME-DAY-REMINDER"
        Case "REGULAR", "GROUP", "GROUP-MEETING"
            NormalizeManagedEmailType = "REGULAR"
        Case Else
            If cleaned = "" Then
                NormalizeManagedEmailType = "UNKNOWN"
            Else
                NormalizeManagedEmailType = cleaned
            End If
    End Select
End Function

Function BuildManagedEmailKey(meetingDate, emailType)
    BuildManagedEmailKey = MANAGED_EMAIL_KEY_PREFIX & "|" & _
                           FormatManagedEmailDate(meetingDate) & "|" & _
                           NormalizeManagedEmailType(emailType)
    LogEvent "Managed email key built: " & BuildManagedEmailKey
End Function

Function ManagedEmailMarker(managedKey)
    ManagedEmailMarker = "<!-- " & MANAGED_EMAIL_PROPERTY_NAME & ": " & managedKey & " -->"
End Function

Sub EnsureManagedEmailHtmlMarker(ByRef mail, managedKey)
    On Error Resume Next
    Dim html, marker, bodyClosePos
    marker = ManagedEmailMarker(managedKey)
    html = mail.HTMLBody
    If Err.Number <> 0 Then
        LogError "Unable to read HTMLBody while stamping managed email key '" & managedKey & "'"
        On Error GoTo 0
        Exit Sub
    End If

    If InStr(1, html, MANAGED_EMAIL_PROPERTY_NAME & ":", vbTextCompare) > 0 Then
        On Error GoTo 0
        Exit Sub
    End If

    bodyClosePos = InStr(1, html, "</body>", vbTextCompare)
    If bodyClosePos > 0 Then
        html = Left(html, bodyClosePos - 1) & vbCrLf & marker & vbCrLf & Mid(html, bodyClosePos)
    Else
        html = html & vbCrLf & marker
    End If
    mail.HTMLBody = html
    If Err.Number <> 0 Then
        LogError "Unable to write hidden HTML managed email marker for key '" & managedKey & "'"
    End If
    On Error GoTo 0
End Sub

Sub StampManagedEmail(ByRef mail, managedKey)
    Call LogVerbose("StampManagedEmail invoked for key='" & managedKey & "'")
    On Error Resume Next
    Dim prop
    Set prop = mail.UserProperties.Find(MANAGED_EMAIL_PROPERTY_NAME)
    If Err.Number <> 0 Then
        LogError "Unable to read Outlook UserProperties while stamping managed email key '" & managedKey & "'"
        Set prop = Nothing
    End If
    Err.Clear
    If prop Is Nothing Then
        Set prop = mail.UserProperties.Add(MANAGED_EMAIL_PROPERTY_NAME, 1, True)
    End If
    If Err.Number <> 0 Then
        LogError "Unable to create Outlook UserProperty for managed email key '" & managedKey & "'"
    Else
        prop.Value = managedKey
        If Err.Number <> 0 Then
            LogError "Unable to set Outlook UserProperty for managed email key '" & managedKey & "'"
        End If
    End If
    On Error GoTo 0

    EnsureManagedEmailHtmlMarker mail, managedKey
    LogEvent "Stamped managed email with key: " & managedKey
End Sub

Function ExtractManagedEmailKeyFromText(textValue)
    Dim markerPos, startPos, remainder, endPos, crPos, ltPos
    ExtractManagedEmailKeyFromText = ""
    markerPos = InStr(1, CStr(textValue), MANAGED_EMAIL_PROPERTY_NAME & ":", vbTextCompare)
    If markerPos = 0 Then Exit Function

    startPos = markerPos + Len(MANAGED_EMAIL_PROPERTY_NAME & ":")
    remainder = Trim(Mid(CStr(textValue), startPos))
    endPos = InStr(1, remainder, "-->", vbTextCompare)
    crPos = InStr(1, remainder, vbCrLf, vbTextCompare)
    ltPos = InStr(1, remainder, "<", vbTextCompare)

    If endPos = 0 Or (crPos > 0 And crPos < endPos) Then endPos = crPos
    If endPos = 0 Or (ltPos > 0 And ltPos < endPos) Then endPos = ltPos

    If endPos > 0 Then
        ExtractManagedEmailKeyFromText = Trim(Left(remainder, endPos - 1))
    Else
        ExtractManagedEmailKeyFromText = Trim(remainder)
    End If
End Function

Function GetManagedEmailKey(ByRef mail)
    On Error Resume Next
    Dim prop, valueText, htmlText, bodyText
    GetManagedEmailKey = ""

    Set prop = mail.UserProperties.Find(MANAGED_EMAIL_PROPERTY_NAME)
    If Err.Number = 0 Then
        If Not prop Is Nothing Then
            valueText = Trim(CStr(prop.Value))
            If valueText <> "" Then
                GetManagedEmailKey = valueText
                On Error GoTo 0
                Exit Function
            End If
        End If
    Else
        Err.Clear
    End If

    htmlText = mail.HTMLBody
    If Err.Number = 0 Then
        valueText = ExtractManagedEmailKeyFromText(htmlText)
        If valueText <> "" Then
            GetManagedEmailKey = valueText
            On Error GoTo 0
            Exit Function
        End If
    Else
        Err.Clear
    End If

    bodyText = mail.Body
    If Err.Number = 0 Then
        valueText = ExtractManagedEmailKeyFromText(bodyText)
        If valueText <> "" Then GetManagedEmailKey = valueText
    Else
        Err.Clear
    End If
    On Error GoTo 0
End Function

Function SafeMailSubject(ByRef mail)
    On Error Resume Next
    SafeMailSubject = CStr(mail.Subject)
    If Err.Number <> 0 Then
        Err.Clear
        SafeMailSubject = ""
    End If
    On Error GoTo 0
End Function

Function FolderLabelFromId(folderId)
    Select Case CLng(folderId)
        Case 4
            FolderLabelFromId = "Outbox"
        Case 5
            FolderLabelFromId = "Sent Items"
        Case 6
            FolderLabelFromId = "Inbox"
        Case Else
            FolderLabelFromId = "folder id " & folderId
    End Select
End Function

Function FolderSortFieldFromId(folderId)
    Select Case CLng(folderId)
        Case 4
            FolderSortFieldFromId = "CreationTime"
        Case 5
            FolderSortFieldFromId = "SentOn"
        Case Else
            FolderSortFieldFromId = "ReceivedTime"
    End Select
End Function

Function FindManagedEmailInFolder(folderId, managedKey, subjectText)
    Call LogVerbose("FindManagedEmailInFolder invoked for key='" & managedKey & "'")
    Dim matches, targetFolder, items, mail, itemKey, matched, folderLabel, sortField
    Set matches = CreateObject("Scripting.Dictionary")
    folderLabel = FolderLabelFromId(folderId)
    sortField = FolderSortFieldFromId(folderId)

    LogEvent "Searching Outlook " & folderLabel & " for managed email key: " & managedKey

    On Error Resume Next
    Set targetFolder = olNS.GetDefaultFolder(CLng(folderId))
    If Err.Number <> 0 Then
        LogError "Unable to access Outlook " & folderLabel & " while searching for managed email key '" & managedKey & "'"
        On Error GoTo 0
        Set FindManagedEmailInFolder = matches
        Exit Function
    End If
    Set items = targetFolder.Items
    If Err.Number <> 0 Then
        LogError "Unable to access Items collection in Outlook " & folderLabel & " for managed email key '" & managedKey & "'"
        On Error GoTo 0
        Set FindManagedEmailInFolder = matches
        Exit Function
    End If
    items.Sort sortField, True
    Err.Clear
    On Error GoTo 0

    For Each mail In items
        If TypeName(mail) = "MailItem" Then
            matched = False
            itemKey = GetManagedEmailKey(mail)
            If itemKey <> "" And itemKey = managedKey Then
                matched = True
            ElseIf ENABLE_MANAGED_EMAIL_KEY_FALLBACK_BY_SUBJECT Then
                If subjectText <> "" And SafeMailSubject(mail) = subjectText Then
                    matched = True
                    LogEvent "Legacy subject-only fallback matched in " & folderLabel & _
                             " for managed key '" & managedKey & "' and subject '" & subjectText & "'."
                End If
            End If

            If matched Then
                matches.Add CStr(matches.Count), mail
            End If
        End If
    Next

    LogEvent folderLabel & " search result for managed key '" & managedKey & "': " & matches.Count & " match(es)."
    Set FindManagedEmailInFolder = matches
End Function

Function FindManagedEmailInSentItems(managedKey, subjectText)
    Set FindManagedEmailInSentItems = FindManagedEmailInFolder(5, managedKey, subjectText)
End Function

Function FindManagedEmailInOutbox(managedKey, subjectText)
    Set FindManagedEmailInOutbox = FindManagedEmailInFolder(4, managedKey, subjectText)
End Function

Function FindManagedEmailState(managedKey, subjectText)
    Dim state, sentMatches, outboxMatches
    Set state = CreateObject("Scripting.Dictionary")
    Set sentMatches = FindManagedEmailInSentItems(managedKey, subjectText)
    Set outboxMatches = FindManagedEmailInOutbox(managedKey, subjectText)
    state.Add "SentItems", sentMatches
    state.Add "Outbox", outboxMatches
    Set FindManagedEmailState = state
End Function

'==============================================================
' Outlook Transport and Outbox Diagnostics
'==============================================================
Function ExchangeConnectionModeName(modeValue)
    If Not IsNumeric(modeValue) Then
        ExchangeConnectionModeName = "Unavailable"
        Exit Function
    End If

    Select Case CLng(modeValue)
        Case 0
            ExchangeConnectionModeName = "olNoExchange"
        Case 100
            ExchangeConnectionModeName = "olOffline"
        Case 200
            ExchangeConnectionModeName = "olCachedOffline"
        Case 300
            ExchangeConnectionModeName = "olDisconnected"
        Case 400
            ExchangeConnectionModeName = "olCachedDisconnected"
        Case 500
            ExchangeConnectionModeName = "olCachedConnectedHeaders"
        Case 600
            ExchangeConnectionModeName = "olCachedConnectedDrizzle"
        Case 700
            ExchangeConnectionModeName = "olCachedConnectedFull"
        Case 800
            ExchangeConnectionModeName = "olOnline"
        Case Else
            ExchangeConnectionModeName = "Unknown"
    End Select
End Function

Function IsBlockedExchangeMode(modeValue)
    If Not IsNumeric(modeValue) Then
        IsBlockedExchangeMode = False
        Exit Function
    End If

    Select Case CLng(modeValue)
        Case 100, 200, 300, 400
            IsBlockedExchangeMode = True
        Case Else
            IsBlockedExchangeMode = False
    End Select
End Function

Function GetOutlookTransportState(ByRef outlookApp)
    Dim state, ns, offlineValue, modeValue, offlineAvailable, modeAvailable, blocked
    Set state = CreateObject("Scripting.Dictionary")

    offlineValue = False
    modeValue = ""
    offlineAvailable = False
    modeAvailable = False

    On Error Resume Next
    Set ns = outlookApp.GetNamespace("MAPI")
    offlineValue = CBool(ns.Offline)
    If Err.Number = 0 Then
        offlineAvailable = True
    Else
        Err.Clear
    End If

    modeValue = ns.ExchangeConnectionMode
    If Err.Number = 0 Then
        modeAvailable = True
    Else
        modeValue = ""
        Err.Clear
    End If
    On Error GoTo 0

    blocked = False
    If offlineAvailable Then
        If offlineValue Then blocked = True
    End If
    If modeAvailable Then
        If IsBlockedExchangeMode(modeValue) Then blocked = True
    End If

    state.Add "OfflineAvailable", offlineAvailable
    state.Add "Offline", offlineValue
    state.Add "ModeAvailable", modeAvailable
    state.Add "Mode", modeValue
    state.Add "ModeName", ExchangeConnectionModeName(modeValue)
    state.Add "Blocked", blocked

    Set GetOutlookTransportState = state
End Function

Function LogOutlookTransportState(contextText, ByRef outlookApp)
    Dim state, offlineText, modeText
    Set state = GetOutlookTransportState(outlookApp)

    If ENABLE_OUTLOOK_TRANSPORT_DIAGNOSTICS Then
        If state("OfflineAvailable") Then
            offlineText = BoolText(state("Offline"))
        Else
            offlineText = "Unavailable"
        End If

        If state("ModeAvailable") Then
            modeText = CStr(state("Mode")) & " (" & state("ModeName") & ")"
        Else
            modeText = "Unavailable"
        End If

        LogEvent "Outlook transport state [" & contextText & "]: Offline=" & offlineText & _
                 " | ExchangeConnectionMode=" & modeText & _
                 " | offline/disconnected/auth-blocked suspected=" & BoolText(state("Blocked"))
    End If

    Set LogOutlookTransportState = state
End Function

Sub LogOutlookTransportStateSnapshot(contextText, ByRef outlookApp)
    Dim ignoredState
    Set ignoredState = LogOutlookTransportState(contextText, outlookApp)
End Sub

Function TryGetMapiProperty(ByRef mail, schemaName, ByRef propertyValue)
    On Error Resume Next
    propertyValue = mail.PropertyAccessor.GetProperty(schemaName)
    If Err.Number <> 0 Then
        LogEvent "WARNING: MAPI property lookup failed for " & schemaName & _
                 " | Err: " & Err.Number & " - " & Err.Description
        Err.Clear
        TryGetMapiProperty = False
    Else
        TryGetMapiProperty = True
    End If
    On Error GoTo 0
End Function

Function TryGetEffectiveDeferredDeliveryTime(ByRef mail, ByRef deferredValue)
    On Error Resume Next
    deferredValue = mail.DeferredDeliveryTime
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        TryGetEffectiveDeferredDeliveryTime = False
        Exit Function
    End If
    On Error GoTo 0

    If Not IsDate(deferredValue) Then
        TryGetEffectiveDeferredDeliveryTime = False
        Exit Function
    End If

    deferredValue = CDate(deferredValue)
    If Year(deferredValue) < 1900 Or Year(deferredValue) >= 4500 Then
        TryGetEffectiveDeferredDeliveryTime = False
    Else
        TryGetEffectiveDeferredDeliveryTime = True
    End If
End Function

Function GetManagedMailReferenceTime(ByRef mail)
    On Error Resume Next
    GetManagedMailReferenceTime = mail.CreationTime
    If Err.Number = 0 And IsDate(GetManagedMailReferenceTime) Then
        On Error GoTo 0
        Exit Function
    End If
    Err.Clear

    GetManagedMailReferenceTime = mail.LastModificationTime
    If Err.Number <> 0 Or Not IsDate(GetManagedMailReferenceTime) Then
        Err.Clear
        GetManagedMailReferenceTime = Empty
    End If
    On Error GoTo 0
End Function

Function GetManagedMailAgeMinutes(ByRef mail, currentTime)
    Dim referenceTime
    referenceTime = GetManagedMailReferenceTime(mail)
    If IsDate(referenceTime) Then
        GetManagedMailAgeMinutes = DateDiff("n", CDate(referenceTime), CDate(currentTime))
    Else
        GetManagedMailAgeMinutes = -1
    End If
End Function

Function SafeOutlookText(ByRef mail, propertyName)
    On Error Resume Next
    Select Case propertyName
        Case "Subject"
            SafeOutlookText = CStr(mail.Subject)
        Case "To"
            SafeOutlookText = CStr(mail.To)
        Case "EntryID"
            SafeOutlookText = CStr(mail.EntryID)
        Case "CreationTime"
            SafeOutlookText = CStr(mail.CreationTime)
        Case "LastModificationTime"
            SafeOutlookText = CStr(mail.LastModificationTime)
        Case Else
            SafeOutlookText = ""
    End Select

    If Err.Number <> 0 Then
        Err.Clear
        SafeOutlookText = "[unavailable]"
    End If
    On Error GoTo 0
End Function

Function SafeAttachmentCount(ByRef mail)
    On Error Resume Next
    SafeAttachmentCount = CStr(mail.Attachments.Count)
    If Err.Number <> 0 Then
        Err.Clear
        SafeAttachmentCount = "[unavailable]"
    End If
    On Error GoTo 0
End Function

Sub LogOutboxDiagnosticSnapshot(ByRef mail, managedKey)
    If Not ENABLE_OUTBOX_DIAGNOSTICS Then Exit Sub

    Dim deferredValue, deferredText, ageMinutes, flagsValue, submitTimeValue
    Dim flagsText, submitText, submitFlagText, unsentFlagText

    ageMinutes = GetManagedMailAgeMinutes(mail, Now)
    deferredText = "Absent"
    If TryGetEffectiveDeferredDeliveryTime(mail, deferredValue) Then
        If CDate(deferredValue) > Now Then
            deferredText = CStr(deferredValue) & " (future)"
        Else
            deferredText = CStr(deferredValue) & " (passed)"
        End If
    End If

    flagsText = "[unavailable]"
    submitFlagText = "[unavailable]"
    unsentFlagText = "[unavailable]"
    If TryGetMapiProperty(mail, "http://schemas.microsoft.com/mapi/proptag/0x0E070003", flagsValue) Then
        flagsText = CStr(flagsValue)
        If IsNumeric(flagsValue) Then
            submitFlagText = BoolText((CLng(flagsValue) And 4) <> 0)
            unsentFlagText = BoolText((CLng(flagsValue) And 8) <> 0)
        End If
    End If

    submitText = "[unavailable]"
    If TryGetMapiProperty(mail, "http://schemas.microsoft.com/mapi/proptag/0x00390040", submitTimeValue) Then
        submitText = CStr(submitTimeValue)
    End If

    LogEvent "Outbox diagnostic snapshot | ManagedKey=" & managedKey & _
             " | Subject=" & SafeOutlookText(mail, "Subject") & _
             " | To=" & SafeOutlookText(mail, "To") & _
             " | EntryID=" & SafeOutlookText(mail, "EntryID") & _
             " | CreationTime=" & SafeOutlookText(mail, "CreationTime") & _
             " | LastModificationTime=" & SafeOutlookText(mail, "LastModificationTime") & _
             " | AgeMinutes=" & CStr(ageMinutes) & _
             " | DeferredDeliveryTime=" & deferredText & _
             " | AttachmentCount=" & SafeAttachmentCount(mail) & _
             " | PR_MESSAGE_FLAGS=" & flagsText & _
             " | MSGFLAG_SUBMIT=" & submitFlagText & _
             " | MSGFLAG_UNSENT=" & unsentFlagText & _
             " | PR_CLIENT_SUBMIT_TIME=" & submitText
End Sub

Function IsItemInOutbox(ByRef mail)
    On Error Resume Next
    Dim outbox
    Set outbox = olNS.GetDefaultFolder(4)
    IsItemInOutbox = (CStr(mail.Parent.EntryID) = CStr(outbox.EntryID))
    If Err.Number <> 0 Then
        Err.Clear
        IsItemInOutbox = False
    End If
    On Error GoTo 0
End Function

Function NewQueueDecision(decisionText, reasonText)
    Dim decision
    Set decision = CreateObject("Scripting.Dictionary")
    decision.Add "Decision", decisionText
    decision.Add "Reason", reasonText
    Set NewQueueDecision = decision
End Function

Function GetQueuedManagedEmailDecision(ByRef outlookApp, ByRef queuedMail, managedKey, currentTime, graceMinutes, expectedDeferredDeliveryTime)
    Dim transportState, deferredValue, ageMinutes, sentMatches
    Set transportState = LogOutlookTransportState("queued managed email " & managedKey, outlookApp)

    If transportState("Blocked") Then
        Set GetQueuedManagedEmailDecision = NewQueueDecision("KEEP_AND_ALERT", _
            "Outlook appears offline/disconnected/auth-blocked; user action required.")
        Exit Function
    End If

    If TryGetEffectiveDeferredDeliveryTime(queuedMail, deferredValue) Then
        If CDate(deferredValue) > CDate(currentTime) Then
            Set GetQueuedManagedEmailDecision = NewQueueDecision("KEEP_WAITING", _
                "Deferred delivery time has not been reached.")
            Exit Function
        End If
    End If

    ageMinutes = GetManagedMailAgeMinutes(queuedMail, currentTime)
    If ageMinutes < 0 Then
        Set GetQueuedManagedEmailDecision = NewQueueDecision("KEEP_AND_ALERT", _
            "Unable to determine queued item age safely; manual review required.")
        Exit Function
    End If

    If ageMinutes < CLng(graceMinutes) Then
        Set GetQueuedManagedEmailDecision = NewQueueDecision("KEEP_WAITING", _
            "Recently queued; still within grace period.")
        Exit Function
    End If

    Set sentMatches = FindManagedEmailInSentItems(managedKey, SafeMailSubject(queuedMail))
    If sentMatches.Count > 0 Then
        Set GetQueuedManagedEmailDecision = NewQueueDecision("ALREADY_SENT", _
            "Email reached Sent Items during recheck.")
        Exit Function
    End If

    If Not ENABLE_STALE_OUTBOX_REPLACEMENT Then
        Set GetQueuedManagedEmailDecision = NewQueueDecision("KEEP_AND_ALERT", _
            "Managed email appears stale, but stale Outbox replacement is disabled.")
        Exit Function
    End If

    Set GetQueuedManagedEmailDecision = NewQueueDecision("REPLACE_OUTBOX_ITEM", _
        "Managed email is stale in Outbox while Outlook appears connected and delivery time has passed.")
End Function

'==============================================================
' Managed Email Dispatch State Machine
'==============================================================
Function GetFirstManagedEmailMatch(ByRef matches)
    Dim matchKey
    Set GetFirstManagedEmailMatch = Nothing
    For Each matchKey In matches.Keys
        Set GetFirstManagedEmailMatch = matches.Item(matchKey)
        Exit Function
    Next
End Function

Function FindNewestManagedOutboxItem(ByRef matches)
    Dim matchKey, mail, newest, mailTime, newestTime
    Set newest = Nothing

    For Each matchKey In matches.Keys
        Set mail = matches.Item(matchKey)
        If newest Is Nothing Then
            Set newest = mail
        Else
            mailTime = GetManagedMailReferenceTime(mail)
            newestTime = GetManagedMailReferenceTime(newest)
            If IsDate(mailTime) And IsDate(newestTime) Then
                If CDate(mailTime) > CDate(newestTime) Then Set newest = mail
            End If
        End If
    Next

    Set FindNewestManagedOutboxItem = newest
End Function

Function AllMatchesHaveExpectedManagedKey(ByRef matches, managedKey)
    Dim matchKey, mail
    AllMatchesHaveExpectedManagedKey = True
    For Each matchKey In matches.Keys
        Set mail = matches.Item(matchKey)
        If GetManagedEmailKey(mail) <> managedKey Then
            AllMatchesHaveExpectedManagedKey = False
            Exit Function
        End If
    Next
End Function

Function ConsolidateManagedOutboxMatches(ByRef matches, managedKey, subjectText)
    Dim result, sentMatches, keptMail, matchKey, mail
    Set ConsolidateManagedOutboxMatches = Nothing

    If matches.Count <= 1 Then
        Set ConsolidateManagedOutboxMatches = matches
        Exit Function
    End If

    LogEvent "Multiple matching managed Outbox items detected for key '" & managedKey & "': " & matches.Count

    If Not AllMatchesHaveExpectedManagedKey(matches, managedKey) Then
        LogEvent "ERROR: Multiple Outbox matches include legacy subject-only or unkeyed items. No cleanup or new send will occur; manual Outlook review required for subject '" & subjectText & "'."
        Exit Function
    End If

    Set sentMatches = FindManagedEmailInSentItems(managedKey, subjectText)
    If sentMatches.Count > 0 Then
        LogEvent "Queue decision: ALREADY_SENT"
        LogEvent "Reason for decision: Email reached Sent Items during duplicate-Outbox safety recheck."
        Set result = CreateObject("Scripting.Dictionary")
        Set ConsolidateManagedOutboxMatches = result
        Exit Function
    End If

    Set keptMail = FindNewestManagedOutboxItem(matches)
    If keptMail Is Nothing Then
        LogEvent "ERROR: Unable to choose a newest managed Outbox item for key '" & managedKey & "'. Manual review required."
        Exit Function
    End If

    For Each matchKey In matches.Keys
        Set mail = matches.Item(matchKey)
        If Not mail Is keptMail Then
            If GetManagedEmailKey(mail) = managedKey And IsItemInOutbox(mail) Then
                On Error Resume Next
                LogEvent "Deleting older duplicate managed Outbox item for key '" & managedKey & "' | EntryID=" & SafeOutlookText(mail, "EntryID")
                mail.Delete
                If Err.Number <> 0 Then
                    LogError "Failed to delete older duplicate managed Outbox item for key '" & managedKey & "'"
                    On Error GoTo 0
                    Exit Function
                End If
                On Error GoTo 0
            Else
                LogEvent "ERROR: Older duplicate failed ownership/folder guard for key '" & managedKey & "'. Manual review required."
                Exit Function
            End If
        End If
    Next

    Set result = CreateObject("Scripting.Dictionary")
    result.Add "0", keptMail
    LogEvent "Consolidated duplicate managed Outbox items for key '" & managedKey & "'; kept newest active copy."
    Set ConsolidateManagedOutboxMatches = result
End Function

Function CreateManagedEmailFromSpec(ByRef outlookApp, managedKey, subjectText, toAddress, bodyText, deferredDeliveryTime)
    Dim mail
    Set mail = outlookApp.CreateItem(0)
    With mail
        .To = toAddress
        .Subject = subjectText
        .Body = bodyText
        If IsDate(deferredDeliveryTime) Then
            .DeferredDeliveryTime = CDate(deferredDeliveryTime)
        End If
    End With
    StampManagedEmail mail, managedKey
    Set CreateManagedEmailFromSpec = mail
End Function

Sub VerifyManagedEmailAfterSend(managedKey, subjectText)
    Dim sentMatches, outboxMatches
    Set sentMatches = FindManagedEmailInSentItems(managedKey, subjectText)
    Set outboxMatches = FindManagedEmailInOutbox(managedKey, subjectText)

    LogEvent "Post-send verification result for managed key '" & managedKey & "': SentItems=" & _
             sentMatches.Count & " | Outbox=" & outboxMatches.Count

    If sentMatches.Count > 0 Or outboxMatches.Count > 0 Then
        LogEvent "Managed email observed in Sent Items or Outbox after send attempt for key '" & managedKey & "'."
    Else
        LogEvent "WARNING: Managed email not observed in Sent Items or Outbox after send attempt for key '" & managedKey & "'."
    End If
End Sub

Sub VerifyManagedEmailAfterSendIfUrgent(isUrgentSend, managedKey, subjectText)
    If CBool(isUrgentSend) Then
        VerifyManagedEmailAfterSend managedKey, subjectText
    Else
        LogEvent "Immediate post-send verification skipped for non-urgent managed email key '" & managedKey & "'. Next script run will check Sent Items or Outbox by managed key."
    End If
End Sub

Function SafeToReplaceManagedOutboxItem(ByRef outlookApp, ByRef queuedMail, managedKey, subjectText, currentTime, graceMinutes)
    Dim sentMatches, transportState, deferredValue, ageMinutes
    SafeToReplaceManagedOutboxItem = False

    If GetManagedEmailKey(queuedMail) <> managedKey Then
        LogEvent "Replacement guard failed: queued item does not have expected managed key '" & managedKey & "'."
        Exit Function
    End If

    If Not IsItemInOutbox(queuedMail) Then
        LogEvent "Replacement guard failed: managed item is no longer in Outlook Outbox for key '" & managedKey & "'."
        Exit Function
    End If

    Set sentMatches = FindManagedEmailInSentItems(managedKey, subjectText)
    If sentMatches.Count > 0 Then
        LogEvent "Replacement guard failed: Sent Items now contains managed key '" & managedKey & "'."
        Exit Function
    End If

    Set transportState = LogOutlookTransportState("pre-replacement guard " & managedKey, outlookApp)
    If transportState("Blocked") Then
        LogEvent "Replacement guard failed: Outlook appears offline/disconnected/auth-blocked for key '" & managedKey & "'."
        Exit Function
    End If

    ageMinutes = GetManagedMailAgeMinutes(queuedMail, currentTime)
    If ageMinutes < CLng(graceMinutes) Then
        LogEvent "Replacement guard failed: queued managed email age " & CStr(ageMinutes) & _
                 " minute(s) is below grace period " & CStr(graceMinutes) & " for key '" & managedKey & "'."
        Exit Function
    End If

    If TryGetEffectiveDeferredDeliveryTime(queuedMail, deferredValue) Then
        If CDate(deferredValue) > CDate(currentTime) Then
            LogEvent "Replacement guard failed: deferred delivery time is still in the future for key '" & managedKey & "'."
            Exit Function
        End If
    End If

    If Not ENABLE_STALE_OUTBOX_REPLACEMENT Then
        LogEvent "Replacement guard failed: stale Outbox replacement is disabled."
        Exit Function
    End If

    SafeToReplaceManagedOutboxItem = True
End Function

Sub ReplaceStaleManagedOutboxItem(ByRef outlookApp, ByRef queuedMail, managedKey, subjectText, toAddress, bodyText, deferredDeliveryTime, emailType, isUrgentSend)
    Dim replacement

    If Not SafeToReplaceManagedOutboxItem(outlookApp, queuedMail, managedKey, subjectText, Now, MANAGED_OUTBOX_GRACE_MINUTES) Then
        LogEvent "ERROR: Replacement aborted by guardrails for managed key '" & managedKey & "'."
        Exit Sub
    End If

    LogEvent "Managed email appears stale in Outbox while Outlook is connected and delivery time has passed. Replacing stale managed Outbox item."

    On Error Resume Next
    LogEvent "Deleting stale managed Outbox item for key '" & managedKey & "' | EntryID=" & SafeOutlookText(queuedMail, "EntryID")
    queuedMail.Delete
    If Err.Number <> 0 Then
        LogError "Failed to delete stale managed Outbox item for key '" & managedKey & "'"
        On Error GoTo 0
        Exit Sub
    End If
    On Error GoTo 0

    Set replacement = CreateManagedEmailFromSpec(outlookApp, managedKey, subjectText, toAddress, bodyText, deferredDeliveryTime)
    LogEvent "Created clean replacement managed email for key '" & managedKey & "' and type '" & emailType & "'."
    LogOutlookTransportStateSnapshot "before replacement send " & managedKey, outlookApp
    On Error Resume Next
    replacement.Send
    If Err.Number <> 0 Then
        LogError "Failed to send replacement managed email for key '" & managedKey & "'"
        On Error GoTo 0
        Exit Sub
    End If
    On Error GoTo 0
    LogOutlookTransportStateSnapshot "after replacement send " & managedKey, outlookApp
    LogEvent "Replaced stale email and submitted replacement for managed key '" & managedKey & "'."
    VerifyManagedEmailAfterSendIfUrgent isUrgentSend, managedKey, subjectText
End Sub

Sub DispatchManagedEmail(ByRef outlookApp, managedKey, subjectText, toAddress, bodyText, deferredDeliveryTime, emailType, isUrgentSend)
    Call LogVerbose("DispatchManagedEmail invoked for key='" & managedKey & "'")
    Dim sentMatches, outboxMatches, consolidatedMatches, queuedMail, mail, decision, queuedKey

    LogEvent "Preparing managed email | Key: " & managedKey & " | Type: " & emailType & _
             " | Subject: " & subjectText & " | To: " & toAddress
    LogOutlookTransportStateSnapshot "before managed dispatch " & managedKey, outlookApp

    Set sentMatches = FindManagedEmailInSentItems(managedKey, subjectText)
    If sentMatches.Count > 0 Then
        LogEvent "Queue decision: ALREADY_SENT"
        LogEvent "Reason for decision: Matching managed email exists in Sent Items. Do not recreate or resend."
        Exit Sub
    End If

    Set outboxMatches = FindManagedEmailInOutbox(managedKey, subjectText)
    If outboxMatches.Count = 0 Then
        If DEBUG_MODE Then
            LogEvent "DEBUG_MODE enabled - managed email not sent. Key: " & managedKey & " | Subject: " & subjectText
            If DISPLAY_DEBUG_POPUPS Then
                MsgBox "[DEBUG] Would send managed email to " & toAddress & ":" & vbCrLf & _
                       "Key: " & managedKey & vbCrLf & "Subject: " & subjectText & vbCrLf & vbCrLf & bodyText
            Else
                LogVerbose "Managed email preview suppressed for key='" & managedKey & "'"
            End If
            Exit Sub
        End If

        Set mail = CreateManagedEmailFromSpec(outlookApp, managedKey, subjectText, toAddress, bodyText, deferredDeliveryTime)
        LogEvent "Created new managed email for key '" & managedKey & "'."
        LogOutlookTransportStateSnapshot "before send " & managedKey, outlookApp
        On Error Resume Next
        mail.Send
        If Err.Number <> 0 Then
            LogError "Failed to send managed email for key '" & managedKey & "'"
            On Error GoTo 0
            Exit Sub
        End If
        On Error GoTo 0
        LogOutlookTransportStateSnapshot "after send " & managedKey, outlookApp
        LogEvent "Submitted managed email for key '" & managedKey & "'."
        VerifyManagedEmailAfterSendIfUrgent isUrgentSend, managedKey, subjectText
        Exit Sub
    End If

    LogEvent "Outbox search result for managed key '" & managedKey & "': active queued attempt detected."
    Set consolidatedMatches = ConsolidateManagedOutboxMatches(outboxMatches, managedKey, subjectText)
    If consolidatedMatches Is Nothing Then
        LogEvent "Queue decision: KEEP_AND_ALERT"
        LogEvent "Reason for decision: Multiple Outbox matches could not be safely consolidated; manual review required."
        LogEvent "ACTION REQUIRED: Managed email has ambiguous Outbox copies. Keeping existing Outbox item(s); review Outlook before rerunning automation."
        Exit Sub
    End If

    If consolidatedMatches.Count = 0 Then
        Exit Sub
    End If

    Set queuedMail = GetFirstManagedEmailMatch(consolidatedMatches)
    queuedKey = GetManagedEmailKey(queuedMail)
    LogOutboxDiagnosticSnapshot queuedMail, managedKey

    If queuedKey <> managedKey Then
        LogEvent "Queue decision: KEEP_WAITING"
        LogEvent "Reason for decision: Legacy subject-only Outbox match has no managed key; treating it as an active send attempt but not deleting or replacing it."
        Exit Sub
    End If

    Set decision = GetQueuedManagedEmailDecision(outlookApp, queuedMail, managedKey, Now, MANAGED_OUTBOX_GRACE_MINUTES, deferredDeliveryTime)
    LogEvent "Queue decision: " & decision("Decision")
    LogEvent "Reason for decision: " & decision("Reason")

    Select Case decision("Decision")
        Case "ALREADY_SENT"
            LogEvent "Managed email has already reached Sent Items. No recreate or resend for key '" & managedKey & "'."
        Case "KEEP_AND_ALERT"
            If InStr(1, decision("Reason"), "offline/disconnected/auth-blocked", vbTextCompare) > 0 Then
                LogEvent "ACTION REQUIRED: Managed email is queued because Outlook appears offline/disconnected/auth-blocked. Keeping existing Outbox item. User should reconnect Outlook, disable Work Offline, or complete O365 authentication."
            Else
                LogEvent "ACTION REQUIRED: Managed email remains queued and requires manual review. Keeping existing Outbox item."
            End If
        Case "KEEP_WAITING"
            If InStr(1, decision("Reason"), "grace period", vbTextCompare) > 0 Then
                LogEvent "Queued managed email is still within grace period. Keeping existing Outbox item."
            Else
                LogEvent "Queued managed email is waiting for Outlook delivery conditions. Keeping existing Outbox item."
            End If
        Case "REPLACE_OUTBOX_ITEM"
            ReplaceStaleManagedOutboxItem outlookApp, queuedMail, managedKey, subjectText, toAddress, bodyText, deferredDeliveryTime, emailType, isUrgentSend
        Case Else
            LogEvent "ERROR: Unknown managed email queue decision '" & decision("Decision") & "' for key '" & managedKey & "'."
    End Select
End Sub

Function HasAlertBeenSentToday(subjectText)
    Call LogVerbose("HasAlertBeenSentToday invoked for subject='" & subjectText & "'")
    Dim sentItems, mail

    On Error Resume Next
    Set sentItems = olNS.GetDefaultFolder(5).Items
    If Err.Number <> 0 Then
        LogError "Unable to access Sent Items for alert subject '" & subjectText & "'"
        On Error GoTo 0
        HasAlertBeenSentToday = False
        Exit Function
    End If
    On Error GoTo 0

    sentItems.Sort "SentOn", True

    HasAlertBeenSentToday = False
    For Each mail In sentItems
        If TypeName(mail) = "MailItem" Then
            If DateValue(mail.SentOn) < Date Then Exit For
            If mail.Subject = subjectText And DateValue(mail.SentOn) = Date Then
                LogEvent "Alert with subject '" & subjectText & "' already sent today."
                HasAlertBeenSentToday = True
                Exit For
            End If
        End If
    Next

    LogEvent "HasAlertBeenSentToday('" & subjectText & "') result: " & HasAlertBeenSentToday
End Function

'==============================================================
' Meeting Content Builders
'==============================================================
Function DeriveMeetingLeadName(objSheetRota, meetingDate)
    Call LogVerbose("DeriveMeetingLeadName invoked")
    Dim previousLabManager, previousFriday, previousFridayRow, searchRow, lastRow, candidateDate

    previousFriday = DateAdd("d", -7, meetingDate)
    previousFridayRow = -1
    lastRow = objSheetRota.Cells(objSheetRota.Rows.Count, "A").End(-4162).Row

    For searchRow = 2 To lastRow
        candidateDate = objSheetRota.Cells(searchRow, 1).Value
        If candidateDate = previousFriday Then
            previousFridayRow = searchRow
            Exit For
        End If
    Next

    If previousFridayRow <> -1 Then
        previousLabManager = Trim(objSheetRota.Cells(previousFridayRow, 6).Value)
    Else
        previousLabManager = ""
    End If

    If previousLabManager = "" Then
        previousLabManager = DEFAULT_PREVIOUS_LAB_MANAGER
    End If

    DeriveMeetingLeadName = previousLabManager
    LogEvent "Derived meeting lead as '" & previousLabManager & "' for meeting date " & FormatDateTime(meetingDate, 2)
End Function

Function BuildMeetingSubject(meetingDate)
    Call LogVerbose("BuildMeetingSubject invoked")
    BuildMeetingSubject = "ABT group meeting @ 11am (" & FormatDateTime(meetingDate, 2) & ")"
End Function

Function BuildGroupEmailSubject(meetingDate, alternateText)
    Call LogVerbose("BuildGroupEmailSubject invoked")
    If IsNoMeetingEvent(alternateText) Then
        BuildGroupEmailSubject = "No group meeting (" & FormatDateTime(meetingDate, 2) & ")"
    Else
        BuildGroupEmailSubject = BuildMeetingSubject(meetingDate)
    End If
End Function

Function IsCollegeClosureEvent(alternateText)
    Dim normalizedAlternate
    normalizedAlternate = LCase(Trim(CStr(alternateText)))
    IsCollegeClosureEvent = (InStr(normalizedAlternate, "college closure") > 0)
End Function

Function IsNoMeetingEvent(alternateText)
    Dim normalizedAlternate
    normalizedAlternate = LCase(Trim(CStr(alternateText)))
    IsNoMeetingEvent = (InStr(normalizedAlternate, "college closure") > 0 Or _
                        InStr(normalizedAlternate, "no meeting") > 0 Or _
                        InStr(normalizedAlternate, "no-meeting") > 0)
End Function

Function GetNoMeetingReasonText(alternateText)
    If IsCollegeClosureEvent(alternateText) Then
        GetNoMeetingReasonText = "because of college closure"
    Else
        GetNoMeetingReasonText = ""
    End If
End Function

Function IsSameDayBeforeMeeting(meetingDate)
    IsSameDayBeforeMeeting = (DateValue(Date) = DateValue(meetingDate) And TimeValue(Now) < TimeSerial(11, 0, 0))
End Function

Function FormatDayMonth(targetDate)
    FormatDayMonth = Right("0" & Day(targetDate), 2) & "/" & Right("0" & Month(targetDate), 2)
End Function

Function FormatShortDate(targetDate)
    FormatShortDate = Right("0" & Day(targetDate), 2) & "/" & _
                      Right("0" & Month(targetDate), 2) & "/" & _
                      Right("0" & (Year(targetDate) Mod 100), 2)
End Function

Function GetLabManagerWeekStart(meetingDate)
    GetLabManagerWeekStart = DateAdd("d", -4, meetingDate)
End Function

Function GetLabManagerWeekEnd(meetingDate)
    GetLabManagerWeekEnd = meetingDate
End Function

Function GenerateEmailContent(meetingDate, row, objSheetRota, nextFridayRow)
    Call LogVerbose("GenerateEmailContent invoked for row " & row)
    Dim literature, results, alternate, room, labManager, next_lit, next_res, next_alt, content, nameParts
    Dim meetingLeadName, nextMeetingLeadName
    Dim meetingDateText, meetingShortDate, nextFridayDate, nextFridayText, nextFridayShortDate
    Dim labManagerRangeStart, labManagerRangeEnd, nextLabManagerRangeStart, nextLabManagerRangeEnd
    Dim nextLabManager
    Dim currentResults, currentLiterature, currentLabManager, currentChair
    Dim nextResults, nextLiterature, nextChair
    Dim currentAlternate, nextAlternate
    literature = Trim(objSheetRota.Cells(row, 2).Value)
    results    = Trim(objSheetRota.Cells(row, 3).Value)
    alternate  = Trim(objSheetRota.Cells(row, 4).Value)
    room       = Trim(objSheetRota.Cells(row, 5).Value)
    labManager = Trim(objSheetRota.Cells(row, 6).Value)
    LogEvent "Generating main email content for date " & meetingDate & _
              " | Row: " & row & " | Lit: " & literature & _
              " | Res: " & results & " | Alt: " & alternate & _
              " | Room: " & room

    If nextFridayRow <> -1 Then
        next_lit = objSheetRota.Cells(nextFridayRow, 2).Value
        next_res = objSheetRota.Cells(nextFridayRow, 3).Value
        next_alt = objSheetRota.Cells(nextFridayRow, 4).Value
        nextLabManager = Trim(objSheetRota.Cells(nextFridayRow, 6).Value)
        nextFridayDate = objSheetRota.Cells(nextFridayRow, 1).Value
        LogEvent "Next Friday presenters found | Row: " & nextFridayRow & _
                  " | Lit: " & next_lit & " | Res: " & next_res & _
                  " | Alt: " & next_alt
    Else
        next_lit = ""
        next_res = ""
        next_alt = ""
        nextLabManager = ""
        nextFridayDate = DateAdd("d", 7, meetingDate)
        LogEvent "No next Friday data found. Using empty placeholders."
    End If

    nameParts = Split(olNS.Accounts.Item(1).CurrentUser, ", ")
    Dim senderFirstName
    senderFirstName = ""
    If UBound(nameParts) >= 1 Then
        senderFirstName = Trim(nameParts(1))
    ElseIf UBound(nameParts) = 0 Then
        senderFirstName = Trim(nameParts(0))
    End If
    If senderFirstName = "" Then
        senderFirstName = Trim(olNS.Accounts.Item(1).CurrentUser)
    End If

    meetingLeadName = DeriveMeetingLeadName(objSheetRota, meetingDate)
    nextMeetingLeadName = DeriveMeetingLeadName(objSheetRota, nextFridayDate)

    meetingDateText = WeekdayName(Weekday(meetingDate), False) & " " & FormatDateTime(meetingDate, 2)
    meetingShortDate = FormatDayMonth(meetingDate)
    nextFridayText = WeekdayName(Weekday(nextFridayDate), False) & " " & FormatDateTime(nextFridayDate, 2)
    nextFridayShortDate = FormatDayMonth(nextFridayDate)

    labManagerRangeStart = FormatDayMonth(DateAdd("d", -4, meetingDate))
    labManagerRangeEnd = FormatDayMonth(meetingDate)
    nextLabManagerRangeStart = FormatDayMonth(DateAdd("d", -4, nextFridayDate))
    nextLabManagerRangeEnd = FormatDayMonth(nextFridayDate)

    currentResults = Trim(results)
    If currentResults = "" Then
        currentResults = "TBC (X)"
    End If

    currentLiterature = Trim(literature)
    If currentLiterature = "" Then
        currentLiterature = "TBC (X)"
    End If

    currentLabManager = Trim(labManager)
    If currentLabManager = "" Then
        currentLabManager = "TBC (X)"
    End If

    currentChair = Trim(meetingLeadName)
    If currentChair = "" Then
        currentChair = "TBC (X)"
    End If

    currentAlternate = Trim(alternate)

    nextResults = Trim(next_res)
    If nextResults = "" Then
        nextResults = "TBC (X)"
    End If

    nextLiterature = Trim(next_lit)
    If nextLiterature = "" Then
        nextLiterature = "TBC (X)"
    End If

    If Trim(nextLabManager) = "" Then
        nextLabManager = "TBC (X)"
    End If

    nextAlternate = Trim(next_alt)

    nextChair = Trim(nextMeetingLeadName)
    If nextChair = "" Then
        nextChair = "TBC (X)"
    End If

    If IsNoMeetingEvent(currentAlternate) Then
        content = "Hi all," & vbCrLf & vbCrLf
        content = content & "Please note that no group meeting will take place on " & meetingDateText & _
                  " " & GetNoMeetingReasonText(currentAlternate) & "." & vbCrLf & vbCrLf
        If nextFridayRow <> -1 Then
            content = content & "The next scheduled group meeting is on " & nextFridayText & " at 11:00." & vbCrLf & vbCrLf
        End If
        content = content & "Best," & vbCrLf & Trim(senderFirstName)
        GenerateEmailContent = content
        LogEvent "Generated no-meeting email body length: " & Len(content)
        Exit Function
    End If

    content = "Hi all," & vbCrLf & vbCrLf
    If Trim(room) <> "" Then
        content = content & "We will have our group meeting on " & meetingDateText & _
                  " at 11:00, in person (" & room & ") or via MS Teams (see calendar invite for the link)." & vbCrLf & vbCrLf
    Else
        content = content & "We will have our group meeting on " & meetingDateText & _
                  " at 11:00, in person or via MS Teams (see calendar invite for the link)." & vbCrLf & vbCrLf
    End If

    content = content & "This week (" & meetingShortDate & "):" & vbCrLf & vbCrLf
    If currentAlternate <> "" Then
        content = content & "- " & currentAlternate & vbCrLf
    Else
        content = content & "- Results: " & currentResults & vbCrLf
        content = content & "- Literature: " & currentLiterature & vbCrLf
    End If
    content = content & "- Lab manager: " & currentLabManager & " (" & labManagerRangeStart & " - " & labManagerRangeEnd & ")" & vbCrLf
    content = content & "- Chair / timekeeper: " & currentChair & vbCrLf
    content = content & vbCrLf

    content = content & "We will be starting promptly at 11:00. Presenters, please arrive/join 5-10 minutes early to set up. If the room is occupied right up to 11:00, we will start at 11:05." & vbCrLf & vbCrLf

    content = content & "For the following Friday (" & nextFridayText & "):" & vbCrLf & vbCrLf
    If nextAlternate <> "" Then
        content = content & "- " & nextAlternate & vbCrLf
    Else
        content = content & "- Results: " & nextResults & vbCrLf
        content = content & "- Literature: " & nextLiterature & vbCrLf
    End If
    content = content & "- Lab manager: " & nextLabManager & " (" & nextLabManagerRangeStart & " - " & nextLabManagerRangeEnd & ")" & vbCrLf
    content = content & "- Chair / timekeeper: " & nextChair &  vbCrLf
    content = content & vbCrLf

    content = content & "Upcoming weeks schedule:" & vbCrLf & _
              "https://imperiallondon.sharepoint.com/sites/Brandt-TalbotGroup/Shared%20Documents/Group%20Meetings/meeting_rota.xlsx?web=1" & vbCrLf & vbCrLf

    content = content & "Best," & vbCrLf & Trim(senderFirstName)

    GenerateEmailContent = content
    LogEvent "Generated email body length: " & Len(content)
End Function

Function GeneratePresenterReminderEmail(presenterName, presentationType, meetingDate)
    Call LogVerbose("GeneratePresenterReminderEmail invoked for presenter='" & presenterName & "'")
    Dim content, nameParts, trimmedType, normalizedType, description, reminderSubject, meetingDateText, typeLabel
    Dim greetingName, tokens, meetingDateCode, presenterInitials
    presenterName = Trim(presenterName)
    presentationType = Trim(presentationType)
    LogEvent "Generating presenter reminder email | Presenter: " & presenterName & _
              " | Type: " & presentationType

    trimmedType = presentationType
    normalizedType = LCase(trimmedType)
    Select Case normalizedType
        Case "literature"
            description = "the literature session"
            typeLabel = "Literature presentation"
        Case "results"
            description = "the results update"
            typeLabel = "Results presentation"
        Case Else
            If trimmedType <> "" Then
                description = "the " & presentationType & " presentation"
                typeLabel = trimmedType & " presentation"
            Else
                description = "your presentation"
                typeLabel = "Presentation"
            End If
    End Select

    reminderSubject = LCase(typeLabel)
    meetingDateText = FormatDateTime(meetingDate, 2)
    meetingDateCode = FormatMeetingDateForFilename(meetingDate)
    presenterInitials = ExtractNameInitials(presenterName)
    If presenterInitials = "" Then
        presenterInitials = "XX"
    End If
    nameParts = Split(olNS.Accounts.Item(1).CurrentUser, ", ")
    Dim senderFirstName
    senderFirstName = ""
    If UBound(nameParts) >= 1 Then
        senderFirstName = Trim(nameParts(1))
    ElseIf UBound(nameParts) = 0 Then
        senderFirstName = Trim(nameParts(0))
    End If
    If senderFirstName = "" Then
        senderFirstName = Trim(olNS.Accounts.Item(1).CurrentUser)
    End If

    If presenterName = "" Then
        content = "Hi," & vbCrLf & vbCrLf
        content = content & "No presenter is currently assigned for the " & reminderSubject & _
                  " scheduled on " & meetingDateText & "." & vbCrLf & vbCrLf
        content = content & "Please update the rota or advise the group so we can keep the agenda on track." & vbCrLf & vbCrLf
        content = content & "Best," & vbCrLf & Trim(senderFirstName)
        GeneratePresenterReminderEmail = content
        LogEvent "Generated presenter reminder length: " & Len(content)
        Exit Function
    End If

    greetingName = presenterName
    If InStr(greetingName, ",") > 0 Then
        tokens = Split(greetingName, ",")
        If UBound(tokens) >= 1 Then
            greetingName = Trim(tokens(1))
        ElseIf UBound(tokens) = 0 Then
            greetingName = Trim(tokens(0))
        End If
    Else
        tokens = Split(greetingName, " ")
        If UBound(tokens) >= 0 Then
            greetingName = Trim(tokens(0))
        End If
    End If

    Dim enDash, apostrophe, bulletChar
    enDash = ChrW(&H2013)
    apostrophe = Chr(39)
    bulletChar = ChrW(&H2022)

    content = "Hi " & Trim(greetingName) & "," & vbCrLf & vbCrLf
    content = content & "Just a reminder that you are scheduled to present " & description & _
              " at this week's group meeting on " & meetingDateText & ". The slot is 15 minutes for your presentation plus 5 minutes for Q&A. " & _
              "As a rough guide, aim for about 1 minute per slide (so around 10" & enDash & "12 slides in total). " & _
              "The group meeting leader will keep time to ensure we don" & apostrophe & "t overrun, so please rehearse your talk beforehand to check that you are within the time limit." & vbCrLf & vbCrLf
    content = content & "Please save your presentation to the group SharePoint folder (https://imperiallondon.sharepoint.com/:f:/r/sites/Brandt-TalbotGroup/Shared%20Documents/Group%20Meetings/Group%20Meeting%20Presentations?csf=1&web=1&e=eK2FLV) using the naming pattern YYMMDD_[NameInitials]_" & normalizedType & "_presentation.pptx." & vbCrLf
    content = content & "For clarity: use the meeting date as YYMMDD, add your initials, and include the talk type (e.g., " & description & "), ending with _presentation.pptx (e.g., " & meetingDateCode & "_" & presenterInitials & "_" & normalizedType & "_presentation.pptx)." & vbCrLf & vbCrLf
    If normalizedType = "literature" Then
        content = content & "Share the article you" & apostrophe & "ll present on Friday by Wednesday, so anyone interested can skim it in advance and come prepared with questions" & enDash & "making the discussion more enjoyable and productive." & vbCrLf & vbCrLf
        content = content & "For literature presentations, please choose high-quality papers that may be of general interest, and focus on the higher-level implications (e.g., key scientific principles and/or relevance to work within the group)." & vbCrLf & vbCrLf
    End If
    content = content & "A few pointers for preparing your slides:" & vbCrLf & vbCrLf
    content = content & bulletChar & " Aim for a balanced, well-planned presentation, rather than trying to include everything." & vbCrLf & vbCrLf
    content = content & bulletChar & " Use no more than ~3 concise bullet points per slide to support (not duplicate) what you say, so the audience focuses on you rather than reading the screen." & vbCrLf & vbCrLf
    content = content & bulletChar & " Let the slides support your performance, not be the performance" & enDash & "they shouldn" & apostrophe & "t steal your stage." & vbCrLf & vbCrLf
    content = content & bulletChar & " One clear, well-chosen image is often more effective than a lot of text, especially as many scientists are visual learners." & vbCrLf & vbCrLf
    content = content & bulletChar & " Assume a left-to-right, top-to-bottom reading pattern: place the most important information at the top left and less critical details toward the bottom right." & vbCrLf & vbCrLf
    content = content & "Please ensure your materials are ready and let me know if you need any support." & vbCrLf & vbCrLf
    content = content & "Best," & vbCrLf & Trim(senderFirstName)
    GeneratePresenterReminderEmail = content
    LogEvent "Generated presenter reminder length: " & Len(content)
End Function

Function GenerateMeetingLeadReminderEmail(meetingLeadName, meetingDate)
    Call LogVerbose("GenerateMeetingLeadReminderEmail invoked for lead='" & meetingLeadName & "'")
    Dim content, greetingName, tokens, meetingDateText
    Dim nameParts, senderFirstName

    meetingLeadName = Trim(meetingLeadName)
    meetingDateText = FormatDateTime(meetingDate, 2)

    nameParts = Split(olNS.Accounts.Item(1).CurrentUser, ", ")
    senderFirstName = ""
    If UBound(nameParts) >= 1 Then
        senderFirstName = Trim(nameParts(1))
    ElseIf UBound(nameParts) = 0 Then
        senderFirstName = Trim(nameParts(0))
    End If
    If senderFirstName = "" Then
        senderFirstName = Trim(olNS.Accounts.Item(1).CurrentUser)
    End If

    greetingName = meetingLeadName
    If InStr(greetingName, ",") > 0 Then
        tokens = Split(greetingName, ",")
        If UBound(tokens) >= 1 Then
            greetingName = Trim(tokens(1))
        ElseIf UBound(tokens) = 0 Then
            greetingName = Trim(tokens(0))
        End If
    Else
        tokens = Split(greetingName, " ")
        If UBound(tokens) >= 0 Then
            greetingName = Trim(tokens(0))
        End If
    End If

    If Trim(greetingName) = "" Then
        greetingName = "there"
    End If

    content = "Hi " & greetingName & "," & vbCrLf & vbCrLf
    content = content & "Just a reminder that you will lead this week's group meeting on " & meetingDateText & "." & vbCrLf & vbCrLf
    content = content & "Each presenter has 15 minutes for their talk plus 5 minutes for Q&A." & vbCrLf & vbCrLf
    content = content & "Please arrive about 5 minutes early to set up the room so the computer is ready right at meeting time." & vbCrLf & vbCrLf
    content = content & "Bring the red/yellow timing cards (5 minutes/1 minute left) to signal time to each presenter, and keep presenters on schedule while running the inclusion activity." & vbCrLf & vbCrLf
    content = content & "Best," & vbCrLf & Trim(senderFirstName)

    GenerateMeetingLeadReminderEmail = content
    LogEvent "Generated meeting lead reminder length: " & Len(content)
End Function

Function GenerateLabManagerReminderEmail(labManagerName, meetingDate)
    Call LogVerbose("GenerateLabManagerReminderEmail invoked for manager='" & labManagerName & "'")
    Dim content, nameParts, manager
    Dim firstName, lastName, senderDisplayName, parcelAddressee
    Dim greetingName, tokens
    Dim weekStartDate, weekEndDate, startText, endText, weekRange
    manager = Trim(labManagerName)
    LogEvent "Generating lab manager reminder email | Manager: " & manager

    If manager = "" Then
        manager = "there"
    End If

    greetingName = manager
    If LCase(greetingName) <> "there" Then
        If InStr(greetingName, ",") > 0 Then
            tokens = Split(greetingName, ",")
            If UBound(tokens) >= 1 Then
                greetingName = Trim(tokens(1))
            ElseIf UBound(tokens) = 0 Then
                greetingName = Trim(tokens(0))
            End If
        Else
            tokens = Split(greetingName, " ")
            If UBound(tokens) >= 0 Then
                greetingName = Trim(tokens(0))
            End If
        End If

        If Trim(greetingName) = "" Then
            greetingName = manager
        End If
    End If

    nameParts = Split(olNS.Accounts.Item(1).CurrentUser, ", ")
    firstName = ""
    lastName = ""

    If UBound(nameParts) >= 1 Then
        lastName = Trim(nameParts(0))
        firstName = Trim(nameParts(1))
    ElseIf UBound(nameParts) = 0 Then
        firstName = Trim(nameParts(0))
    End If

    senderDisplayName = firstName
    If senderDisplayName = "" Then
        senderDisplayName = Trim(olNS.Accounts.Item(1).CurrentUser)
    End If

    parcelAddressee = senderDisplayName
    If lastName <> "" Then
        If senderDisplayName <> "" Then
            parcelAddressee = senderDisplayName & " " & lastName
        Else
            parcelAddressee = lastName
        End If
    End If

    If parcelAddressee = "" Then
        parcelAddressee = "me"
    End If

    If senderDisplayName = "" Then
        senderDisplayName = parcelAddressee
    End If

    weekStartDate = GetLabManagerWeekStart(meetingDate)
    weekEndDate = GetLabManagerWeekEnd(meetingDate)
    startText = FormatDateTime(weekStartDate, 2)
    endText = FormatDateTime(weekEndDate, 2)
    weekRange = startText & " " & ChrW(&H2013) & " " & endText

    Dim greetingDisplay
    If LCase(greetingName) = "there" Then
        greetingDisplay = greetingName
    Else
        greetingDisplay = Trim(greetingName)
    End If

    content = "Hi " & greetingDisplay & "," & vbCrLf & vbCrLf
    content = content & "This is a reminder that you are the lab manager for the week of " & weekRange & "." & vbCrLf & vbCrLf
    content = content & "Lab cleaning starts on Monday and must be completed by this Friday " & ChrW(&H2014) & _
              " please try to finish it by Friday EOD so the lab is ready for Monday." & vbCrLf & vbCrLf
    Dim parcelDisplay
    parcelDisplay = parcelAddressee
    If LCase(parcelAddressee) <> "me" Then
        parcelDisplay = Trim(parcelAddressee)
    End If

    content = content & "On friday, please pick up all parcels addressed to " & parcelDisplay & _
              "; most of them contain the consumables ordered the last week that need to be re-stocked in the lab." & vbCrLf & vbCrLf
    content = content & "Also, please procure the list of missing items on the whiteboard from the stores so that we can maintain supplies at all times." & vbCrLf & vbCrLf
    content = content & "Thank you for keeping the lab organized." & vbCrLf & vbCrLf
    content = content & "Best," & vbCrLf & Trim(senderDisplayName)
    GenerateLabManagerReminderEmail = content
    LogEvent "Generated lab manager reminder length: " & Len(content)
End Function

'==============================================================
' Reminder Workflow
'==============================================================
Function ResolveEmailOrManager(personName)
    Call LogVerbose("ResolveEmailOrManager invoked for person='" & personName & "'")
    Dim resolved
    resolved = GetExactEmail(personName)
    If Trim(resolved & "") <> "" Then
        LogEvent "Resolved exact email for '" & personName & "': " & resolved
        ResolveEmailOrManager = resolved
    Else
        LogEvent "Falling back to manager email for '" & personName & "'"
        ResolveEmailOrManager = MANAGER
    End If
End Function

Sub DispatchReminderEmail(toAddress, subjectText, bodyText, managedKey, emailType)
    Call LogVerbose("DispatchReminderEmail invoked for subject='" & subjectText & "'")
    DispatchManagedEmail OL, managedKey, subjectText, toAddress, bodyText, Empty, emailType, False
End Sub

Function BuildPresenterReminderSubject(presentationType, meetingDate)
    Call LogVerbose("BuildPresenterReminderSubject invoked")
    Dim trimmedType, normalizedType, typeLabel
    trimmedType = Trim(presentationType)
    normalizedType = LCase(trimmedType)
    Select Case normalizedType
        Case "literature"
            typeLabel = "Literature presentation"
        Case "results"
            typeLabel = "Results presentation"
        Case Else
            If trimmedType = "" Then
                typeLabel = "Presentation"
            Else
                typeLabel = trimmedType & " presentation"
            End If
    End Select
    BuildPresenterReminderSubject = typeLabel & " reminder (" & FormatDateTime(meetingDate, 2) & ")"
End Function

Function BuildMeetingLeadReminderSubject(meetingDate)
    Call LogVerbose("BuildMeetingLeadReminderSubject invoked")
    BuildMeetingLeadReminderSubject = "Meeting lead reminder (" & FormatDateTime(meetingDate, 2) & ")"
End Function

Function BuildSameDayMeetingReminderSubject(meetingDate, room)
    Call LogVerbose("BuildSameDayMeetingReminderSubject invoked")
    Dim meetingDateText
    meetingDateText = FormatShortDate(meetingDate)
    If Trim(room) <> "" Then
        BuildSameDayMeetingReminderSubject = "Reminder: ABT group meeting " & meetingDateText & " @ 11am in " & Trim(room)
    Else
        BuildSameDayMeetingReminderSubject = "Reminder: ABT group meeting " & meetingDateText & " @ 11am"
    End If
End Function

Function BuildLabManagerReminderSubject(labManagerName, meetingDate)
    Call LogVerbose("BuildLabManagerReminderSubject invoked")
    Dim weekStartDate, weekEndDate, startText, endText
    weekStartDate = GetLabManagerWeekStart(meetingDate)
    weekEndDate = GetLabManagerWeekEnd(meetingDate)
    startText = FormatDateTime(weekStartDate, 2)
    endText = FormatDateTime(weekEndDate, 2)
    BuildLabManagerReminderSubject = "Lab management reminder (" & startText & " " & ChrW(&H2013) & " " & endText & ")"
End Function

Sub TriggerReminderEmails(literaturePresenter, resultsPresenter, labManagerName, meetingLeadName, meetingDate)
    Call LogVerbose("TriggerReminderEmails invoked")
    LogEvent "Triggering reminder workflow for meeting date " & FormatDateTime(meetingDate, 2)
    MaybeSendPresenterReminder literaturePresenter, "Literature", meetingDate
    MaybeSendPresenterReminder resultsPresenter, "Results", meetingDate
    MaybeSendMeetingLeadReminder meetingLeadName, meetingDate
    MaybeSendLabManagerReminder labManagerName, meetingDate
End Sub

Sub MaybeSendPresenterReminder(presenterName, presentationType, meetingDate)
    Call LogVerbose("MaybeSendPresenterReminder invoked for presenter='" & presenterName & "'")
    Dim trimmedName, subjectLine, targetEmail, body, emailType, managedKey
    trimmedName = Trim(presenterName)

    targetEmail = ResolveEmailOrManager(trimmedName)
    subjectLine = BuildPresenterReminderSubject(presentationType, meetingDate)
    emailType = NormalizeManagedEmailType(presentationType & "-REMINDER")
    managedKey = BuildManagedEmailKey(meetingDate, emailType)

    body = GeneratePresenterReminderEmail(trimmedName, presentationType, meetingDate)
    DispatchReminderEmail targetEmail, subjectLine, body, managedKey, emailType
End Sub

Sub MaybeSendMeetingLeadReminder(meetingLeadName, meetingDate)
    Call LogVerbose("MaybeSendMeetingLeadReminder invoked for meeting lead='" & meetingLeadName & "'")
    Dim trimmedName, subjectLine, targetEmail, body, emailType, managedKey
    trimmedName = Trim(meetingLeadName)

    targetEmail = ResolveEmailOrManager(trimmedName)
    subjectLine = BuildMeetingLeadReminderSubject(meetingDate)
    emailType = "MEETING-LEAD-REMINDER"
    managedKey = BuildManagedEmailKey(meetingDate, emailType)

    body = GenerateMeetingLeadReminderEmail(trimmedName, meetingDate)
    DispatchReminderEmail targetEmail, subjectLine, body, managedKey, emailType
End Sub

Function GenerateSameDayMeetingReminderEmail(meetingDate, room)
    Call LogVerbose("GenerateSameDayMeetingReminderEmail invoked")
    Dim content, nameParts, senderFirstName, meetingDateText

    meetingDateText = WeekdayName(Weekday(meetingDate), False) & " " & FormatDateTime(meetingDate, 2)

    nameParts = Split(olNS.Accounts.Item(1).CurrentUser, ", ")
    senderFirstName = ""
    If UBound(nameParts) >= 1 Then
        senderFirstName = Trim(nameParts(1))
    ElseIf UBound(nameParts) = 0 Then
        senderFirstName = Trim(nameParts(0))
    End If
    If senderFirstName = "" Then
        senderFirstName = Trim(olNS.Accounts.Item(1).CurrentUser)
    End If

    content = "Hi all," & vbCrLf & vbCrLf
    If Trim(room) <> "" Then
        content = content & "Just a quick reminder that our group meeting is today (" & meetingDateText & _
                  ") at 11:00 in " & Trim(room) & "." & vbCrLf & vbCrLf
    Else
        content = content & "Just a quick reminder that our group meeting is today (" & meetingDateText & _
                  ") at 11:00." & vbCrLf & vbCrLf
    End If
    content = content & "Looking forward to seeing you there." & vbCrLf & vbCrLf
    content = content & "Best," & vbCrLf & Trim(senderFirstName)

    GenerateSameDayMeetingReminderEmail = content
    LogEvent "Generated same-day meeting reminder length: " & Len(content)
End Function

Sub MaybeSendSameDayMeetingReminder(meetingDate, room, alternateText)
    Call LogVerbose("MaybeSendSameDayMeetingReminder invoked")
    Dim subjectLine, body, emailType, managedKey

    If IsNoMeetingEvent(alternateText) Then
        LogEvent "Skipping same-day meeting reminder " & GetNoMeetingReasonText(alternateText) & "."
        Exit Sub
    End If

    If Not IsSameDayBeforeMeeting(meetingDate) Then
        LogEvent "Skipping same-day meeting reminder because it is not the meeting day before 11:00."
        Exit Sub
    End If

    subjectLine = BuildSameDayMeetingReminderSubject(meetingDate, room)
    emailType = "SAME-DAY-REMINDER"
    managedKey = BuildManagedEmailKey(meetingDate, emailType)

    body = GenerateSameDayMeetingReminderEmail(meetingDate, room)
    DispatchReminderEmail EMAIL_TO, subjectLine, body, managedKey, emailType
End Sub

Sub MaybeSendLabManagerReminder(labManagerName, meetingDate)
    Call LogVerbose("MaybeSendLabManagerReminder invoked for manager='" & labManagerName & "'")
    Dim trimmedName, subjectLine, targetEmail, body, emailType, managedKey
    trimmedName = Trim(labManagerName)

    targetEmail = ResolveEmailOrManager(trimmedName)
    subjectLine = BuildLabManagerReminderSubject(trimmedName, meetingDate)
    emailType = "LAB-MANAGER-REMINDER"
    managedKey = BuildManagedEmailKey(meetingDate, emailType)

    body = GenerateLabManagerReminderEmail(trimmedName, meetingDate)
    DispatchReminderEmail targetEmail, subjectLine, body, managedKey, emailType
End Sub

'==============================================================
' Standard Email Dispatch
'==============================================================
Sub DistributeEmail(header, body, meetingDate)
    Call LogVerbose("DistributeEmail invoked with subject='" & header & "'")
    Dim managedKey, emailType
    LogEvent "Preparing regular meeting email with subject: " & header

    emailType = "REGULAR"
    managedKey = BuildManagedEmailKey(meetingDate, emailType)
    DispatchManagedEmail OL, managedKey, header, EMAIL_TO, body, Empty, emailType, False
End Sub

'==============================================================
' Alert Email Helpers
'==============================================================
Function GenerateEmailAlert(alertType, missingDate, recipientEmail, tentativeRota)
    Call LogVerbose("GenerateEmailAlert invoked for alertType='" & alertType & "'")
    Dim content
    content = "Hi," & vbCrLf & vbCrLf
    Select Case alertType
        Case "MissingDate"
            content = content & "There is no entry in the rota for " & missingDate & "." & vbCrLf & _
                      "Please update the rota accordingly." & vbCrLf & vbCrLf & tentativeRota
        Case "Unassigned"
            content = content & "The rota entry for " & missingDate & " has no assigned presenters." & vbCrLf & _
                      "Please review the tentative 6-month rota below and approve or adjust:" & vbCrLf & vbCrLf & tentativeRota
        Case "MissingRoom"
            content = content & "The rota entry for " & missingDate & " has no room reservation." & vbCrLf & _
                      "Please reserve a room for the meeting." & vbCrLf
            content = content & vbCrLf & "Send Email to the building manager to request room for the upcoming term: " & _
              "mailto:" & BUILDING_ADMIN_EMAIL & "?subject=Room%20Reservation%20Request%20for%20ABT%20Group%20Meetings%20%E2%80%93%20Upcoming%20Term&body=Hi%20building%20manager,%0D%0A%0D%0AI%20hope%20you%20are%20well.%0D%0A%0D%0AI%20would%20like%20to%20request%20a%20recurring%20booking%20for%20our%20ABT%20group%20meetings%20for%20the%20upcoming%20academic%20term.%20Could%20you%20please%20reserve%20G25%20(MSRH)%20for%20Fridays%20from%2011:00%20to%2012:00,%20starting%20from%20the%20next%20available%20week?%0D%0A%0D%0ACould%20you%20also%20let%20me%20know%20the%20exact%20date%20the%20reservation%20ends?%0D%0A%0D%0AThank%20you%20very%20much%20for%20your%20help.%0D%0A%0D%0ABest%20regards,%0D%0AGiacomo" & vbCrLf & vbCrLf
        Case "MeetingNotSet"
            content = content & "The rota entry for " & missingDate & " has no presenters or alternate assigned, so the regular meeting email was not sent to the distribution list." & vbCrLf & _
                      "Please update the rota with presenters so the meeting can be scheduled." & vbCrLf
    End Select
    content = content & vbCrLf & "Contact directly via email: " & recipientEmail & vbCrLf & vbCrLf
    content = content & "Best," & vbCrLf & "Automated Meeting Scheduler"
    GenerateEmailAlert = content
End Function

Sub AlertEmail(toAddress, messageBody, subjectText)
    Call LogVerbose("AlertEmail invoked to='" & toAddress & "'")
    Dim mail
    If HasAlertBeenSentToday(subjectText) Then
        LogEvent "Alert email for subject '" & subjectText & "' was already sent today. Skipping duplicate dispatch."
        Exit Sub
    End If

    LogEvent "Preparing alert email with subject: " & subjectText & " to " & toAddress
    Set mail = OL.CreateItem(0)
    With mail
        .To = toAddress
        .Subject = subjectText
        .Body = messageBody
        If DEBUG_MODE Then
            LogEvent "DEBUG_MODE enabled - alert email not sent. Subject: " & subjectText
            If DISPLAY_DEBUG_POPUPS Then
                MsgBox "[DEBUG] Would send ALERT email to " & toAddress & ":" & vbCrLf & _
                    "Subject: " & subjectText & vbCrLf & vbCrLf & messageBody
            Else
                LogVerbose "Alert email preview suppressed for subject='" & subjectText & "'"
            End If
        Else
            LogEvent "Sending alert email to " & toAddress & " with subject: " & subjectText
            .Send
            If EmailExists(subjectText, 5, True) Then
                LogEvent "Negative feedback loop confirmed for alert subject: " & subjectText
            Else
                LogEvent "WARNING: Alert subject not observed in Sent Items after sending: " & subjectText
            End If
        End If
    End With
End Sub

Sub AlertEmailWithAttachment(toAddress, messageBody, subjectText, attachmentPath)
    Call LogVerbose("AlertEmailWithAttachment invoked to='" & toAddress & "' with attachment='" & attachmentPath & "'")
    Dim mail
    If HasAlertBeenSentToday(subjectText) Then
        LogEvent "Alert email with attachment for subject '" & subjectText & "' was already sent today. Skipping duplicate dispatch."
        Exit Sub
    End If

    LogEvent "Preparing alert email with attachment. Subject: " & subjectText & _
                  " | Recipient: " & toAddress & " | Attachment: " & attachmentPath
    Set mail = OL.CreateItem(0)
    With mail
        .To = toAddress
        .Subject = subjectText
        .Body = messageBody
        If attachmentPath <> "" Then
            .Attachments.Add attachmentPath
            LogEvent "Attached file to email: " & attachmentPath
        End If
        If DEBUG_MODE Then
            LogEvent "DEBUG_MODE enabled - alert email with attachment not sent. Subject: " & subjectText
            If DISPLAY_DEBUG_POPUPS Then
                MsgBox "[DEBUG] Would send ALERT email with attachment to " & toAddress & ":" & vbCrLf & _
                       "Subject: " & subjectText & vbCrLf & vbCrLf & messageBody & vbCrLf & _
                       "Attachment: " & attachmentPath
            Else
                LogVerbose "Alert email with attachment preview suppressed for subject='" & subjectText & "'"
            End If
        Else
            LogEvent "Sending alert email with attachment to " & toAddress & " with subject: " & subjectText
            .Send
            If EmailExists(subjectText, 5, True) Then
                LogEvent "Negative feedback loop confirmed for alert subject: " & subjectText
            Else
                LogEvent "WARNING: Alert subject not observed in Sent Items after sending: " & subjectText
            End If
        End If
    End With
End Sub

'==============================================================
' Tentative Rota Helpers
'==============================================================
Function GenerateTentativeRota(objSheetEmails)
    Call LogVerbose("GenerateTentativeRota invoked")
    Dim lastRow, presenterColumn, i, numNames, names(), rndIndex, tmp
    Dim rotaDates(), rotaAssignments(), rotaBody, dt, totalWeeks
    Dim csvFile, txtStream
    LogEvent "Starting tentative rota generation"

    lastRow = objSheetEmails.Cells(objSheetEmails.Rows.Count, "A").End(-4162).Row
    presenterColumn = FindHeaderColumn(objSheetEmails, "Presenter", 5)
    LogEvent "Using Emails sheet Presenter column: " & presenterColumn
    numNames = 0
    For i = 2 To lastRow
        If IsFlagSet(objSheetEmails.Cells(i, presenterColumn).Value) Then numNames = numNames + 1
    Next
    LogEvent "Eligible names counted: " & numNames
    If numNames = 0 Then
        LogEvent "No eligible names found for tentative rota."
        GenerateTentativeRota = "No eligible names for rota."
        Exit Function
    End If

    ReDim names(numNames - 1)
    numNames = 0
    For i = 2 To lastRow
        If IsFlagSet(objSheetEmails.Cells(i, presenterColumn).Value) Then
            names(numNames) = Trim(objSheetEmails.Cells(i, 1).Value)
            numNames = numNames + 1
        End If
    Next
    LogEvent "Names loaded for rota: " & Join(names, ", ")

    Randomize
    For i = 0 To UBound(names)
        rndIndex = Int(Rnd * (UBound(names) + 1))
        tmp = names(i)
        names(i) = names(rndIndex)
        names(rndIndex) = tmp
    Next
    LogEvent "Names shuffled for tentative rota."

    totalWeeks = 26
    LogEvent "Generating tentative rota for weeks: " & totalWeeks
    ReDim rotaDates(totalWeeks - 1)
    ReDim rotaAssignments(totalWeeks - 1, 1)
    dt = Date + ((5 - Weekday(Date, vbMonday) + 7) Mod 7)

    For i = 0 To totalWeeks - 1
        rotaDates(i) = DateAdd("ww", i, dt)
        rotaAssignments(i, 0) = names((i * 2) Mod (UBound(names) + 1))
        rotaAssignments(i, 1) = names((i * 2 + 1) Mod (UBound(names) + 1))
    Next

    rotaBody = "Tentative 6-month rota (Fridays, 2 presenters/day):" & vbCrLf & vbCrLf
    rotaBody = rotaBody & "Date         | Presenter 1          | Presenter 2" & vbCrLf
    rotaBody = rotaBody & String(50, "-") & vbCrLf
    For i = 0 To totalWeeks - 1
        rotaBody = rotaBody & FormatDateTime(rotaDates(i), 2) & " | " & _
                   PadRight(rotaAssignments(i, 0), 20) & " | " & _
                   PadRight(rotaAssignments(i, 1), 20) & vbCrLf
    Next

    csvFile = fso.GetSpecialFolder(2) & "\TentativeRota.csv"
    LogEvent "Writing tentative rota CSV to: " & csvFile
    Set txtStream = fso.CreateTextFile(csvFile, True)
    txtStream.WriteLine "Date,Presenter1,Presenter2"
    For i = 0 To totalWeeks - 1
        txtStream.WriteLine FormatDateTime(rotaDates(i), 2) & "," & _
                            rotaAssignments(i, 0) & "," & rotaAssignments(i, 1)
    Next
    txtStream.Close

    GenerateTentativeRota = rotaBody & vbCrLf & "[CSV: " & csvFile & "]"
    LogEvent "Tentative rota generation completed."
End Function

Function PadRight(str, totalLength)
    Call LogVerbose("PadRight invoked")
    Dim padding
    padding = totalLength - Len(str)
    If padding > 0 Then
        PadRight = str & String(padding, " ")
    Else
        PadRight = str
    End If
End Function

Sub WriteRotaCSV(rotaText, filePath)
    Call LogVerbose("WriteRotaCSV invoked for filePath='" & filePath & "'")
    Dim ts, lines, line, i
    LogEvent "Writing provided rota text to CSV at: " & filePath

    lines = Split(rotaText, vbCrLf)

    Set ts = fso.CreateTextFile(filePath, True)
    For i = 0 To UBound(lines)
        line = Trim(lines(i))
        If line <> "" Then
            line = Replace(line, "|", ",")
            ts.WriteLine line
        End If
    Next

    ts.Close
    Set ts = Nothing
    LogEvent "CSV writing completed for: " & filePath
End Sub

'==============================================================
' Workbook Helpers
'==============================================================
Function LoadMeetingWorkbook(ByRef objExcel, ByRef objWorkbook, ByRef objSheetRota, ByRef objSheetEmails)
    Call LogVerbose("LoadMeetingWorkbook invoked")
    LoadMeetingWorkbook = False

    On Error Resume Next
    Set objExcel = CreateObject("Excel.Application")
    If Err.Number <> 0 Then
        LogError "Failed to create Excel.Application"
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0
    LogEvent "Excel application created successfully."

    On Error Resume Next
    Set objWorkbook = objExcel.Workbooks.Open(EXCEL_PATH)
    If Err.Number <> 0 Then
        LogError "Failed to open workbook: " & EXCEL_PATH
        objExcel.Quit
        Set objExcel = Nothing
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0
    LogEvent "Workbook opened: " & EXCEL_PATH

    Set objSheetRota = objWorkbook.Sheets(SHEET_ROTA)
    Set objSheetEmails = objWorkbook.Sheets(SHEET_EMAILS)
    LogEvent "Sheets obtained: Rota and Emails"

    LoadMeetingWorkbook = True
End Function

Sub CloseMeetingWorkbook(ByRef objExcel, ByRef objWorkbook, ByRef objSheetRota, ByRef objSheetEmails)
    Call LogVerbose("CloseMeetingWorkbook invoked")
    objWorkbook.Close False
    objExcel.Quit
    Set objExcel = Nothing
    Set objWorkbook = Nothing
    Set objSheetRota = Nothing
    Set objSheetEmails = Nothing
    LogEvent "Coordinator routine completed and Excel resources released."
End Sub

Sub PopulateFridayDates(ByRef fridayDates)
    Call LogVerbose("PopulateFridayDates invoked")
    fridayDates(0) = Date + ((5 - Weekday(Date, vbMonday) + 7) Mod 7)
    fridayDates(1) = fridayDates(0) + 7
    fridayDates(2) = fridayDates(0) + 14
    LogEvent "Computed Fridays | This: " & FormatDateTime(fridayDates(0), 2) & _
              " | Next: " & FormatDateTime(fridayDates(1), 2) & _
              " | Next+1: " & FormatDateTime(fridayDates(2), 2)
End Sub

Sub LocateMeetingRows(ByRef fridayDates, ByVal objSheetRota, ByRef rowIndexes)
    Call LogVerbose("LocateMeetingRows invoked")
    Dim lastRow, i, meetingDate
    lastRow = objSheetRota.Cells(objSheetRota.Rows.Count, "A").End(-4162).Row
    LogEvent "Scanning rota sheet up to row: " & lastRow

    For i = 0 To 2
        rowIndexes(i) = -1
    Next

    For i = 2 To lastRow
        meetingDate = objSheetRota.Cells(i, 1).Value
        If meetingDate = fridayDates(0) Then rowIndexes(0) = i
        If meetingDate = fridayDates(1) Then rowIndexes(1) = i
        If meetingDate = fridayDates(2) Then rowIndexes(2) = i
    Next

    LogEvent "Rota rows located | This: " & rowIndexes(0) & _
              " | Next: " & rowIndexes(1) & _
              " | Next+1: " & rowIndexes(2)
End Sub

Sub SendCriticalAlert(alertType, targetDate, recipient, objSheetEmails)
    Call LogVerbose("SendCriticalAlert invoked for alertType='" & alertType & "'")
    Dim subject, tentativeRota, csvPath
    subject = "ALERT: " & alertType & " for " & FormatDateTime(targetDate, 2)

    If HasAlertBeenSentToday(subject) Then
        LogEvent "Alert '" & subject & "' already dispatched today. Skipping duplicate send."
        Exit Sub
    End If

    If alertType = "MissingDate" Or alertType = "Unassigned" Then
        tentativeRota = GenerateTentativeRota(objSheetEmails)
        csvPath = fso.GetSpecialFolder(2) & "\TentativeRota.csv"
        WriteRotaCSV tentativeRota, csvPath
    Else
        tentativeRota = ""
        csvPath = ""
    End If

    LogEvent "Dispatching alert email | Type: " & alertType & _
              " | Date: " & FormatDateTime(targetDate, 2) & _
              " | Recipient: " & recipient

    AlertEmailWithAttachment recipient, _
        GenerateEmailAlert(alertType, FormatDateTime(targetDate, 2), recipient, tentativeRota), _
        subject, csvPath
End Sub

Sub EvaluateCriticalWindows(ByRef fridayDates, ByRef rowIndexes, ByRef objSheetRota, ByRef objSheetEmails)
    Call LogVerbose("EvaluateCriticalWindows invoked")
    Dim idx, rowNum
    Dim tmpLiterature, tmpResults, tmpAlternate, tmpRoom

    For idx = 0 To 2
        rowNum = rowIndexes(idx)

        If rowNum = -1 Then
            SendCriticalAlert "MissingDate", fridayDates(idx), MANAGER, objSheetEmails
        Else
            tmpLiterature = objSheetRota.Cells(rowNum, 2).Value
            tmpResults    = objSheetRota.Cells(rowNum, 3).Value
            tmpAlternate  = objSheetRota.Cells(rowNum, 4).Value
            tmpRoom       = objSheetRota.Cells(rowNum, 5).Value
            LogEvent "Row " & rowNum & " data | Lit: " & tmpLiterature & _
                          " | Res: " & tmpResults & " | Alt: " & tmpAlternate & _
                          " | Room: " & tmpRoom

            If Trim(tmpLiterature) = "" And Trim(tmpResults) = "" And Trim(tmpAlternate) = "" Then
                SendCriticalAlert "Unassigned", fridayDates(idx), MANAGER, objSheetEmails
            End If

            If Trim(tmpRoom) = "" And Not IsNoMeetingEvent(tmpAlternate) Then
                SendCriticalAlert "MissingRoom", fridayDates(idx), MANAGER, objSheetEmails
            ElseIf Trim(tmpRoom) = "" Then
                LogEvent "Skipping missing-room alert for " & FormatDateTime(fridayDates(idx), 2) & " " & GetNoMeetingReasonText(tmpAlternate) & "."
            End If
        End If
    Next
End Sub

Sub HandleCommunications(ByRef fridayDates, ByRef rowIndexes, ByRef objSheetRota)
    Call LogVerbose("HandleCommunications invoked")
    Dim currentRow, literature, results, labManager, alternate, room, meetingLeadName, body, header, managerAlertSubject
    currentRow = rowIndexes(0)

    If currentRow = -1 Then
        LogEvent "No rota entry found for this Friday. Regular email and reminders will not be processed."
        Exit Sub
    End If

    literature = Trim(objSheetRota.Cells(currentRow, 2).Value)
    results    = Trim(objSheetRota.Cells(currentRow, 3).Value)
    labManager = Trim(objSheetRota.Cells(currentRow, 6).Value)
    alternate  = Trim(objSheetRota.Cells(currentRow, 4).Value)
    room       = Trim(objSheetRota.Cells(currentRow, 5).Value)
    meetingLeadName = DeriveMeetingLeadName(objSheetRota, fridayDates(0))

    If IsNoMeetingEvent(alternate) Then
        LogEvent "No-meeting event detected for " & FormatDateTime(fridayDates(0), 2) & " " & GetNoMeetingReasonText(alternate) & ". Sending no-meeting notice and suppressing meeting reminders."
        header = BuildGroupEmailSubject(fridayDates(0), alternate)
        body = GenerateEmailContent(fridayDates(0), currentRow, objSheetRota, rowIndexes(1))
        DistributeEmail header, body, fridayDates(0)
        Exit Sub
    End If

    If literature = "" And results = "" And alternate = "" Then
        LogEvent "No presenters or alternate assigned for " & FormatDateTime(fridayDates(0), 2) & ". Regular meeting email suppressed."
        managerAlertSubject = "ALERT: MeetingNotSet for " & FormatDateTime(fridayDates(0), 2)
        If Not HasAlertBeenSentToday(managerAlertSubject) Then
            LogEvent "Sending manager alert that the meeting is not set for " & FormatDateTime(fridayDates(0), 2)
            Call AlertEmail(MANAGER, _
                GenerateEmailAlert("MeetingNotSet", FormatDateTime(fridayDates(0), 2), MANAGER, ""), _
                managerAlertSubject)
        Else
            LogEvent "Manager alert already exists for " & FormatDateTime(fridayDates(0), 2) & ". Skipping duplicate notification."
        End If
        Exit Sub
    End If

    TriggerReminderEmails literature, results, labManager, meetingLeadName, fridayDates(0)
    MaybeSendSameDayMeetingReminder fridayDates(0), room, alternate

    header = BuildGroupEmailSubject(fridayDates(0), alternate)
    body = GenerateEmailContent(fridayDates(0), currentRow, objSheetRota, rowIndexes(1))
    LogEvent "Dispatching regular meeting email for " & FormatDateTime(fridayDates(0), 2)
    DistributeEmail header, body, fridayDates(0)
End Sub

'==============================================================
' Coordinator (Main Workflow)
'==============================================================
Sub Coordinator()
    Call LogVerbose("Coordinator invoked")
    Dim fridayDates(2), rowIndexes(2)
    Dim objExcel, objWorkbook, objSheetRota, objSheetEmails

    LogEvent "Coordinator routine started"

    PopulateFridayDates fridayDates

    If Not LoadMeetingWorkbook(objExcel, objWorkbook, objSheetRota, objSheetEmails) Then
        Exit Sub
    End If

    LocateMeetingRows fridayDates, objSheetRota, rowIndexes
    EvaluateCriticalWindows fridayDates, rowIndexes, objSheetRota, objSheetEmails
    HandleCommunications fridayDates, rowIndexes, objSheetRota

    CloseMeetingWorkbook objExcel, objWorkbook, objSheetRota, objSheetEmails
End Sub

'==============================================================
' Script Entrypoint
'==============================================================
Sub Main()
    Call LogVerbose("Main invoked")
    InitializeFileSystem
    InitializeLogging

    If Not SyncMeetingWorkbook() Then
        LogEvent "Continuing execution despite sync issues."
    End If

    If Not InitializeOutlook() Then
        CleanupSyncedWorkbook
        LogEvent "=== Script execution completed ==="
        Exit Sub
    End If

    LogEvent "Invoking Coordinator routine"
    Coordinator

    CleanupSyncedWorkbook
    LogEvent "=== Script execution completed ==="
End Sub

Main
