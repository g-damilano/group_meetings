Option Explicit
SetLocale 1033

Dim fso
Set fso = CreateObject("Scripting.FileSystemObject")

Dim scriptFolder
scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
Dim scaffoldRoot
scaffoldRoot = fso.GetParentFolderName(fso.GetParentFolderName(scriptFolder))

Dim bootstrapPath
bootstrapPath = fso.BuildPath(scaffoldRoot, "vbs\core\bootstrap.vbs")
Dim ts
Set ts = fso.OpenTextFile(bootstrapPath, 1)
ExecuteGlobal ts.ReadAll
ts.Close

SC_LoadCoreModules

Dim failures
failures = 0

Sub AssertTrue(condition, message)
  If condition Then
    WScript.Echo "OK: " & message
  Else
    WScript.Echo "FAILED: " & message
    failures = failures + 1
  End If
End Sub

Dim directory
Set directory = SC_CreateDictionary()
directory("team lead") = "team.lead@example.invalid"

Dim direct
Set direct = SC_ResolveRecipient("Alex Person <alex.person@example.invalid>", directory)
AssertTrue direct("resolution_status") = "direct", "direct SMTP recipient resolved"
AssertTrue direct("smtp_address") = "alex.person@example.invalid", "direct SMTP address normalized"
AssertTrue direct("display_name") = "Alex Person", "display name extracted"

Dim resolved
Set resolved = SC_ResolveRecipient("team lead", directory)
AssertTrue resolved("resolution_status") = "resolved", "directory recipient resolved"
AssertTrue resolved("smtp_address") = "team.lead@example.invalid", "directory SMTP address normalized"

Dim unresolved
Set unresolved = SC_ResolveRecipient("unknown person", directory)
AssertTrue unresolved("resolution_status") = "unresolved", "unknown recipient remains unresolved"
AssertTrue unresolved("fallback_used") = True, "unknown recipient marked as fallback"

Dim recipients
Set recipients = SC_ResolveRecipientList("Alex Person <alex.person@example.invalid>; team lead", directory)
AssertTrue recipients.Count = 2, "recipient list split"
AssertTrue SC_JoinResolvedRecipientAddresses(recipients) = "alex.person@example.invalid; team.lead@example.invalid", "recipient list joined"

Dim context
Set context = SC_CreateDictionary()
context("FIRST_NAME") = "Alex"
context("PROJECT") = "Example Project"

Dim templateText
templateText = "<!-- Subject: Welcome -->" & vbCrLf & _
               "<p>Hello [FIRST_NAME], welcome to {{PROJECT}}.</p>"

Dim placeholders
Set placeholders = SC_ExtractPlaceholders(templateText)
AssertTrue placeholders.Exists("FIRST_NAME"), "square placeholder extracted"
AssertTrue placeholders.Exists("PROJECT"), "double-brace placeholder extracted"

Dim renderedText
renderedText = SC_ApplyContextToText(templateText, context)
AssertTrue InStr(1, renderedText, "Hello Alex", vbTextCompare) > 0, "square placeholder rendered"
AssertTrue InStr(1, renderedText, "Example Project", vbTextCompare) > 0, "double-brace placeholder rendered"

Dim rendered
Set rendered = SC_RenderTemplateString(templateText, context)
AssertTrue rendered("metadata").Exists("SUBJECT"), "metadata parsed"
AssertTrue rendered("metadata")("SUBJECT") = "Welcome", "metadata value preserved"
AssertTrue InStr(1, rendered("body"), "Hello Alex", vbTextCompare) > 0, "rendered body returned"

If failures > 0 Then
  WScript.Echo "Template/recipient smoke test failed: " & failures & " issue(s)."
  WScript.Quit 1
End If

WScript.Echo "Template/recipient smoke test passed."

