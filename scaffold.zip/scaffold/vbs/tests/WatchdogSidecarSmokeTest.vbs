Option Explicit
SetLocale 1033

Dim fso
Set fso = CreateObject("Scripting.FileSystemObject")
Dim shell
Set shell = CreateObject("WScript.Shell")

Dim scriptFolder
scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
Dim scaffoldRoot
scaffoldRoot = fso.GetParentFolderName(fso.GetParentFolderName(scriptFolder))

Sub LoadTextModule(modulePath)
  Dim ts
  Set ts = fso.OpenTextFile(modulePath, 1)
  ExecuteGlobal ts.ReadAll
  ts.Close
End Sub

LoadTextModule fso.BuildPath(scaffoldRoot, "vbs\core\bootstrap.vbs")
SC_LoadCoreModules
LoadTextModule fso.BuildPath(scaffoldRoot, "vbs\watchdog\outlook_watchdog_sidecar.vbs")

Dim failures
failures = 0
Dim tempLogPath
tempLogPath = fso.BuildPath(fso.GetSpecialFolder(2), "office_scaffold_watchdog_sidecar_smoke.log")

Sub AssertTrue(condition, message)
  If condition Then
    WScript.Echo "OK: " & message
  Else
    WScript.Echo "FAILED: " & message
    failures = failures + 1
  End If
End Sub

Function FileContains(path, token)
  FileContains = (InStr(1, SC_ReadTextFile(path), CStr(token), vbTextCompare) > 0)
End Function

Class FakeUserProperty
  Public Value
End Class

Class FakeUserProperties
  Private props

  Private Sub Class_Initialize()
    Set props = CreateObject("Scripting.Dictionary")
  End Sub

  Public Function Find(name)
    If props.Exists(name) Then
      Set Find = props(name)
    Else
      Set Find = Nothing
    End If
  End Function

  Public Function Add(name, propType, addToFolderFields)
    Dim prop
    Set prop = New FakeUserProperty
    props(name) = prop
    Set Add = prop
  End Function
End Class

Class FakeAttachments
  Public Count
End Class

Class FakePropertyAccessor
  Public Function GetProperty(name)
    Err.Raise 4601, "FakePropertyAccessor", "Property unavailable"
  End Function
End Class

Class FakeMail
  Public UserProperties
  Public Attachments
  Public PropertyAccessor
  Public HTMLBody
  Public Body
  Public Subject
  Public EntryID
  Public CreationTime
  Public DeferredDeliveryTime
  Public DeleteCalled

  Private Sub Class_Initialize()
    Set UserProperties = New FakeUserProperties
    Set Attachments = New FakeAttachments
    Set PropertyAccessor = New FakePropertyAccessor
    HTMLBody = "<html><body><p>Queued</p></body></html>"
    Body = "Queued"
    Subject = "Queued"
    EntryID = "queued-entry"
    CreationTime = DateAdd("n", -30, Now)
    DeferredDeliveryTime = DateAdd("n", -1, Now)
    DeleteCalled = False
  End Sub

  Public Sub Delete()
    DeleteCalled = True
  End Sub
End Class

Function MakeTransport(blocked)
  Dim report
  Set report = SC_CreateHealthReport()
  report("blocked_or_auth_suspected") = CBool(blocked)
  report("offline") = CBool(blocked)
  Set MakeTransport = report
End Function

Function NewMail(subjectText, managedKey)
  Dim mail
  Set mail = New FakeMail
  mail.Subject = subjectText
  If Len(managedKey) > 0 Then SC_StampManagedMail mail, managedKey
  Set NewMail = mail
End Function

Dim managedKey
managedKey = SC_BuildManagedEmailKey("org", "workflow", #5/29/2026#, "regular", "target")
Dim managedMail
Set managedMail = NewMail("stale managed", managedKey)
Dim userMail
Set userMail = NewMail("user authored", "")

Dim items
Set items = SC_CreateDictionary()
Set items("managed") = managedMail
Set items("user") = userMail

Dim result
Set result = SC_WD_RunReportOnly(items, MakeTransport(False), Now, 15, tempLogPath)
AssertTrue result("state") = SC_STATE_ACTION_REQUIRED, "Stale managed mail is reported action-required in report-only mode"
AssertTrue CBool(result("report_only")), "Sidecar result is report-only"
AssertTrue result("repair_actions_taken") = 0, "Sidecar takes no repair actions"
AssertTrue result("outbox_report")("unmanaged_count") = 1, "Sidecar reports unmanaged mail"
AssertTrue userMail.DeleteCalled = False, "Sidecar does not delete unmarked user mail"
AssertTrue managedMail.DeleteCalled = False, "Sidecar does not delete managed mail in report-only mode"

Dim uncertain
Set uncertain = NewMail("uncertain", managedKey)
uncertain.CreationTime = "not-a-date"
Dim uncertainItems
Set uncertainItems = SC_CreateDictionary()
Set uncertainItems("uncertain") = uncertain
Set result = SC_WD_RunReportOnly(uncertainItems, MakeTransport(False), Now, 15, tempLogPath)
AssertTrue result("state") = SC_STATE_FAILED_SAFE, "Uncertain watchdog state fails safe"
AssertTrue CBool(result("action_required")), "Uncertain watchdog state requires action"
AssertTrue uncertain.DeleteCalled = False, "Uncertain item is not modified"

Function QuoteArg(value)
  QuoteArg = Chr(34) & Replace(CStr(value), Chr(34), Chr(34) & Chr(34)) & Chr(34)
End Function

Function RunCommand(commandText)
  Dim runResult
  Set runResult = SC_CreateDictionary()
  Dim exec
  Set exec = shell.Exec(commandText)
  Do While exec.Status = 0
    WScript.Sleep 50
  Loop
  runResult("exit_code") = exec.ExitCode
  runResult("output") = exec.StdOut.ReadAll & exec.StdErr.ReadAll
  Set RunCommand = runResult
End Function

Function OutputContains(runResult, token)
  OutputContains = (InStr(1, CStr(runResult("output")), CStr(token), vbTextCompare) > 0)
End Function

Dim entrypointPath
entrypointPath = fso.BuildPath(scaffoldRoot, "vbs\entrypoints\run_watchdog_report_only.vbs")
Dim dryRunEntry
Set dryRunEntry = RunCommand("cscript.exe //NoLogo " & QuoteArg(entrypointPath))
AssertTrue dryRunEntry("exit_code") = 0, "Watchdog entrypoint defaults to no-live report-only mode"
AssertTrue OutputContains(dryRunEntry, "report_only=true"), "Watchdog entrypoint reports report-only boundary"

Dim blockedEntry
Set blockedEntry = RunCommand("cscript.exe //NoLogo " & QuoteArg(entrypointPath) & " /repair")
AssertTrue blockedEntry("exit_code") = 1, "Watchdog repair request is blocked"
AssertTrue OutputContains(blockedEntry, "state=FAILED_SAFE"), "Blocked watchdog repair request fails safe"

Dim sidecarPath
sidecarPath = fso.BuildPath(scaffoldRoot, "vbs\watchdog\outlook_watchdog_sidecar.vbs")
AssertTrue Not FileContains(sidecarPath, ".Send"), "Watchdog sidecar owns no send call"
AssertTrue Not FileContains(sidecarPath, ".Delete"), "Watchdog sidecar owns no delete call"
AssertTrue Not FileContains(sidecarPath, "CreateObject(""Outlook.Application"")"), "Watchdog sidecar owns no Outlook creation"

If failures > 0 Then
  WScript.Echo "Watchdog sidecar smoke test failed: " & failures & " issue(s)."
  WScript.Quit 1
End If

On Error Resume Next
If fso.FileExists(tempLogPath) Then fso.DeleteFile tempLogPath, True
On Error GoTo 0

WScript.Echo "Watchdog sidecar smoke test passed."
