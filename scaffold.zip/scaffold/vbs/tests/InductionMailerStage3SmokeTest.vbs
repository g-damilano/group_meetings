Option Explicit
SetLocale 1033

Dim fso
Set fso = CreateObject("Scripting.FileSystemObject")

Dim scriptFolder
scriptFolder = fso.GetParentFolderName(WScript.ScriptFullName)
Dim scaffoldRoot
scaffoldRoot = fso.GetParentFolderName(fso.GetParentFolderName(scriptFolder))

Sub LoadTextModule(modulePath)
  Dim ts
  Set ts = fso.OpenTextFile(modulePath, 1)
  ExecuteGlobal ts.ReadAll
  ts.Close
End Sub

LoadTextModule fso.BuildPath(scaffoldRoot, "vbs\core\bootstrap.vbs")
SC_LoadCoreModules
LoadTextModule fso.BuildPath(scaffoldRoot, "vbs\workflows\workflow_helpers.vbs")
LoadTextModule fso.BuildPath(scaffoldRoot, "vbs\workflows\induction_mailer_workflow.vbs")
LoadTextModule fso.BuildPath(scaffoldRoot, "vbs\workflows\induction_mailer_input_adapter.vbs")
LoadTextModule fso.BuildPath(scaffoldRoot, "vbs\workflows\induction_mailer_message_plan.vbs")
LoadTextModule fso.BuildPath(scaffoldRoot, "vbs\workflows\induction_mailer_runner.vbs")

Dim failures
failures = 0

Sub AssertTrue(condition, message)
  If condition Then
    WScript.Echo "OK: " & message
  Else
    WScript.Echo "FAILED: " & message
    failures = failures + 1
  End If
End Sub

Function FileContains(path, token)
  FileContains = (InStr(1, SC_ReadTextFile(path), CStr(token), vbTextCompare) > 0)
End Function

Dim recipientsPath
recipientsPath = fso.BuildPath(scriptFolder, "fixtures\induction_recipients_fixture.csv")
Dim manifestPath
manifestPath = fso.BuildPath(scriptFolder, "fixtures\induction_template_manifest_fixture.csv")

Dim recipientLoad
Set recipientLoad = SC_IM_LoadRecipientCsv(recipientsPath)
AssertTrue recipientLoad("state") = SC_STATE_COMPOSED, "Recipient fixture loads"
AssertTrue recipientLoad("row_count") = 3, "Recipient fixture reports all rows"
AssertTrue recipientLoad("active_count") = 2, "Recipient fixture reports active recipients"
AssertTrue recipientLoad("recipients")("0")("full_name") = "New Starter", "Recipient full name mapped"

Dim templateLoad
Set templateLoad = SC_IM_LoadTemplateManifestCsv(manifestPath)
AssertTrue templateLoad("state") = SC_STATE_COMPOSED, "Template manifest fixture loads"
AssertTrue templateLoad("row_count") = 3, "Template manifest reports all rows"
AssertTrue templateLoad("enabled_count") = 2, "Template manifest reports enabled templates"
AssertTrue fso.FileExists(templateLoad("templates")("0")("template_path")), "Template path resolves relative to manifest"

Dim directory
Set directory = SC_IM_BuildRecipientDirectory(recipientLoad("recipients"))
AssertTrue directory("new-starter") = "new.starter@example.invalid", "Recipient directory maps aliases"
AssertTrue directory("New Starter") = "new.starter@example.invalid", "Recipient directory maps display names"

Dim context
Set context = SC_CreateInductionMailerWorkflowContext()
context("log_path") = fso.BuildPath(fso.GetSpecialFolder(2), "office_scaffold_induction_stage3_smoke.log")

Dim plan
Set plan = SC_IM_CreateMessagePlan(context, templateLoad("templates"), recipientLoad("recipients"), SC_IM_MODE_ALL, #6/1/2026#)
AssertTrue plan("state") = SC_STATE_COMPOSED, "Induction all-mode plan composes"
AssertTrue plan("messages").Count = 3, "All-mode plan has one broadcast and two personal messages"
AssertTrue plan("skips").Count = 1, "Disabled template is recorded as a skip"
AssertTrue plan("messages")("0")("message_type") = SC_IM_MODE_BROADCAST, "Broadcast template planned first"
AssertTrue plan("messages")("1")("message_type") = SC_IM_MODE_PERSONAL, "Personal template planned for active recipient"

Dim templateContext
Set templateContext = SC_CreateDictionary()
Dim planRun
Set planRun = SC_IM_RunMessagePlan(context, plan, directory, templateContext)
AssertTrue planRun("planned_count") = 3, "Plan run sees all induction messages"
AssertTrue planRun("composed_count") = 3, "Plan run remains dry-run composed"
AssertTrue planRun("failed_count") = 0, "Plan run has no failed-safe result"
AssertTrue planRun("dispatch_results")("0")("prepared_to") = "new.starter@example.invalid; observer@example.invalid", "Broadcast resolves active recipients"
AssertTrue planRun("dispatch_results")("1")("prepared_to") = "new.starter@example.invalid", "Personal message resolves first active recipient"
AssertTrue InStr(1, planRun("dispatch_results")("1")("prepared_subject"), "Welcome New", vbTextCompare) > 0, "Personal subject receives recipient context"
AssertTrue Not CBool(planRun("dispatch_results")("0")("created_new_mail")), "Dry-run creates no Outlook mail"

Dim runnerResult
Set runnerResult = SC_IM_RunInductionMailerCsvDryRun(context, manifestPath, recipientsPath, SC_IM_MODE_ALL, #6/1/2026#)
AssertTrue runnerResult("state") = SC_STATE_COMPOSED, "Induction runner composes"
AssertTrue runnerResult("planned_count") = 3, "Induction runner reports planned count"
AssertTrue runnerResult("composed_count") = 3, "Induction runner dry-runs all messages"
AssertTrue runnerResult("failed_count") = 0, "Induction runner reports no failed-safe messages"
AssertTrue runnerResult("skipped_count") = 1, "Induction runner reports disabled-template skip"

Dim broadcastOnly
Set broadcastOnly = SC_IM_RunInductionMailerCsvDryRun(context, manifestPath, recipientsPath, SC_IM_MODE_BROADCAST, #6/1/2026#)
AssertTrue broadcastOnly("planned_count") = 1, "Broadcast-only runner plans one message"
AssertTrue broadcastOnly("composed_count") = 1, "Broadcast-only runner composes one message"

Dim liveContext
Set liveContext = SC_CreateInductionMailerWorkflowContext()
liveContext("dry_run") = False
Dim blockedRun
Set blockedRun = SC_IM_RunInductionMailerCsvDryRun(liveContext, manifestPath, recipientsPath, SC_IM_MODE_ALL, #6/1/2026#)
AssertTrue blockedRun("state") = SC_STATE_FAILED_SAFE, "Induction runner blocks non-dry-run context"
AssertTrue CBool(blockedRun("action_required")), "Blocked induction runner flags action required"
AssertTrue blockedRun("planned_count") = 0, "Blocked induction runner does not plan messages"

Dim adapterPath
adapterPath = fso.BuildPath(scaffoldRoot, "vbs\workflows\induction_mailer_input_adapter.vbs")
Dim plannerPath
plannerPath = fso.BuildPath(scaffoldRoot, "vbs\workflows\induction_mailer_message_plan.vbs")
Dim runnerPath
runnerPath = fso.BuildPath(scaffoldRoot, "vbs\workflows\induction_mailer_runner.vbs")
AssertTrue Not FileContains(adapterPath, "CreateObject(""Outlook.Application"")"), "Induction adapter owns no Outlook application creation"
AssertTrue Not FileContains(plannerPath, "CreateObject(""Outlook.Application"")"), "Induction planner owns no Outlook application creation"
AssertTrue Not FileContains(runnerPath, "CreateObject(""Outlook.Application"")"), "Induction runner owns no Outlook application creation"
AssertTrue Not FileContains(plannerPath, "GetDefaultFolder"), "Induction planner owns no Outlook folder access"
AssertTrue Not FileContains(runnerPath, ".Send"), "Induction runner owns no Outlook send call"
AssertTrue Not FileContains(runnerPath, ".Delete"), "Induction runner owns no Outlook delete call"
AssertTrue Not FileContains(runnerPath, "sharepoint.com"), "Induction runner contains no private schedule links"

If failures > 0 Then
  WScript.Echo "Induction mailer Stage 3 smoke test failed: " & failures & " issue(s)."
  WScript.Quit 1
End If

WScript.Echo "Induction mailer Stage 3 smoke test passed."
