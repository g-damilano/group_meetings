' Recipient parsing and resolution helpers.
' The core resolver is deliberately conservative: direct SMTP parsing and caller-supplied
' directory maps are supported offline; live GAL/O365 lookup belongs behind a separate adapter.

Function SC_NormalizeEmailAddress(value)
  Dim text
  text = Trim(CStr(value))
  If LCase(Left(text, 7)) = "mailto:" Then text = Mid(text, 8)

  Dim ltPos
  Dim gtPos
  ltPos = InStr(1, text, "<", vbTextCompare)
  gtPos = InStr(1, text, ">", vbTextCompare)
  If ltPos > 0 And gtPos > ltPos Then
    text = Mid(text, ltPos + 1, gtPos - ltPos - 1)
  End If

  SC_NormalizeEmailAddress = LCase(Trim(text))
End Function

Function SC_DisplayNameFromRecipientText(value)
  Dim text
  text = Trim(CStr(value))
  Dim ltPos
  ltPos = InStr(1, text, "<", vbTextCompare)
  If ltPos > 1 Then
    SC_DisplayNameFromRecipientText = Trim(Left(text, ltPos - 1))
  Else
    SC_DisplayNameFromRecipientText = ""
  End If
End Function

Function SC_IsValidEmailAddress(value)
  Dim candidate
  candidate = SC_NormalizeEmailAddress(value)
  If Len(candidate) = 0 Then
    SC_IsValidEmailAddress = False
    Exit Function
  End If

  Dim regex
  Set regex = Nothing
  On Error Resume Next
  Set regex = CreateObject("VBScript.RegExp")
  If Err.Number <> 0 Then
    Err.Clear
    Set regex = Nothing
  End If
  On Error GoTo 0

  If regex Is Nothing Then
    Dim atPos
    Dim dotPos
    atPos = InStr(1, candidate, "@", vbTextCompare)
    dotPos = InStrRev(candidate, ".")
    SC_IsValidEmailAddress = (atPos > 1 And dotPos > atPos + 1 And dotPos < Len(candidate))
    Exit Function
  End If

  regex.Pattern = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,63}$"
  regex.IgnoreCase = True
  regex.Global = False
  SC_IsValidEmailAddress = regex.Test(candidate)
End Function

Function SC_DirectoryLookup(directory, lookupValue)
  SC_DirectoryLookup = ""
  If Not IsObject(directory) Then Exit Function

  Dim rawKey
  rawKey = Trim(CStr(lookupValue))
  Dim lowerKey
  lowerKey = LCase(rawKey)
  Dim upperKey
  upperKey = UCase(rawKey)

  On Error Resume Next
  If directory.Exists(rawKey) Then
    SC_DirectoryLookup = CStr(directory(rawKey))
  ElseIf directory.Exists(lowerKey) Then
    SC_DirectoryLookup = CStr(directory(lowerKey))
  ElseIf directory.Exists(upperKey) Then
    SC_DirectoryLookup = CStr(directory(upperKey))
  End If
  Err.Clear
  On Error GoTo 0
End Function

Function SC_ResolveRecipient(rawValue, directory)
  Dim spec
  Set spec = SC_CreateRecipientSpec(rawValue)

  Dim normalizedEmail
  normalizedEmail = SC_NormalizeEmailAddress(rawValue)
  If SC_IsValidEmailAddress(normalizedEmail) Then
    spec("display_name") = SC_DisplayNameFromRecipientText(rawValue)
    spec("smtp_address") = normalizedEmail
    spec("resolution_status") = "direct"
    spec("directory_source") = "direct"
    spec("fallback_used") = False
    Set SC_ResolveRecipient = spec
    Exit Function
  End If

  Dim directoryValue
  directoryValue = SC_DirectoryLookup(directory, rawValue)
  If Len(directoryValue) > 0 And SC_IsValidEmailAddress(directoryValue) Then
    spec("display_name") = Trim(CStr(rawValue))
    spec("smtp_address") = SC_NormalizeEmailAddress(directoryValue)
    spec("resolution_status") = "resolved"
    spec("directory_source") = "provided-directory"
    spec("fallback_used") = False
    Set SC_ResolveRecipient = spec
    Exit Function
  End If

  spec("display_name") = Trim(CStr(rawValue))
  spec("smtp_address") = Trim(CStr(rawValue))
  spec("resolution_status") = "unresolved"
  spec("directory_source") = ""
  spec("fallback_used") = True
  Set SC_ResolveRecipient = spec
End Function

Function SC_ResolveRecipientList(rawValue, directory)
  Dim recipients
  Set recipients = SC_CreateDictionary()

  Dim normalized
  normalized = Replace(CStr(rawValue), ",", ";")
  Dim parts
  parts = Split(normalized, ";")

  Dim i
  For i = LBound(parts) To UBound(parts)
    Dim itemText
    itemText = Trim(CStr(parts(i)))
    If Len(itemText) > 0 Then
      recipients.Add CStr(recipients.Count), SC_ResolveRecipient(itemText, directory)
    End If
  Next

  Set SC_ResolveRecipientList = recipients
End Function

Function SC_JoinResolvedRecipientAddresses(recipients)
  Dim list
  Set list = CreateObject("System.Collections.ArrayList")

  If IsObject(recipients) Then
    Dim key
    For Each key In recipients.Keys
      Dim spec
      Set spec = recipients(key)
      If Len(Trim(CStr(spec("smtp_address")))) > 0 Then list.Add Trim(CStr(spec("smtp_address")))
    Next
  End If

  If list.Count = 0 Then
    SC_JoinResolvedRecipientAddresses = ""
  Else
    Dim values()
    ReDim values(list.Count - 1)
    Dim i
    For i = 0 To list.Count - 1
      values(i) = list(i)
    Next
    SC_JoinResolvedRecipientAddresses = Join(values, "; ")
  End If
End Function

